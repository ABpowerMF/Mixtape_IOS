import Foundation
import SwiftUI
import UniformTypeIdentifiers

/// One file with your playlists, stats, your own lyrics and settings (not the music itself).
struct BackupFile: Codable {
    var app = "mixtape-ios"
    var version = 1
    var created: Double = Date().timeIntervalSince1970
    var playlists: [Playlist]
    /// Settings as a property list, base64.
    var settings: String
    /// Lyrics you pasted yourself, by file name.
    var lyrics: [String: String]
}

enum Backup {
    static var ownLyricsFolder: URL { Store.dataFolder.appendingPathComponent("lyrics", isDirectory: true) }

    static func make(playlists: [Playlist]) -> Data {
        var settings: [String: Any] = [:]
        for key in Prefs.backupKeys {
            if let v = UserDefaults.standard.object(forKey: key) { settings[key] = v }
        }
        let plist = (try? PropertyListSerialization.data(fromPropertyList: settings, format: .binary, options: 0)) ?? Data()
        var lyrics: [String: String] = [:]
        let files = (try? FileManager.default.contentsOfDirectory(at: ownLyricsFolder, includingPropertiesForKeys: nil)) ?? []
        for f in files where f.pathExtension == "json" {
            if let text = try? String(contentsOf: f, encoding: .utf8) { lyrics[f.lastPathComponent] = text }
        }
        let file = BackupFile(playlists: playlists, settings: plist.base64EncodedString(), lyrics: lyrics)
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted]
        return (try? encoder.encode(file)) ?? Data()
    }

    /// Puts the settings and lyrics back; returns the playlists.
    static func restore(_ data: Data) throws -> [Playlist] {
        let file = try JSONDecoder().decode(BackupFile.self, from: data)
        guard file.app == "mixtape-ios" else { throw StepError(step: "backup", message: "that isn't a Mixtape for iPhone backup") }
        if let plist = Data(base64Encoded: file.settings),
           let settings = try? PropertyListSerialization.propertyList(from: plist, options: [], format: nil) as? [String: Any] {
            for (k, v) in settings where Prefs.backupKeys.contains(k) { UserDefaults.standard.set(v, forKey: k) }
        }
        try? FileManager.default.createDirectory(at: ownLyricsFolder, withIntermediateDirectories: true)
        for (name, text) in file.lyrics where !name.contains("/") {
            try? text.write(to: ownLyricsFolder.appendingPathComponent(name), atomically: true, encoding: .utf8)
        }
        return file.playlists
    }
}

struct BackupDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }
    var data: Data

    init(data: Data) { self.data = data }

    init(configuration: ReadConfiguration) throws {
        guard let d = configuration.file.regularFileContents else { throw CocoaError(.fileReadCorruptFile) }
        data = d
    }

    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: data)
    }
}
