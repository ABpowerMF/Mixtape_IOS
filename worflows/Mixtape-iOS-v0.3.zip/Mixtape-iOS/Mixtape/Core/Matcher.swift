import Foundation

/// Same matching as the phone and PC apps: finds the file in the library that fits a playlist song.
enum TextMatch {
    private static let noise = try! NSRegularExpression(
        pattern: "\\b(feat|ft|featuring|with|remaster|remastered|radio edit|single version|album version|original version|mono|stereo|deluxe|bonus track|explicit|clean|official|lyrics?|audio|video|hq|hd)\\b")
    private static let brackets = try! NSRegularExpression(pattern: "[(\\[]([^)\\]]*)[)\\]]")
    private static let feat = try! NSRegularExpression(pattern: "\\s(feat\\.?|ft\\.?|featuring)\\s.*$")

    static func isNoise(_ s: String) -> Bool {
        noise.firstMatch(in: s, range: NSRange(location: 0, length: (s as NSString).length)) != nil
    }

    /// Lowercase, no accents, "&" → "and", only letters/digits separated by single spaces.
    static func normalize(_ raw: String?) -> String {
        guard let raw = raw, !raw.isEmpty else { return "" }
        var s = raw.lowercased().folding(options: [.diacriticInsensitive, .widthInsensitive], locale: nil)
        s = s.replacingOccurrences(of: "&", with: " and ")
        var out = String.UnicodeScalarView()
        var lastSpace = true
        for u in s.unicodeScalars {
            if u == "'" || u == "\u{2019}" || u == "`" || u == "\u{00B4}" { continue }
            let p = u.properties
            if p.isAlphabetic || p.numericType != nil {
                if p.generalCategory == .nonspacingMark { continue }
                out.append(u)
                lastSpace = false
            } else if p.generalCategory == .nonspacingMark {
                continue
            } else if !lastSpace {
                out.append(" ")
                lastSpace = true
            }
        }
        return String(out).trimmed
    }

    /// Title without "(feat. …)", "(Remastered 2011)", " - Radio Edit" and similar noise.
    static func normalizeTitle(_ raw: String?) -> String {
        var s = (raw ?? "").lowercased()
        let ns = s as NSString
        var rebuilt = ""
        var last = 0
        for m in brackets.matches(in: s, range: NSRange(location: 0, length: ns.length)) {
            rebuilt += ns.substring(with: NSRange(location: last, length: m.range.location - last))
            let inner = ns.substring(with: m.range(at: 1))
            rebuilt += isNoise(inner) ? " " : " \(inner) "
            last = m.range.location + m.range.length
        }
        rebuilt += ns.substring(from: last)
        s = rebuilt
        if let dash = s.range(of: " - "), dash.lowerBound > s.startIndex, isNoise(String(s[dash.upperBound...])) {
            s = String(s[..<dash.lowerBound])
        }
        s = feat.stringByReplacingMatches(in: s, range: NSRange(location: 0, length: (s as NSString).length), withTemplate: "")
        return normalize(s)
    }

    static func tokens(_ s: String) -> Set<String> { Set(s.split(separator: " ").map(String.init)) }

    static func containsWords(_ hay: String, _ needle: String) -> Bool {
        !needle.isEmpty && " \(hay) ".contains(" \(needle) ")
    }

    static func levenshtein(_ a: [Character], _ b: [Character]) -> Int {
        if a.isEmpty { return b.count }
        if b.isEmpty { return a.count }
        var prev = Array(0...b.count)
        var cur = Array(repeating: 0, count: b.count + 1)
        for i in 1...a.count {
            cur[0] = i
            for j in 1...b.count {
                cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] == b[j - 1] ? 0 : 1))
            }
            swap(&prev, &cur)
        }
        return prev[b.count]
    }

    static func similarity(_ a: String, _ b: String) -> Double {
        if a == b { return 1 }
        if a.isEmpty || b.isEmpty { return 0 }
        let x = Array(a.prefix(120)), y = Array(b.prefix(120))
        let distance: Double = Double(levenshtein(x, y))
        let longest: Double = Double(max(x.count, y.count))
        let lev: Double = 1 - distance / longest
        let ta = tokens(a), tb = tokens(b)
        let (small, big) = ta.count <= tb.count ? (ta, tb) : (tb, ta)
        let contained = !small.isEmpty && small.isSubset(of: big) ? 0.9 : 0
        return max(lev, contained)
    }
}

/// What the matcher needs from a playlist song.
struct WantedSong {
    var title: String
    var artists: [String]
    var durationMs: Int
}

final class Matcher {
    private struct Entry {
        let song: Song
        let title: String
        let artist: String
        let hay: String
    }

    private let entries: [Entry]
    private var byTitle: [String: [Int]] = [:]
    private var byWord: [String: [Int]] = [:]

    init(_ songs: [Song]) {
        entries = songs.map { s in
            let title = TextMatch.normalizeTitle(s.title)
            let artist = TextMatch.normalize(s.artist)
            return Entry(song: s, title: title, artist: artist, hay: "\(title) \(artist) \(TextMatch.normalize(s.album))")
        }
        for (i, e) in entries.enumerated() {
            byTitle[e.title, default: []].append(i)
            for w in TextMatch.tokens(e.title) { byWord[w, default: []].append(i) }
        }
    }

    func match(_ want: WantedSong) -> Song? {
        let title = TextMatch.normalizeTitle(want.title)
        if title.isEmpty { return nil }
        let artists = want.artists.map { TextMatch.normalize($0) }.filter { !$0.isEmpty }
        var cands = Set(byTitle[title] ?? [])
        let lists = TextMatch.tokens(title).compactMap { byWord[$0] }.sorted { $0.count < $1.count }.prefix(3)
        for l in lists { cands.formUnion(l) }
        var best: Entry?
        var bestScore = 0.0
        for i in cands.sorted() {
            let e = entries[i]
            let ts = TextMatch.similarity(title, e.title)
            if ts < 0.75 { continue }
            let artistScore: Double
            if e.artist.isEmpty || artists.isEmpty {
                artistScore = 0.5
            } else if artists.contains(where: { TextMatch.containsWords(e.artist, $0) || TextMatch.containsWords($0, e.artist) }) {
                artistScore = 1
            } else {
                artistScore = artists.map { TextMatch.similarity($0, e.artist) }.max() ?? 0
            }
            var s = 0.65 * ts + 0.35 * artistScore
            let local = e.song.durationMs
            if want.durationMs > 0 && local > 0 {
                let diff = abs(want.durationMs - local)
                if diff <= 3000 && artistScore >= 0.5 { s += 0.1 } else if diff > 20000 { s -= 0.15 }
            }
            if s > bestScore { bestScore = s; best = e }
        }
        return bestScore >= 0.8 ? best?.song : nil
    }

    /// Songs whose title/artist/album contain every word typed.
    func search(_ query: String, limit: Int = 300) -> [Song] {
        let words = TextMatch.tokens(TextMatch.normalizeTitle(query))
        if words.isEmpty { return [] }
        var out: [Song] = []
        for e in entries where words.allSatisfy({ e.hay.contains($0) }) {
            out.append(e.song)
            if out.count >= limit { break }
        }
        return out
    }
}
