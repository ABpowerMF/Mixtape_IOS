import Foundation
import Network

/// Settings that aren't about the look (those live in ThemeStore) or the sound (FxSettings).
enum Prefs {
    static let downloadQuality = "dl.quality"        // "best" or "small"
    static let downloadParallel = "dl.parallel"      // 1…4
    static let swipeMiniPlayer = "player.swipe"
    static let clockSideways = "clock.sideways"
    static let clockSeconds = "clock.seconds"
    static let clockDate = "clock.date"
    static let clockCover = "clock.cover"
    static let clockAccent = "clock.accent"
    static let clockSize = "clock.size"
    static let clockDim = "clock.dim"
    static let videoCovers = "video.covers"
    static let videoWifiOnly = "video.wifiOnly"
    static let artistInfo = "artist.info"
    static let lyricsOnline = "lyrics.online"
    static let tutorialSeen = "tutorial.seen"

    /// A yes/no setting that may never have been set (then [fallback]).
    static func bool(_ key: String, _ fallback: Bool) -> Bool {
        UserDefaults.standard.object(forKey: key) as? Bool ?? fallback
    }

    static func int(_ key: String, _ fallback: Int) -> Int {
        UserDefaults.standard.object(forKey: key) as? Int ?? fallback
    }

    static func double(_ key: String, _ fallback: Double) -> Double {
        UserDefaults.standard.object(forKey: key) as? Double ?? fallback
    }

    /// Every setting key that goes into a backup.
    static let backupKeys: [String] = [
        downloadQuality, downloadParallel, swipeMiniPlayer, clockSideways, clockSeconds, clockDate, clockCover,
        clockAccent, clockSize, clockDim, videoCovers, videoWifiOnly, artistInfo, lyricsOnline,
        "theme.id", "theme.rounded", "theme.scale", "theme.custom", "theme.font", "theme.animations",
        "theme.bgDim", "theme.bgBlur", "songs.sort", "albums.size", "fx", "stats.plays", "stats.ms",
    ]
}

/// Plays and listening time per song (for Stats).
enum Stats {
    static func record(_ song: Song) {
        var plays = UserDefaults.standard.dictionary(forKey: "stats.plays") as? [String: Int] ?? [:]
        plays[song.id, default: 0] += 1
        UserDefaults.standard.set(plays, forKey: "stats.plays")
    }

    static func plays() -> [String: Int] {
        UserDefaults.standard.dictionary(forKey: "stats.plays") as? [String: Int] ?? [:]
    }

    static func addListening(_ add: [String: Int]) {
        var ms = listening()
        for (id, v) in add { ms[id, default: 0] += v }
        UserDefaults.standard.set(ms, forKey: "stats.ms")
    }

    /// Milliseconds listened per song.
    static func listening() -> [String: Int] {
        UserDefaults.standard.dictionary(forKey: "stats.ms") as? [String: Int] ?? [:]
    }

    static func formatListened(_ ms: Int) -> String {
        let minutes = ms / 60_000
        if minutes < 60 { return "\(minutes) min" }
        let hours = minutes / 60
        return hours < 48 ? "\(hours) h \(minutes % 60) min" : "\(hours / 24) days \(hours % 24) h"
    }
}

/// Is the phone on Wi-Fi right now (for "video covers only on Wi-Fi").
final class NetworkWatch {
    static let shared = NetworkWatch()
    private let monitor = NWPathMonitor()
    private(set) var onWifi = true
    private(set) var online = true

    private init() {
        monitor.pathUpdateHandler = { [weak self] path in
            self?.onWifi = path.usesInterfaceType(.wifi) || path.usesInterfaceType(.wiredEthernet)
            self?.online = path.status == .satisfied
        }
        monitor.start(queue: DispatchQueue(label: "mixtape.network"))
    }
}
