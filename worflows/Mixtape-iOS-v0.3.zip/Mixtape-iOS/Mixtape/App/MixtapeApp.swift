import SwiftUI
import UIKit

@main
struct MixtapeApp: App {
    @StateObject private var model = AppModel()
    @StateObject private var nav = Nav()
    @Environment(\.scenePhase) private var phase

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(model)
                .environmentObject(model.theme)
                .environmentObject(model.player)
                .environmentObject(model.downloader)
                .environmentObject(model.updater)
                .environmentObject(nav)
                .onOpenURL { url in
                    if url.isFileURL { model.importFiles([url]) }
                }
        }
        .onChange(of: phase) { p in
            model.player.setVisible(p == .active)
            BackgroundVideo.shared.setActive(p == .active)
            if p == .active {
                Task {
                    await model.rescan()
                    await model.checkForUpdate()
                }
            }
        }
    }
}

enum Tab: String, CaseIterable {
    case songs, albums, playlists, download, settings

    var icon: String {
        switch self {
        case .songs: return "music.note"
        case .albums: return "square.grid.2x2"
        case .playlists: return "music.note.list"
        case .download: return "arrow.down.circle"
        case .settings: return "gearshape"
        }
    }
}

enum Route: Hashable {
    case album(String)
    case playlist(String)
}

/// Which tab is open, what's pushed on each, and the app-wide sheets.
@MainActor
final class Nav: ObservableObject {
    @Published var tab: Tab = .songs
    @Published var songsPath: [Route] = []
    @Published var albumsPath: [Route] = []
    @Published var playlistsPath: [Route] = []
    @Published var showPlayer = false
    @Published var addToPlaylist: [String]?
    @Published var lyricsFor: Song?
    @Published var confirmDelete: Song?
    @Published var showTutorial = false
    /// Clock mode: open, and how far it's turned (0, 90 or -90 degrees).
    @Published var showClock = false
    @Published var clockTurn = 0
    private var clockFromRotation = false

    func openClock(turn: Int, fromRotation: Bool = false) {
        clockTurn = turn
        clockFromRotation = fromRotation
        showClock = true
    }

    func closeClock() {
        showClock = false
        clockFromRotation = false
    }

    /// The phone was turned: open the clock when it's sideways (if that's on), close it when upright again.
    func orientationChanged(_ o: UIDeviceOrientation) {
        switch o {
        case .landscapeLeft, .landscapeRight:
            guard Prefs.bool(Prefs.clockSideways, false) else { return }
            openClock(turn: o == .landscapeLeft ? 90 : -90, fromRotation: true)
        case .portrait:
            if showClock && clockFromRotation { closeClock() }
        default:
            break
        }
    }

    func open(_ r: Route) {
        showPlayer = false
        switch tab {
        case .songs: songsPath.append(r)
        case .albums: albumsPath.append(r)
        case .playlists: playlistsPath.append(r)
        default:
            if case .album = r { tab = .albums; albumsPath = [r] } else { tab = .playlists; playlistsPath = [r] }
        }
    }
}
