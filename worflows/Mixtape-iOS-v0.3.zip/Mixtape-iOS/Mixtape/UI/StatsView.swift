import SwiftUI

/// Listening time, most listened songs and artists.
struct StatsView: View {
    @EnvironmentObject var model: AppModel
    @EnvironmentObject var theme: ThemeStore

    private struct Row: Identifiable {
        let id: String
        let title: String
        let subtitle: String
        let ms: Int
        let song: Song?
    }

    var body: some View {
        let listened = Stats.listening()
        let plays = Stats.plays()
        let total = listened.values.reduce(0, +)
        let songs = topSongs(listened, plays)
        let artists = topArtists(listened)
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 0) {
                Header(title: "stats", subtitle: "Listening time: \(Stats.formatListened(total))")
                if songs.isEmpty {
                    Text("Play some music and your most listened songs and artists show up here.")
                        .font(theme.font(13)).foregroundColor(theme.p.fog).padding(16)
                }
                if !songs.isEmpty {
                    SectionTitle(text: "most listened songs")
                    ForEach(Array(songs.enumerated()), id: \.element.id) { i, r in
                        HStack(spacing: 12) {
                            Text("\(i + 1)").font(theme.font(12)).foregroundColor(theme.p.fog).frame(width: 24)
                            CoverView(song: r.song, size: 40)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(r.title).font(theme.font(14, .medium)).foregroundColor(theme.p.paper).lineLimit(1)
                                Text(r.subtitle).font(theme.font(12)).foregroundColor(theme.p.fog).lineLimit(1)
                            }
                            Spacer()
                            Text(Stats.formatListened(r.ms)).font(theme.font(11)).foregroundColor(theme.p.tape)
                        }
                        .padding(.horizontal, 16).padding(.vertical, 4)
                    }
                }
                if !artists.isEmpty {
                    SectionTitle(text: "most listened artists")
                    ForEach(Array(artists.enumerated()), id: \.element.id) { i, r in
                        HStack(spacing: 12) {
                            Text("\(i + 1)").font(theme.font(12)).foregroundColor(theme.p.fog).frame(width: 24)
                            Text(r.title).font(theme.font(14, .medium)).foregroundColor(theme.p.paper).lineLimit(1)
                            Spacer()
                            Text(Stats.formatListened(r.ms)).font(theme.font(11)).foregroundColor(theme.p.tape)
                        }
                        .padding(.horizontal, 16).padding(.vertical, 8)
                    }
                }
            }
            .padding(.bottom, 24)
        }
        .mixScreen(theme)
        .navigationBarTitleDisplayMode(.inline)
    }

    private func topSongs(_ listened: [String: Int], _ plays: [String: Int]) -> [Row] {
        var rows: [Row] = []
        for (id, ms) in listened where ms > 0 {
            let s = model.song(id)
            let count = plays[id] ?? 0
            let title = s?.title ?? ((id as NSString).lastPathComponent as String)
            let artist = s?.displayArtist ?? "Not on the phone anymore"
            rows.append(Row(id: id, title: title, subtitle: count > 0 ? "\(artist) · \(count) plays" : artist, ms: ms, song: s))
        }
        rows.sort { (a: Row, b: Row) -> Bool in a.ms > b.ms }
        return Array(rows.prefix(25))
    }

    private func topArtists(_ listened: [String: Int]) -> [Row] {
        var byArtist: [String: Int] = [:]
        for (id, ms) in listened {
            guard let s = model.song(id), !s.mainArtist.isEmpty else { continue }
            byArtist[s.mainArtist, default: 0] += ms
        }
        var rows: [Row] = []
        for (name, ms) in byArtist { rows.append(Row(id: name, title: name, subtitle: "", ms: ms, song: nil)) }
        rows.sort { (a: Row, b: Row) -> Bool in a.ms > b.ms }
        return Array(rows.prefix(15))
    }
}
