import SwiftUI

struct PlaylistsView: View {
    @EnvironmentObject var model: AppModel
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var nav: Nav
    @State private var query = ""
    @State private var showImport = false
    @State private var showNew = false
    @State private var newName = ""

    private var lists: [Playlist] {
        let q = TextMatch.normalize(query)
        return q.isEmpty ? model.playlists : model.playlists.filter { TextMatch.normalize($0.name).contains(q) }
    }

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 0) {
                Header(title: "playlists", subtitle: "\(model.playlists.count) playlists")
                HStack(spacing: 8) {
                    MixButton(label: "import from spotify", icon: "link", primary: true) { showImport = true }
                    MixButton(label: "new", icon: "plus") { showNew = true }
                }
                .padding(.horizontal, 16).padding(.top, 12)
                if model.playlists.count > 6 {
                    SearchField(placeholder: "Search playlists", text: $query, slim: true).padding(.top, 12)
                }
                if model.playlists.isEmpty {
                    Text("Paste a Spotify playlist link: Mixtape finds those songs on your phone, and can download the ones you don't have.")
                        .font(theme.font(13)).foregroundColor(theme.p.fog).padding(16)
                }
                ForEach(lists) { p in
                    NavigationLink(value: Route.playlist(p.id)) {
                        HStack(spacing: 12) {
                            RemoteCover(url: p.image, fallback: model.song(p.entries.first(where: { $0.songId != nil })?.songId), title: p.name, size: 56)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(p.name).font(theme.font(15, .medium)).foregroundColor(theme.p.paper).lineLimit(1)
                                Text(p.isOwn ? "\(p.entries.count) songs · yours" : "\(p.matchedCount)/\(p.entries.count) on your phone · \(p.kind)")
                                    .font(theme.font(12)).foregroundColor(theme.p.fog).lineLimit(1)
                            }
                            Spacer()
                            Image(systemName: "chevron.right").font(.system(size: 12)).foregroundColor(theme.p.gap)
                        }
                        .padding(.horizontal, 16).padding(.vertical, 6)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .contextMenu {
                        Button { model.play(playlist: p) } label: { Label("Play", systemImage: "play") }
                        Button { model.play(playlist: p, shuffled: true) } label: { Label("Shuffle", systemImage: "shuffle") }
                        Button(role: .destructive) { model.deletePlaylist(p.id) } label: { Label("Delete playlist", systemImage: "trash") }
                    }
                }
            }
            .padding(.bottom, 16)
        }
        .scrollDismissesKeyboard(.immediately)
        .mixScreen(theme)
        .toolbar(.hidden, for: .navigationBar)
        .sheet(isPresented: $showImport) { ImportSheet().mixEnvironment(model, nav) }
        .alert("New playlist", isPresented: $showNew) {
            TextField("Name", text: $newName)
            Button("Create") {
                let p = model.createPlaylist(newName)
                newName = ""
                nav.playlistsPath.append(.playlist(p.id))
            }
            Button("Cancel", role: .cancel) { newName = "" }
        }
    }
}

/// Paste a Spotify link → playlist. With a short guide on where to find the link.
struct ImportSheet: View {
    @EnvironmentObject var model: AppModel
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var nav: Nav
    @Environment(\.dismiss) var dismiss
    @State private var link = ""
    @State private var busy = false
    @State private var error: String?
    @State private var showHelp = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    Text("Paste a link to a public Spotify playlist, album or song.")
                        .font(theme.font(14)).foregroundColor(theme.p.paper)
                    TextField("", text: $link, prompt: Text("https://open.spotify.com/playlist/…").foregroundColor(theme.p.fog))
                        .font(theme.font(14)).foregroundColor(theme.p.paper)
                        .autocorrectionDisabled().textInputAutocapitalization(.never)
                        .keyboardType(.URL)
                        .padding(12)
                        .background(RoundedRectangle(cornerRadius: theme.corner).fill(theme.p.raised))
                    HStack(spacing: 10) {
                        PasteButton(payloadType: String.self) { strings in
                            if let s = strings.first { link = s.trimmed }
                        }
                        .buttonBorderShape(.capsule)
                        .tint(theme.p.raised)
                        MixButton(label: busy ? "reading…" : "import", icon: "arrow.down.doc", primary: true) { go() }
                            .disabled(busy || link.trimmed.isEmpty)
                        if busy { ProgressView().tint(theme.p.tape) }
                    }
                    if let e = error {
                        Text(e).font(theme.font(13)).foregroundColor(theme.p.alert)
                    }
                    Button { withAnimation(theme.anim()) { showHelp.toggle() } } label: {
                        HStack {
                            Text(theme.head("where do I find the link?")).font(theme.font(13, .semibold)).foregroundColor(theme.p.tape)
                            Image(systemName: showHelp ? "chevron.up" : "chevron.down").font(.system(size: 11)).foregroundColor(theme.p.tape)
                        }
                    }
                    .buttonStyle(.plain)
                    if showHelp {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("1. Open the playlist in Spotify.")
                            Text("2. Tap ••• (or the share arrow) › Share › Copy link.")
                            Text("3. Come back here and tap Paste.")
                            Text("The playlist has to be public. Your own private ones: make them public for a moment, import, then make them private again.")
                                .foregroundColor(theme.p.fog)
                            Text("No Spotify account or Premium needed. Imports have no song limit.").foregroundColor(theme.p.fog)
                        }
                        .font(theme.font(13)).foregroundColor(theme.p.paper)
                    }
                }
                .padding(16)
            }
            .mixScreen(theme)
            .navigationTitle(theme.rounded ? "Import from Spotify" : "~/import")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Close") { dismiss() } } }
        }
        .tint(theme.p.tape)
        .presentationDetents([.medium, .large])
    }

    private func go() {
        busy = true
        error = nil
        Task {
            do {
                let p = try await model.importSpotify(link.trimmed)
                busy = false
                dismiss()
                model.show("\(p.name): \(p.matchedCount)/\(p.entries.count) songs found on your phone")
                nav.tab = .playlists
                nav.playlistsPath = [.playlist(p.id)]
            } catch {
                busy = false
                self.error = "Couldn't import: \(error.localizedDescription)"
            }
        }
    }
}
