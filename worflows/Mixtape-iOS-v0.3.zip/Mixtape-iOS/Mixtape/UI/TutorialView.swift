import SwiftUI

/// The three intro pages: shown on a fresh install, and again from Settings › Tutorial.
struct TutorialView: View {
    @EnvironmentObject var theme: ThemeStore
    @Environment(\.dismiss) var dismiss
    @State private var page = 0

    private struct Page {
        let icon: String
        let title: String
        let lines: [String]
    }

    private let pages: [Page] = [
        Page(icon: "music.note", title: "your music", lines: [
            "Mixtape plays the music files on your phone. No account, no ads.",
            "Add songs with Import files (Songs tab or Settings), or drop them into the Files app › On My iPhone › Mixtape.",
            "Sending a song with AirDrop or \"Open in…\" › Mixtape works too.",
        ]),
        Page(icon: "link", title: "spotify playlists", lines: [
            "Playlists tab › Import from Spotify, paste a playlist link (Share › Copy link in Spotify).",
            "Mixtape finds those songs on your phone. The ones you don't have get a download button, or tap Download missing.",
            "Downloads go into your Mixtape folder with title, artist and cover.",
        ]),
        Page(icon: "hand.draw", title: "little tricks", lines: [
            "Swipe a cover (or a playlist number) to the right to add the song to the queue.",
            "Hold a song for more: play next, add to a playlist, lyrics…",
            "Swipe the mini player left/right to change songs, up to open the player.",
            "Turn on Sideways clock mode in Settings, then turn the phone sideways.",
        ]),
    ]

    var body: some View {
        VStack(spacing: 0) {
            TabView(selection: $page) {
                ForEach(0..<pages.count, id: \.self) { i in
                    pageView(pages[i]).tag(i)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .always))
            HStack {
                Button(theme.btn("skip")) { finish() }
                    .font(theme.font(14)).foregroundColor(theme.p.fog)
                Spacer()
                MixButton(label: page == pages.count - 1 ? "start" : "next", primary: true) {
                    if page < pages.count - 1 {
                        withAnimation(theme.anim()) { page += 1 }
                    } else {
                        finish()
                    }
                }
            }
            .padding(20)
        }
        .background(ScreenBackground())
        .preferredColorScheme(theme.p.isLight ? .light : .dark)
    }

    private func pageView(_ p: Page) -> some View {
        VStack(alignment: .leading, spacing: 18) {
            Spacer()
            Image(systemName: p.icon).font(.system(size: 44, weight: .semibold)).foregroundColor(theme.p.tape)
            Text(theme.head(p.title)).font(theme.font(26, .bold)).foregroundColor(theme.p.paper)
            ForEach(p.lines, id: \.self) { line in
                Text(line).font(theme.font(15)).foregroundColor(theme.p.paper).fixedSize(horizontal: false, vertical: true)
            }
            Spacer()
            Spacer()
        }
        .padding(.horizontal, 28)
    }

    private func finish() {
        UserDefaults.standard.set(true, forKey: Prefs.tutorialSeen)
        dismiss()
    }
}
