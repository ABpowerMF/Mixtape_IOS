import SwiftUI

/// Equaliser and effects: presets, 5 bands, bass, volume boost, slowed / sped up, reverb, bitcrush, fades.
struct EqualizerView: View {
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var player: Player

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                topSection
                presetsSection
                bandsSection
                speedSection
                effectsSection
                fadeSection
                MixButton(label: "reset all", icon: "arrow.counterclockwise") { player.setFx(FxSettings()) }
                    .padding(16)
            }
            .padding(.bottom, 24)
        }
        .mixScreen(theme)
        .navigationBarTitleDisplayMode(.inline)
    }

    private var topSection: some View {
        VStack(alignment: .leading, spacing: 0) {
            Header(title: "equaliser")
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Equaliser").font(theme.font(15, .medium)).foregroundColor(theme.p.paper)
                    Text(player.fx.enabled ? "On. Changes apply straight away." : "Off. Turn it on with the switch.")
                        .font(theme.font(12)).foregroundColor(theme.p.fog)
                }
                Spacer()
                Toggle("", isOn: bind(\.enabled)).labelsHidden().tint(theme.p.tape)
            }
            .padding(.horizontal, 16).padding(.top, 12)
        }
    }

    private var presetsSection: some View {
        VStack(alignment: .leading, spacing: 0) {
            SectionTitle(text: "presets")
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(Fx.presets, id: \.0) { preset in
                        chip(preset.0, on: player.fx.preset == preset.0) { choosePreset(preset.0, preset.1) }
                    }
                    if player.fx.preset == "Custom" { chip("Custom", on: true) {} }
                }
                .padding(.horizontal, 16)
            }
        }
    }

    private var bandsSection: some View {
        let fx = player.fx
        return VStack(alignment: .leading, spacing: 0) {
            SectionTitle(text: "bands")
            ForEach(0..<Fx.freqs.count, id: \.self) { i in
                sliderRow("\(Fx.label(Fx.freqs[i])) Hz", value: bandBinding(i), range: -Fx.maxDb...Fx.maxDb, step: 0.5,
                          text: bandText(i), enabled: fx.enabled)
            }
            SectionTitle(text: "extras")
            sliderRow("Bass / depth", value: bind(\.bass), range: 0...1, step: 0.05,
                      text: "\(Int(fx.bass * 100))%", enabled: fx.enabled)
            sliderRow("Volume boost", value: bind(\.boost), range: 0...10, step: 0.5,
                      text: String(format: "+%.1f dB", fx.boost), enabled: fx.enabled)
        }
    }

    private var speedSection: some View {
        let fx = player.fx
        return VStack(alignment: .leading, spacing: 0) {
            SectionTitle(text: "slowed / sped up")
            sliderRow("Speed", value: bind(\.speed), range: 0.5...1.5, step: 0.05,
                      text: String(format: "%.2f×", fx.speed), enabled: true)
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Vinyl pitch").font(theme.font(14)).foregroundColor(theme.p.paper)
                    Text("On: the pitch drops with the speed (the classic slowed sound). Off: same pitch, just slower/faster.")
                        .font(theme.font(11)).foregroundColor(theme.p.fog)
                }
                Spacer()
                Toggle("", isOn: bind(\.vinyl)).labelsHidden().tint(theme.p.tape)
            }
            .padding(.horizontal, 16).padding(.vertical, 6)
        }
    }

    private var effectsSection: some View {
        let fx = player.fx
        return VStack(alignment: .leading, spacing: 0) {
            SectionTitle(text: "reverb")
            sliderRow("Reverb", value: bind(\.reverb), range: 0...1, step: 0.05,
                      text: fx.reverb <= 0 ? "off" : "\(Int(fx.reverb * 100))%", enabled: true)
            SectionTitle(text: "bitcrush")
            sliderRow("Crush", value: bind(\.bitcrush), range: 0...1, step: 0.05,
                      text: fx.bitcrush <= 0 ? "off" : "\(Int(fx.bitcrush * 100))%", enabled: true)
            Text("Lo-fi, old-console sound: grittier the further you go.")
                .font(theme.font(11)).foregroundColor(theme.p.fog).padding(.horizontal, 16)
        }
    }

    private var fadeSection: some View {
        let fx = player.fx
        return VStack(alignment: .leading, spacing: 0) {
            SectionTitle(text: "fade in & out")
            sliderRow("Fade length", value: bind(\.fadeSeconds), range: 0...10, step: 0.5,
                      text: fx.fadeSeconds <= 0 ? "off" : String(format: "%.1f s", fx.fadeSeconds), enabled: true)
            sliderRow("Crossfade", value: bind(\.crossfadeSeconds), range: 0...12, step: 0.5,
                      text: fx.crossfadeSeconds <= 0 ? "off" : String(format: "%.1f s", fx.crossfadeSeconds), enabled: true)
            Text("Fade: each song fades in at the start and out at the end. Crossfade: the next song starts while this one fades out.")
                .font(theme.font(11)).foregroundColor(theme.p.fog).padding(.horizontal, 16)
        }
    }

    private func bandText(_ i: Int) -> String {
        let v: Float = i < player.fx.bands.count ? player.fx.bands[i] : 0
        return String(format: "%+.1f dB", v)
    }

    private func choosePreset(_ name: String, _ bands: [Float]) {
        var f = player.fx
        f.preset = name
        f.bands = bands
        f.enabled = true
        player.setFx(f)
    }

    private func bind<T>(_ kp: WritableKeyPath<FxSettings, T>) -> Binding<T> {
        Binding(get: { player.fx[keyPath: kp] }, set: { v in
            var f = player.fx
            f[keyPath: kp] = v
            player.setFx(f)
        })
    }

    private func bandBinding(_ i: Int) -> Binding<Float> {
        Binding(get: { i < player.fx.bands.count ? player.fx.bands[i] : 0 }, set: { v in
            var f = player.fx
            if i < f.bands.count { f.bands[i] = v }
            f.preset = "Custom"
            player.setFx(f)
        })
    }

    private func chip(_ label: String, on: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(label)
                .font(theme.font(12, .semibold))
                .foregroundColor(on ? theme.p.ink : theme.p.paper)
                .padding(.horizontal, 12).padding(.vertical, 7)
                .background(RoundedRectangle(cornerRadius: theme.rounded ? 14 : 3).fill(on ? theme.p.tape : theme.p.raised))
        }
        .buttonStyle(.plain)
    }

    private func sliderRow(_ label: String, value: Binding<Float>, range: ClosedRange<Float>, step: Float,
                           text: String, enabled: Bool) -> some View {
        VStack(spacing: 2) {
            HStack {
                Text(label).font(theme.font(14)).foregroundColor(enabled ? theme.p.paper : theme.p.fog)
                Spacer()
                Text(text).font(theme.font(12)).foregroundColor(enabled ? theme.p.tape : theme.p.fog)
            }
            Slider(value: value, in: range, step: step).tint(theme.p.tape).disabled(!enabled)
        }
        .padding(.horizontal, 16).padding(.vertical, 4)
    }
}
