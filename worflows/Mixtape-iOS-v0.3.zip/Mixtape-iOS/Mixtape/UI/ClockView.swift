import SwiftUI
import UIKit

/// Clock mode: big clock, date and what's playing. Opens when you turn the phone sideways
/// (if "Sideways clock mode" is on) or from the player's menu. Keeps the screen on while open.
struct ClockView: View {
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var player: Player
    @EnvironmentObject var nav: Nav
    @AppStorage(Prefs.clockSeconds) private var seconds = false
    @AppStorage(Prefs.clockDate) private var showDate = true
    @AppStorage(Prefs.clockCover) private var showCover = true
    @AppStorage(Prefs.clockAccent) private var accent = false
    @AppStorage(Prefs.clockSize) private var size = 1.0
    @AppStorage(Prefs.clockDim) private var dim = 0.0

    var body: some View {
        GeometryReader { g in
            let sideways: Bool = nav.clockTurn != 0
            let w: CGFloat = sideways ? g.size.height : g.size.width
            let h: CGFloat = sideways ? g.size.width : g.size.height
            content(width: w, height: h)
                .frame(width: w, height: h)
                .rotationEffect(.degrees(Double(nav.clockTurn)))
                .frame(width: g.size.width, height: g.size.height)
        }
        .background(Color.black.ignoresSafeArea())
        .overlay(Color.black.opacity(dim).ignoresSafeArea().allowsHitTesting(false))
        .statusBar(hidden: true)
        .onAppear { UIApplication.shared.isIdleTimerDisabled = true }
        .onDisappear { UIApplication.shared.isIdleTimerDisabled = false }
    }

    private func content(width: CGFloat, height: CGFloat) -> some View {
        let byWidth: CGFloat = width / (seconds ? 5.2 : 3.6)
        let byHeight: CGFloat = height / 2.2
        let big: CGFloat = min(byWidth, byHeight) * CGFloat(size)
        return ZStack(alignment: .topTrailing) {
            VStack(spacing: 10) {
                Spacer(minLength: 0)
                timeBlock(big)
                Spacer(minLength: 0)
                nowPlayingBar
            }
            Button { nav.closeClock() } label: {
                Image(systemName: "xmark").font(.system(size: 16, weight: .semibold)).foregroundColor(theme.p.fog)
                    .frame(width: 44, height: 44)
            }
            .buttonStyle(.plain)
            .padding(8)
        }
    }

    private func timeBlock(_ big: CGFloat) -> some View {
        let color: Color = accent ? theme.p.tape : theme.p.paper
        let dateSize: CGFloat = max(14, big * 0.16)
        let interval: Double = seconds ? 1 : 15
        return TimelineView(.periodic(from: .now, by: interval)) { context in
            VStack(spacing: 4) {
                Text(timeText(context.date))
                    .font(.system(size: big, weight: .semibold, design: theme.rounded ? .rounded : .monospaced))
                    .monospacedDigit()
                    .foregroundColor(color)
                    .lineLimit(1)
                    .minimumScaleFactor(0.3)
                if showDate {
                    Text(dateText(context.date)).font(theme.font(dateSize)).foregroundColor(theme.p.fog)
                }
            }
        }
    }

    @ViewBuilder
    private var nowPlayingBar: some View {
        if let s = player.current {
            HStack(spacing: 12) {
                if showCover { CoverView(song: s, size: 54) }
                VStack(alignment: .leading, spacing: 2) {
                    Text(s.title).font(theme.font(15, .medium)).foregroundColor(theme.p.paper).lineLimit(1)
                    Text(s.displayArtist).font(theme.font(12)).foregroundColor(theme.p.fog).lineLimit(1)
                }
                Spacer()
                Button { player.previous() } label: { Image(systemName: "backward.fill").font(.system(size: 20)) }
                Button { player.toggle() } label: {
                    Image(systemName: player.isPlaying ? "pause.fill" : "play.fill").font(.system(size: 26))
                }
                .padding(.horizontal, 12)
                Button { player.next() } label: { Image(systemName: "forward.fill").font(.system(size: 20)) }
            }
            .buttonStyle(.plain)
            .foregroundColor(theme.p.paper)
            .padding(.horizontal, 28)
            .padding(.bottom, 18)
        }
    }

    private func timeText(_ d: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = seconds ? "HH:mm:ss" : "HH:mm"
        return f.string(from: d)
    }

    private func dateText(_ d: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "EEEE, d MMMM"
        return f.string(from: d)
    }
}

/// Clock options (shown in Settings when sideways clock mode is on).
struct ClockOptions: View {
    @EnvironmentObject var theme: ThemeStore
    @AppStorage(Prefs.clockSeconds) private var seconds = false
    @AppStorage(Prefs.clockDate) private var showDate = true
    @AppStorage(Prefs.clockCover) private var showCover = true
    @AppStorage(Prefs.clockAccent) private var accent = false
    @AppStorage(Prefs.clockSize) private var size = 1.0
    @AppStorage(Prefs.clockDim) private var dim = 0.0

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            SettingToggle(title: "Seconds", subtitle: "Show seconds", isOn: $seconds)
            SettingToggle(title: "Date", subtitle: "Show the day and date", isOn: $showDate)
            SettingToggle(title: "Cover", subtitle: "Show the cover of what's playing", isOn: $showCover)
            SettingToggle(title: "Accent colour", subtitle: "Clock in your accent colour", isOn: $accent)
            SettingSlider(title: "Clock size", value: $size, range: 0.6...1.4, text: "\(Int(size * 100))%")
                .padding(.horizontal, 16)
            SettingSlider(title: "Darken", value: $dim, range: 0...0.8, text: dim <= 0 ? "off" : "\(Int(dim * 100))%")
                .padding(.horizontal, 16)
        }
        .padding(.leading, 12)
    }
}
