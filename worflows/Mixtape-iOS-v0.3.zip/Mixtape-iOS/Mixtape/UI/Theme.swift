import SwiftUI
import UIKit

/// RGB colour used to build palettes (so contrast can be computed).
struct RGB: Equatable {
    var r: Double, g: Double, b: Double
    init(_ hex: UInt32) {
        r = Double((hex >> 16) & 0xff) / 255
        g = Double((hex >> 8) & 0xff) / 255
        b = Double(hex & 0xff) / 255
    }
    init(r: Double, g: Double, b: Double) { self.r = r; self.g = g; self.b = b }

    var color: Color { Color(red: r, green: g, blue: b) }
    var ui: UIColor { UIColor(red: r, green: g, blue: b, alpha: 1) }

    var luminance: Double {
        func ch(_ c: Double) -> Double { c <= 0.03928 ? c / 12.92 : pow((c + 0.055) / 1.055, 2.4) }
        return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b)
    }
    func lerp(_ o: RGB, _ t: Double) -> RGB { RGB(r: r + (o.r - r) * t, g: g + (o.g - g) * t, b: b + (o.b - b) * t) }
    static func contrast(_ a: RGB, _ b: RGB) -> Double {
        let la = a.luminance + 0.05, lb = b.luminance + 0.05
        return max(la, lb) / min(la, lb)
    }
    var hex: UInt32 {
        func c(_ v: Double) -> UInt32 { UInt32(max(0, min(255, (v * 255).rounded()))) }
        return c(r) << 16 | c(g) << 8 | c(b)
    }
}

/// The app's colours: background, panels, highlights, lines, text, dim text, accent, errors.
struct Palette {
    var ink: Color, deep: Color, raised: Color, gap: Color, paper: Color, fog: Color, tape: Color
    var alert = Color(red: 1, green: 0.37, blue: 0.34)
    var isLight: Bool

    /// Builds a full palette from three colours. Text and accent are nudged until they stand out from the
    /// background, so a theme can never make the app unreadable.
    static func from(_ background: UInt32, _ text: UInt32, _ accent: UInt32) -> Palette {
        let bg = RGB(background)
        var t = RGB(text)
        if RGB.contrast(t, bg) < 4.5 { t = bg.luminance > 0.5 ? RGB(0x111111) : RGB(0xF2F2F2) }
        var a = RGB(accent)
        var step = 0
        while RGB.contrast(a, bg) < 2.5 && step < 10 { a = a.lerp(t, 0.2); step += 1 }
        return Palette(ink: bg.color, deep: bg.lerp(t, 0.05).color, raised: bg.lerp(t, 0.10).color, gap: bg.lerp(t, 0.20).color,
                       paper: t.color, fog: bg.lerp(t, 0.55).color, tape: a.color, isLight: bg.luminance > 0.5)
    }
}

struct ThemeChoice: Identifiable {
    let id: String
    let name: String
    let colors: (UInt32, UInt32, UInt32)
}

struct FontChoice: Identifiable {
    let id: String
    let name: String
    /// A font family installed on every iPhone (nil = the system font in [design]).
    var family: String? = nil
    var design: Font.Design = .default
}

/// Theme, style (terminal or rounded), font, text size, animations and background picture/video.
final class ThemeStore: ObservableObject {
    static let choices: [ThemeChoice] = [
        ThemeChoice(id: "terminal", name: "Terminal", colors: (0x050805, 0xCFF5CF, 0x39FF6A)),
        ThemeChoice(id: "mono", name: "Black & white", colors: (0x000000, 0xF2F2F2, 0xFFFFFF)),
        ThemeChoice(id: "paper", name: "White & black", colors: (0xFFFFFF, 0x111111, 0x000000)),
        ThemeChoice(id: "greenwhite", name: "Green & white", colors: (0xFFFFFF, 0x102010, 0x16A34A)),
        ThemeChoice(id: "amber", name: "Amber", colors: (0x0A0700, 0xFFE2A8, 0xFFB000)),
        ThemeChoice(id: "night", name: "Night drive", colors: (0x16202E, 0xEAF0F7, 0xF2C14E)),
        ThemeChoice(id: "softlight", name: "Soft light", colors: (0xF2F2F7, 0x1C1C1E, 0x007AFF)),
        ThemeChoice(id: "softdark", name: "Soft dark", colors: (0x000000, 0xF2F2F7, 0x0A84FF)),
        ThemeChoice(id: "rose", name: "Rose", colors: (0x1A1014, 0xF7E8EE, 0xFF6FA3)),
    ]

    static let fonts: [FontChoice] = [
        FontChoice(id: "auto", name: "Matches the style"),
        FontChoice(id: "mono", name: "SF Mono", design: .monospaced),
        FontChoice(id: "rounded", name: "SF Rounded", design: .rounded),
        FontChoice(id: "system", name: "SF Pro", design: .default),
        FontChoice(id: "serif", name: "New York", design: .serif),
        FontChoice(id: "Menlo", name: "Menlo", family: "Menlo"),
        FontChoice(id: "Courier New", name: "Courier New", family: "Courier New"),
        FontChoice(id: "American Typewriter", name: "American Typewriter", family: "American Typewriter"),
        FontChoice(id: "Avenir Next", name: "Avenir Next", family: "Avenir Next"),
        FontChoice(id: "Futura", name: "Futura", family: "Futura"),
        FontChoice(id: "Gill Sans", name: "Gill Sans", family: "Gill Sans"),
        FontChoice(id: "Georgia", name: "Georgia", family: "Georgia"),
        FontChoice(id: "Didot", name: "Didot", family: "Didot"),
        FontChoice(id: "Chalkboard SE", name: "Chalkboard", family: "Chalkboard SE"),
        FontChoice(id: "Noteworthy", name: "Noteworthy", family: "Noteworthy"),
    ]

    @Published var themeId: String { didSet { save() } }
    @Published var rounded: Bool { didSet { save() } }
    @Published var textScale: Double { didSet { save() } }
    @Published var custom: (UInt32, UInt32, UInt32) { didSet { save() } }
    @Published var fontId: String { didSet { save() } }
    /// PostScript name of the font you imported (if any).
    @Published var customFontName: String? { didSet { save() } }
    @Published var animations: Bool { didSet { save(); UIView.setAnimationsEnabled(animations) } }
    /// "", "image" or "video".
    @Published private(set) var bgKind: String
    @Published var bgDim: Double { didSet { save() } }
    @Published var bgBlur: Double { didSet { save() } }
    /// Changes whenever a new background is picked (so it's reloaded).
    @Published private(set) var bgVersion = 0

    init() {
        let d = UserDefaults.standard
        themeId = d.string(forKey: "theme.id") ?? "terminal"
        rounded = d.bool(forKey: "theme.rounded")
        let s = d.double(forKey: "theme.scale")
        textScale = s > 0 ? s : 1
        let c = d.array(forKey: "theme.custom") as? [Int]
        custom = c.map { ($0.count == 3) ? (UInt32($0[0]), UInt32($0[1]), UInt32($0[2])) : (0x050805, 0xCFF5CF, 0x39FF6A) } ?? (0x050805, 0xCFF5CF, 0x39FF6A)
        fontId = d.string(forKey: "theme.font") ?? "auto"
        customFontName = FontImport.registerSaved()
        animations = d.object(forKey: "theme.animations") as? Bool ?? true
        bgKind = ThemeStore.currentBackgroundKind()
        bgDim = d.object(forKey: "theme.bgDim") as? Double ?? 0.5
        bgBlur = d.double(forKey: "theme.bgBlur")
        UIView.setAnimationsEnabled(animations)
    }

    /// Reads everything again (after a backup restore).
    func reload() {
        let d = UserDefaults.standard
        themeId = d.string(forKey: "theme.id") ?? "terminal"
        rounded = d.bool(forKey: "theme.rounded")
        let s = d.double(forKey: "theme.scale")
        textScale = s > 0 ? s : 1
        if let c = d.array(forKey: "theme.custom") as? [Int], c.count == 3 { custom = (UInt32(c[0]), UInt32(c[1]), UInt32(c[2])) }
        fontId = d.string(forKey: "theme.font") ?? "auto"
        animations = d.object(forKey: "theme.animations") as? Bool ?? true
        bgDim = d.object(forKey: "theme.bgDim") as? Double ?? 0.5
        bgBlur = d.double(forKey: "theme.bgBlur")
    }

    private func save() {
        let d = UserDefaults.standard
        d.set(themeId, forKey: "theme.id")
        d.set(rounded, forKey: "theme.rounded")
        d.set(textScale, forKey: "theme.scale")
        d.set([Int(custom.0), Int(custom.1), Int(custom.2)], forKey: "theme.custom")
        d.set(fontId, forKey: "theme.font")
        d.set(animations, forKey: "theme.animations")
        d.set(bgDim, forKey: "theme.bgDim")
        d.set(bgBlur, forKey: "theme.bgBlur")
    }

    private var cachedKey = ""
    private var cached: Palette?

    /// The current colours (worked out once per theme change, not on every redraw).
    var p: Palette {
        let key = "\(themeId)|\(custom.0)|\(custom.1)|\(custom.2)"
        if key == cachedKey, let c = cached { return c }
        let palette: Palette
        if themeId == "custom" {
            palette = Palette.from(custom.0, custom.1, custom.2)
        } else {
            let c = ThemeStore.choices.first { $0.id == themeId } ?? ThemeStore.choices[0]
            palette = Palette.from(c.colors.0, c.colors.1, c.colors.2)
        }
        cachedKey = key
        cached = palette
        return palette
    }

    var fontName: String {
        if fontId == "custom" { return customFontName == nil ? "Your font" : "Your font" }
        return ThemeStore.fonts.first { $0.id == fontId }?.name ?? "Matches the style"
    }

    func font(_ size: CGFloat, _ weight: Font.Weight = .regular) -> Font {
        let scaled: CGFloat = size * CGFloat(textScale)
        if fontId == "custom", let name = customFontName {
            return Font.custom(name, size: scaled).weight(weight)
        }
        if let choice = ThemeStore.fonts.first(where: { $0.id == fontId }), fontId != "auto" {
            if let family = choice.family { return Font.custom(family, size: scaled).weight(weight) }
            return .system(size: scaled, weight: weight, design: choice.design)
        }
        return .system(size: scaled, weight: weight, design: rounded ? .rounded : .monospaced)
    }

    /// The same font in a given size, for previews in the font list.
    func preview(_ choice: FontChoice, size: CGFloat) -> Font {
        if choice.id == "custom", let name = customFontName { return Font.custom(name, size: size) }
        if let family = choice.family { return Font.custom(family, size: size) }
        if choice.id == "auto" { return .system(size: size, design: rounded ? .rounded : .monospaced) }
        return .system(size: size, design: choice.design)
    }

    /// Corner radius: square-ish for terminal, round for the Apple style.
    var corner: CGFloat { rounded ? 14 : 4 }
    var coverCorner: CGFloat { rounded ? 10 : 3 }

    private func cap(_ s: String) -> String { s.prefix(1).uppercased() + s.dropFirst() }
    func path(_ name: String) -> String { rounded ? cap(name) : "~/\(name)" }
    func btn(_ label: String) -> String { rounded ? cap(label) : "[ \(label) ]" }
    func head(_ text: String) -> String { rounded ? cap(text) : "> \(text)" }

    /// Animation that respects the "Animations" setting.
    func anim(_ a: Animation = .easeInOut(duration: 0.25)) -> Animation? { animations ? a : nil }

    // MARK: - Background picture / video

    static var bgImageURL: URL { Store.dataFolder.appendingPathComponent("background.jpg") }
    static var bgVideoURL: URL { Store.dataFolder.appendingPathComponent("background.mov") }

    static func currentBackgroundKind() -> String {
        let fm = FileManager.default
        if fm.fileExists(atPath: bgVideoURL.path) { return "video" }
        if fm.fileExists(atPath: bgImageURL.path) { return "image" }
        return ""
    }

    func setBackgroundImage(_ data: Data) -> Bool {
        guard let img = UIImage(data: data) else { return false }
        let small = Artwork.resize(img, to: 2000)
        guard let jpg = small.jpegData(compressionQuality: 0.88) else { return false }
        try? FileManager.default.removeItem(at: ThemeStore.bgVideoURL)
        do { try jpg.write(to: ThemeStore.bgImageURL, options: .atomic) } catch { return false }
        bgKind = "image"
        bgVersion += 1
        return true
    }

    func setBackgroundVideo(_ data: Data) -> Bool {
        try? FileManager.default.removeItem(at: ThemeStore.bgImageURL)
        do { try data.write(to: ThemeStore.bgVideoURL, options: .atomic) } catch { return false }
        bgKind = "video"
        bgVersion += 1
        return true
    }

    func clearBackground() {
        try? FileManager.default.removeItem(at: ThemeStore.bgImageURL)
        try? FileManager.default.removeItem(at: ThemeStore.bgVideoURL)
        bgKind = ""
        bgVersion += 1
    }
}
