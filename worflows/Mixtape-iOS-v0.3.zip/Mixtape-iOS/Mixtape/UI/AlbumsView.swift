import SwiftUI

struct AlbumsView: View {
    @EnvironmentObject var model: AppModel
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var nav: Nav
    @State private var query = ""
    @AppStorage("albums.size") private var size = 1

    private var albums: [Album] {
        let q = TextMatch.normalize(query)
        if q.isEmpty { return model.albums }
        return model.albums.filter { TextMatch.normalize("\($0.name) \($0.artist)").contains(q) }
    }

    var body: some View {
        let side: CGFloat = [110, 160, 330][max(0, min(2, size))]
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                Header(title: "albums", subtitle: "\(model.albums.count) albums")
                SearchField(placeholder: "Search albums", text: $query).padding(.top, 10)
                HStack(spacing: 6) {
                    ForEach(0..<3) { i in
                        Button { size = i } label: {
                            Text(["S", "M", "L"][i])
                                .font(theme.font(12, .semibold))
                                .foregroundColor(size == i ? theme.p.ink : theme.p.fog)
                                .frame(width: 30, height: 24)
                                .background(RoundedRectangle(cornerRadius: theme.rounded ? 12 : 3).fill(size == i ? theme.p.tape : theme.p.raised))
                        }
                        .buttonStyle(.plain)
                    }
                    Spacer()
                }
                .padding(.horizontal, 16).padding(.vertical, 10)
                if model.albums.isEmpty {
                    Text("Songs with an album tag show up here.")
                        .font(theme.font(13)).foregroundColor(theme.p.fog).padding(16)
                }
                LazyVGrid(columns: [GridItem(.adaptive(minimum: side, maximum: side + side * 0.4), spacing: 14)], spacing: 18) {
                    ForEach(albums) { a in
                        NavigationLink(value: Route.album(a.id)) {
                            VStack(alignment: .leading, spacing: 4) {
                                GeometryReader { g in
                                    CoverView(song: a.songs.first(where: { $0.hasArt }) ?? a.songs.first, size: g.size.width)
                                }
                                .aspectRatio(1, contentMode: .fit)
                                Text(a.name).font(theme.font(13, .medium)).foregroundColor(theme.p.paper).lineLimit(1)
                                Text(a.artist).font(theme.font(11)).foregroundColor(theme.p.fog).lineLimit(1)
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 16)
                .animation(theme.anim(), value: size)
            }
            .padding(.bottom, 16)
        }
        .scrollDismissesKeyboard(.immediately)
        .mixScreen(theme)
        .toolbar(.hidden, for: .navigationBar)
    }
}

struct AlbumView: View {
    @EnvironmentObject var model: AppModel
    @EnvironmentObject var theme: ThemeStore
    let albumId: String

    var body: some View {
        if let a = model.albums.first(where: { $0.id == albumId }) {
            ScrollView {
                VStack(spacing: 0) {
                    CoverView(song: a.songs.first(where: { $0.hasArt }) ?? a.songs.first, size: 230)
                        .shadow(color: .black.opacity(0.35), radius: 14, y: 6)
                        .padding(.top, 12)
                    Text(a.name).font(theme.font(20, .bold)).foregroundColor(theme.p.paper)
                        .multilineTextAlignment(.center).padding(.top, 14).padding(.horizontal, 16)
                    Text(a.artist).font(theme.font(14)).foregroundColor(theme.p.fog).padding(.top, 2)
                    Text("\(a.songs.count) songs · \(formatTime(a.songs.reduce(0) { $0 + $1.durationMs }))")
                        .font(theme.font(12)).foregroundColor(theme.p.fog).padding(.top, 2)
                    HStack(spacing: 10) {
                        MixButton(label: "play", icon: "play.fill", primary: true) { model.play(a.songs, start: 0, source: a.name, shuffled: false) }
                        MixButton(label: "shuffle", icon: "shuffle") { model.play(a.songs, start: -1, source: a.name, shuffled: true) }
                    }
                    .padding(.vertical, 14)
                    LazyVStack(spacing: 0) {
                        ForEach(Array(a.songs.enumerated()), id: \.element.id) { i, s in
                            SongRow(song: s, number: s.trackNo > 0 ? s.trackNo : i + 1, showCover: false) {
                                model.play(a.songs, start: i, source: a.name)
                            }
                        }
                    }
                }
                .padding(.bottom, 16)
            }
            .mixScreen(theme)
            .navigationBarTitleDisplayMode(.inline)
        } else {
            Text("This album is gone.").font(theme.font(14)).foregroundColor(theme.p.fog)
                .frame(maxWidth: .infinity, maxHeight: .infinity).mixScreen(theme)
        }
    }
}
