import SwiftUI

/// Type a song, or paste a YouTube / YouTube Music / Spotify link.
struct DownloadView: View {
    @EnvironmentObject var model: AppModel
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var downloader: Downloader
    @EnvironmentObject var nav: Nav
    @State private var text = ""
    @State private var results: [YTHit] = []
    @State private var searching = false
    @State private var message: String?
    @FocusState private var focused: Bool

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 0) {
                Header(title: "download", subtitle: "Songs are saved as .m4a in your Mixtape folder")
                HStack(spacing: 8) {
                    HStack(spacing: 8) {
                        Image(systemName: "magnifyingglass").foregroundColor(theme.p.fog)
                        TextField("", text: $text, prompt: Text("Song name, or a YouTube / Spotify link").foregroundColor(theme.p.fog))
                            .font(theme.font(15)).foregroundColor(theme.p.paper)
                            .autocorrectionDisabled().textInputAutocapitalization(.never)
                            .submitLabel(.go)
                            .focused($focused)
                            .onSubmit(go)
                        if !text.isEmpty {
                            Button { text = ""; results = [] } label: { Image(systemName: "xmark.circle.fill").foregroundColor(theme.p.fog) }
                                .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, 10).frame(height: 42)
                    .background(RoundedRectangle(cornerRadius: theme.rounded ? 12 : 4).fill(theme.p.raised))
                    PasteButton(payloadType: String.self) { s in
                        if let first = s.first { text = first.trimmed; go() }
                    }
                    .labelStyle(.iconOnly)
                    .buttonBorderShape(.roundedRectangle)
                    .tint(theme.p.raised)
                }
                .padding(.horizontal, 16).padding(.top, 12)

                HStack(spacing: 10) {
                    MixButton(label: searching ? "searching…" : "search", icon: "magnifyingglass", primary: true, action: go)
                        .disabled(searching || text.trimmed.isEmpty)
                    if searching { ProgressView().tint(theme.p.tape) }
                }
                .padding(.horizontal, 16).padding(.top, 10)

                if let m = message {
                    Text(m).font(theme.font(13)).foregroundColor(theme.p.fog).padding(.horizontal, 16).padding(.top, 10)
                }

                if !results.isEmpty {
                    SectionTitle(text: "results")
                    ForEach(results) { hit in resultRow(hit) }
                }

                if !downloader.jobs.isEmpty {
                    HStack {
                        SectionTitle(text: "downloads")
                        Spacer()
                        if downloader.jobs.contains(where: { $0.status.finished }) {
                            Button(theme.btn("clear finished")) { downloader.clearFinished() }
                                .font(theme.font(12)).foregroundColor(theme.p.tape).padding(.trailing, 16).padding(.top, 12)
                        }
                    }
                    ForEach(downloader.jobs.reversed()) { job in jobRow(job) }
                    if downloader.activeCount > 0 {
                        MixButton(label: "cancel all", icon: "xmark") { downloader.cancelAll() }.padding(16)
                    }
                }

                if results.isEmpty && downloader.jobs.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(theme.head("how it works")).font(theme.font(13, .semibold)).foregroundColor(theme.p.tape)
                        Text("• Type a song and pick the right result.")
                        Text("• Paste a YouTube or YouTube Music link to get that exact video's audio.")
                        Text("• Paste a Spotify playlist, album or song link: it's imported to your playlists and the songs you don't have are downloaded.")
                        Text("Downloads keep going while you use the app. Keep Mixtape open until they finish: iPhones pause apps in the background.")
                            .foregroundColor(theme.p.fog)
                    }
                    .font(theme.font(13)).foregroundColor(theme.p.paper)
                    .padding(16)
                }
            }
            .padding(.bottom, 16)
        }
        .scrollDismissesKeyboard(.immediately)
        .mixScreen(theme)
        .toolbar(.hidden, for: .navigationBar)
    }

    private func resultRow(_ hit: YTHit) -> some View {
        HStack(spacing: 12) {
            RemoteCover(url: hit.thumbnail, title: hit.title, size: 48)
            VStack(alignment: .leading, spacing: 3) {
                Text(hit.title).font(theme.font(14, .medium)).foregroundColor(theme.p.paper).lineLimit(1)
                Text(resultLine(hit))
                    .font(theme.font(12)).foregroundColor(theme.p.fog).lineLimit(1)
            }
            Spacer()
            Button {
                downloader.enqueue([DownloadRequest(title: hit.title, artist: hit.artist, album: hit.album, durationMs: hit.durationMs,
                                                    videoId: hit.videoId, coverURL: hit.thumbnail)])
                model.show("Downloading \(hit.title)")
            } label: {
                Image(systemName: "arrow.down.circle.fill").font(.system(size: 26)).foregroundColor(theme.p.tape)
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 16).padding(.vertical, 5)
    }

    private func resultLine(_ hit: YTHit) -> String {
        var parts: [String] = []
        if !hit.artist.isEmpty { parts.append(hit.artist) }
        if !hit.album.isEmpty { parts.append(hit.album) }
        if hit.durationMs > 0 { parts.append(formatTime(hit.durationMs)) }
        return parts.joined(separator: " · ")
    }

    private func jobRow(_ job: DownloadJob) -> some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text(job.request.label).font(theme.font(14, .medium)).foregroundColor(theme.p.paper).lineLimit(1)
                switch job.status {
                case .queued: Text("waiting").font(theme.font(11)).foregroundColor(theme.p.fog)
                case .searching: Text("finding it on YouTube…").font(theme.font(11)).foregroundColor(theme.p.fog)
                case .downloading:
                    ProgressView(value: job.progress).tint(theme.p.tape)
                case .saving: Text("adding tags and cover…").font(theme.font(11)).foregroundColor(theme.p.fog)
                case .done: Text("done").font(theme.font(11)).foregroundColor(theme.p.tape)
                case .failed(let why): Text(why).font(theme.font(11)).foregroundColor(theme.p.alert).lineLimit(3)
                case .canceled: Text("canceled").font(theme.font(11)).foregroundColor(theme.p.fog)
                }
            }
            Spacer()
            switch job.status {
            case .failed, .canceled:
                Button { downloader.retry(job.id) } label: { Image(systemName: "arrow.clockwise").foregroundColor(theme.p.tape) }
                    .buttonStyle(.plain)
            case .done:
                if let id = job.fileId, let s = model.song(id) {
                    Button { model.play([s], start: 0, source: "Downloads") } label: { Image(systemName: "play.circle").font(.system(size: 22)).foregroundColor(theme.p.tape) }
                        .buttonStyle(.plain)
                }
            default:
                Button { downloader.cancel(job.id) } label: { Image(systemName: "xmark.circle").foregroundColor(theme.p.fog) }
                    .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 16).padding(.vertical, 7)
    }

    private func go() {
        let t = text.trimmed
        guard !t.isEmpty else { return }
        focused = false
        message = nil
        if Spotify.parseLink(t) != nil {
            searching = true
            Task {
                do {
                    let p = try await model.importSpotify(t)
                    searching = false
                    let missing = p.entries.filter { $0.songId == nil }.count
                    message = "\(p.name): \(p.matchedCount) already on your phone, downloading \(missing)."
                    model.download(missingIn: p.id)
                    text = ""
                } catch {
                    searching = false
                    message = "Couldn't read that Spotify link: \(error.localizedDescription)"
                }
            }
            return
        }
        if YouTubeSearch.isYouTubeLink(t) {
            guard let vid = YouTubeSearch.videoId(from: t) else {
                message = "That YouTube link has no video in it (playlists come in a later version)."
                return
            }
            searching = true
            Task {
                let info = await YouTubeSearch.describe(videoId: vid)
                searching = false
                downloader.enqueue([DownloadRequest(title: info.title, artist: info.artist, videoId: vid, coverURL: info.thumbnail)])
                model.show("Downloading \(info.title)")
                text = ""
            }
            return
        }
        searching = true
        Task {
            var hits = (try? await YouTubeSearch.music(t)) ?? []
            if hits.isEmpty { hits = (try? await YouTubeSearch.videos(t)) ?? [] }
            results = Array(hits.prefix(10))
            searching = false
            if hits.isEmpty { message = "Nothing found. Check your connection, or try other words." }
        }
    }
}
