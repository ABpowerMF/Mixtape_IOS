import SwiftUI
import UIKit
import AVFoundation
import CoreText

/// What's behind every screen: the theme colour, or your own picture / video (darkened, optionally blurred).
struct ScreenBackground: View {
    @EnvironmentObject var theme: ThemeStore

    var body: some View {
        ZStack {
            theme.p.ink
            if theme.bgKind == "image", let img = BackgroundImageCache.image(version: theme.bgVersion) {
                Color.clear
                    .overlay(Image(uiImage: img).resizable().scaledToFill())
                    .clipped()
                    .blur(radius: CGFloat(theme.bgBlur))
                theme.p.ink.opacity(theme.bgDim)
            } else if theme.bgKind == "video" {
                LoopingVideo(version: theme.bgVersion)
                if theme.bgBlur > 0 {
                    Rectangle().fill(.ultraThinMaterial).opacity(min(1, theme.bgBlur / 15))
                }
                theme.p.ink.opacity(theme.bgDim)
            }
        }
        .ignoresSafeArea()
    }
}

enum BackgroundImageCache {
    private static var cached: (Int, UIImage)?

    static func image(version: Int) -> UIImage? {
        if let c = cached, c.0 == version { return c.1 }
        guard let data = try? Data(contentsOf: ThemeStore.bgImageURL), let img = UIImage(data: data) else { return nil }
        cached = (version, img)
        return img
    }
}

/// One muted, looping player for the background video, shared by every screen.
final class BackgroundVideo {
    static let shared = BackgroundVideo()
    let player = AVQueuePlayer()
    private var looper: AVPlayerLooper?
    private var version = -1
    private var active = true

    init() {
        player.isMuted = true
        player.preventsDisplaySleepDuringVideoPlayback = false
    }

    func load(version: Int) {
        guard version != self.version else { return }
        self.version = version
        looper = nil
        player.removeAllItems()
        guard FileManager.default.fileExists(atPath: ThemeStore.bgVideoURL.path) else { return }
        let item = AVPlayerItem(url: ThemeStore.bgVideoURL)
        looper = AVPlayerLooper(player: player, templateItem: item)
        if active { player.play() }
    }

    /// Only plays while the app is on screen (battery).
    func setActive(_ on: Bool) {
        active = on
        if on && looper != nil { player.play() } else { player.pause() }
    }
}

final class PlayerLayerView: UIView {
    override class var layerClass: AnyClass { AVPlayerLayer.self }
    var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
}

struct LoopingVideo: UIViewRepresentable {
    let version: Int

    func makeUIView(context: Context) -> PlayerLayerView {
        let v = PlayerLayerView()
        v.playerLayer.videoGravity = .resizeAspectFill
        v.playerLayer.player = BackgroundVideo.shared.player
        BackgroundVideo.shared.load(version: version)
        return v
    }

    func updateUIView(_ v: PlayerLayerView, context: Context) {
        BackgroundVideo.shared.load(version: version)
    }
}

/// Fonts you import (.ttf / .otf), kept in the app and registered at every launch.
enum FontImport {
    static var folder: URL {
        let u = Store.dataFolder.appendingPathComponent("fonts", isDirectory: true)
        try? FileManager.default.createDirectory(at: u, withIntermediateDirectories: true)
        return u
    }

    private static func savedFile() -> URL? {
        let files = (try? FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: nil)) ?? []
        return files.first { ["ttf", "otf"].contains($0.pathExtension.lowercased()) }
    }

    /// Registers the saved font; returns its name (nil if there's none).
    static func registerSaved() -> String? {
        guard let file = savedFile() else { return nil }
        return register(file)
    }

    private static func register(_ url: URL) -> String? {
        guard let provider = CGDataProvider(url: url as CFURL), let cg = CGFont(provider),
              let name = cg.postScriptName as String? else { return nil }
        var error: Unmanaged<CFError>?
        _ = CTFontManagerRegisterFontsForURL(url as CFURL, .process, &error)
        return name
    }

    /// Copies a picked font into the app and registers it. Returns its name, or nil if it isn't a font.
    static func importFont(_ picked: URL) -> String? {
        let scoped = picked.startAccessingSecurityScopedResource()
        defer { if scoped { picked.stopAccessingSecurityScopedResource() } }
        let ext = picked.pathExtension.lowercased()
        guard ["ttf", "otf"].contains(ext) else { return nil }
        if let old = savedFile() {
            var error: Unmanaged<CFError>?
            _ = CTFontManagerUnregisterFontsForURL(old as CFURL, .process, &error)
            try? FileManager.default.removeItem(at: old)
        }
        let dest = folder.appendingPathComponent("font-\(Int(Date().timeIntervalSince1970)).\(ext)")
        do { try FileManager.default.copyItem(at: picked, to: dest) } catch { return nil }
        guard let name = register(dest) else {
            try? FileManager.default.removeItem(at: dest)
            return nil
        }
        return name
    }
}
