import SwiftUI

struct NowPlayingView: View {
    static let speeds: [(Float, String)] = [
        (0.8, "Slowed (0.8×)"), (0.9, "A bit slowed (0.9×)"), (1.0, "Normal"), (1.1, "Sped up (1.1×)"), (1.25, "Nightcore (1.25×)"),
    ]
    @EnvironmentObject var model: AppModel
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var player: Player
    @EnvironmentObject var nav: Nav
    @Environment(\.dismiss) var dismiss
    @State private var showQueue = false
    @State private var showLyrics = false
    @State private var showEq = false
    @State private var showArtist = false
    @State private var addIds: [String]?
    @State private var showSleep = false
    @State private var dragY: CGFloat = 0
    @State private var videoURL: URL?
    @AppStorage(Prefs.videoCovers) private var videoCovers = false
    @AppStorage(Prefs.videoWifiOnly) private var videoWifiOnly = true
    @AppStorage(Prefs.artistInfo) private var artistInfo = true

    var body: some View {
        let song = player.current
        GeometryReader { g in
            let byWidth: CGFloat = g.size.width - 48
            let byHeight: CGFloat = g.size.height * 0.46
            let art: CGFloat = min(byWidth, byHeight)
            VStack(spacing: 0) {
                topBar(song)
                Spacer(minLength: 6)
                cover(song, size: art)
                Spacer(minLength: 6)
                titles(song)
                Scrubber(clock: player.clock).padding(.horizontal, 24).padding(.top, 14)
                controls
                bottomRow(song)
            }
        }
        .background(playerBackground)
        .offset(y: dragY)
        .gesture(dismissDrag)
        .overlay {
            if nav.showClock {
                ClockView().transition(.opacity)
            }
        }
        .sheet(isPresented: $showQueue) { QueueView().mixEnvironment(model, nav) }
        .sheet(isPresented: $showLyrics) {
            if let s = song { LyricsView(song: s).mixEnvironment(model, nav) }
        }
        .sheet(isPresented: $showEq) {
            NavigationStack { EqualizerView() }.mixEnvironment(model, nav).tint(theme.p.tape)
        }
        .sheet(isPresented: $showArtist) {
            if let s = song { ArtistSheet(song: s).mixEnvironment(model, nav) }
        }
        .sheet(isPresented: Binding(get: { addIds != nil }, set: { if !$0 { addIds = nil } })) {
            AddToPlaylistSheet(ids: addIds ?? []).mixEnvironment(model, nav)
        }
        .confirmationDialog("Sleep timer", isPresented: $showSleep, titleVisibility: .visible) {
            ForEach([10, 15, 30, 45, 60, 90], id: \.self) { m in
                Button("\(m) minutes") { player.setSleep(minutes: m); model.show("Stops in \(m) minutes") }
            }
            if player.sleepAt != nil { Button("Turn off", role: .destructive) { player.setSleep(minutes: nil) } }
        }
        .task(id: song?.id ?? "") { await loadVideo(song) }
    }

    @ViewBuilder
    private var playerBackground: some View {
        if theme.bgKind.isEmpty {
            LinearGradient(colors: [theme.p.raised, theme.p.ink, theme.p.ink], startPoint: .top, endPoint: .bottom).ignoresSafeArea()
        } else {
            ScreenBackground()
        }
    }

    /// Drag the player down to close it.
    private var dismissDrag: some Gesture {
        DragGesture(minimumDistance: 15)
            .onChanged { v in
                let down: CGFloat = v.translation.height
                if down > 0 && down > abs(v.translation.width) { dragY = down }
            }
            .onEnded { v in
                let fast: Bool = v.predictedEndTranslation.height > 500
                if dragY > 140 || (fast && dragY > 40) {
                    dismiss()
                } else {
                    withAnimation(theme.anim(.spring(response: 0.3, dampingFraction: 0.85))) { dragY = 0 }
                }
            }
    }

    private func topBar(_ song: Song?) -> some View {
        HStack {
            Button { dismiss() } label: {
                Image(systemName: "chevron.down").font(.system(size: 18, weight: .semibold)).frame(width: 44, height: 44)
            }
            Spacer()
            VStack(spacing: 1) {
                Text(theme.rounded ? "Playing from" : "playing from").font(theme.font(10)).foregroundColor(theme.p.fog)
                Text(player.source.isEmpty ? "Mixtape" : player.source).font(theme.font(12, .semibold)).foregroundColor(theme.p.paper).lineLimit(1)
            }
            Spacer()
            Menu {
                if let s = song {
                    Button { addIds = [s.id] } label: { Label("Add to playlist", systemImage: "music.note.list") }
                    if let album = model.albums.first(where: { $0.id == s.albumKey }), !s.album.isEmpty {
                        Button { dismiss(); nav.open(.album(album.id)) } label: { Label("Go to album", systemImage: "square.stack") }
                    }
                    if artistInfo && !s.mainArtist.isEmpty {
                        Button { showArtist = true } label: { Label("About \(s.mainArtist)", systemImage: "person.crop.circle") }
                    }
                }
                Button { showEq = true } label: { Label("Equaliser & effects", systemImage: "slider.vertical.3") }
                Button { nav.openClock(turn: 0) } label: { Label("Clock mode", systemImage: "clock") }
                Button { showSleep = true } label: { Label(player.sleepAt == nil ? "Sleep timer" : "Sleep timer (on)", systemImage: "moon.zzz") }
            } label: {
                Image(systemName: "ellipsis").font(.system(size: 18, weight: .semibold)).frame(width: 44, height: 44)
            }
        }
        .foregroundColor(theme.p.paper)
        .padding(.horizontal, 8)
    }

    private func cover(_ song: Song?, size: CGFloat) -> some View {
        ZStack {
            CoverView(song: song, size: size)
            if let url = videoURL {
                VideoCoverView(url: url, playing: player.isPlaying)
                    .frame(width: size, height: size)
                    .clipShape(RoundedRectangle(cornerRadius: coverRadius(theme, size), style: .continuous))
                    .allowsHitTesting(false)
            }
        }
        .shadow(color: .black.opacity(0.4), radius: 20, y: 8)
        .gesture(DragGesture(minimumDistance: 25)
            .onChanged { v in
                let down: CGFloat = v.translation.height
                if down > 0 && down > abs(v.translation.width) { dragY = down }
            }
            .onEnded { v in
                let w: CGFloat = v.translation.width
                let h: CGFloat = v.translation.height
                if abs(w) > abs(h) {
                    if w < -60 { player.next() } else if w > 60 { player.previous() }
                } else if h < -70, artistInfo, song != nil {
                    showArtist = true
                }
                if dragY > 140 {
                    dismiss()
                } else {
                    withAnimation(theme.anim(.spring(response: 0.3, dampingFraction: 0.85))) { dragY = 0 }
                }
            })
    }

    private func titles(_ song: Song?) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(song?.title ?? "Nothing playing").font(theme.font(22, .bold)).foregroundColor(theme.p.paper).lineLimit(2)
            Text(song?.displayArtist ?? "").font(theme.font(15)).foregroundColor(theme.p.fog).lineLimit(1)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 24)
    }

    private var controls: some View {
        HStack {
            Button { player.setShuffle(!player.shuffle) } label: {
                Image(systemName: "shuffle").font(.system(size: 20)).foregroundColor(player.shuffle ? theme.p.tape : theme.p.fog)
            }
            Spacer()
            Button { player.previous() } label: { Image(systemName: "backward.fill").font(.system(size: 30)) }
            Spacer()
            Button { player.toggle() } label: {
                ZStack {
                    Circle().fill(theme.p.paper).frame(width: 72, height: 72)
                    Image(systemName: player.isPlaying ? "pause.fill" : "play.fill").font(.system(size: 30)).foregroundColor(theme.p.ink)
                        .offset(x: player.isPlaying ? 0 : 2)
                }
            }
            Spacer()
            Button { player.next() } label: { Image(systemName: "forward.fill").font(.system(size: 30)) }
            Spacer()
            Button { player.cycleRepeat() } label: {
                Image(systemName: player.repeatMode == .one ? "repeat.1" : "repeat").font(.system(size: 20))
                    .foregroundColor(player.repeatMode == .off ? theme.p.fog : theme.p.tape)
            }
        }
        .buttonStyle(.plain)
        .foregroundColor(theme.p.paper)
        .padding(.horizontal, 28)
        .padding(.top, 10)
    }

    private func bottomRow(_ song: Song?) -> some View {
        HStack {
            bottomButton("quote.bubble", "lyrics", on: false) { showLyrics = true }
            Spacer()
            Menu {
                ForEach(NowPlayingView.speeds, id: \.0) { v in
                    Button { player.setSpeed(v.0) } label: {
                        if player.speed == v.0 { Label(v.1, systemImage: "checkmark") } else { Text(v.1) }
                    }
                }
            } label: {
                VStack(spacing: 3) {
                    Image(systemName: "dial.low").font(.system(size: 18))
                    Text(player.speed == 1 ? "speed" : String(format: "%.2g×", player.speed)).font(theme.font(10))
                }
                .foregroundColor(player.speed == 1 ? theme.p.fog : theme.p.tape)
                .frame(width: 64)
            }
            Spacer()
            bottomButton("slider.vertical.3", "effects", on: player.fx.enabled || player.fx.reverb > 0 || player.fx.bitcrush > 0) { showEq = true }
            Spacer()
            bottomButton("list.bullet", "queue", on: false) { showQueue = true }
        }
        .padding(.horizontal, 22)
        .padding(.top, 18)
        .padding(.bottom, 12)
    }

    private func bottomButton(_ icon: String, _ label: String, on: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 3) {
                Image(systemName: icon).font(.system(size: 18))
                Text(label).font(theme.font(10))
            }
            .foregroundColor(on ? theme.p.tape : theme.p.fog)
            .frame(width: 64)
        }
        .buttonStyle(.plain)
    }

    private func loadVideo(_ song: Song?) async {
        videoURL = nil
        guard videoCovers, let s = song else { return }
        if videoWifiOnly && !NetworkWatch.shared.onWifi { return }
        videoURL = await VideoCovers.shared.url(for: s)
    }
}

/// About the artist: their Spotify photo and a short Wikipedia profile.
struct ArtistSheet: View {
    @EnvironmentObject var theme: ThemeStore
    @Environment(\.dismiss) var dismiss
    let song: Song
    @State private var info: ArtistInfo?
    @State private var loading = true

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    if loading {
                        ProgressView().tint(theme.p.tape).frame(maxWidth: .infinity).padding(.top, 60)
                    } else if let i = info {
                        if let img = i.image {
                            RemoteCover(url: img, title: i.name, size: 260)
                                .frame(maxWidth: .infinity)
                        }
                        Text(i.name).font(theme.font(24, .bold)).foregroundColor(theme.p.paper)
                        if !i.description.isEmpty {
                            Text(i.description).font(theme.font(13)).foregroundColor(theme.p.tape)
                        }
                        if !i.extract.isEmpty {
                            Text(i.extract).font(theme.font(15)).foregroundColor(theme.p.paper).lineSpacing(4)
                        }
                        if let page = i.pageURL, let url = URL(string: page) {
                            Link(destination: url) {
                                Text(theme.btn("read more on wikipedia")).font(theme.font(13, .semibold)).foregroundColor(theme.p.tape)
                            }
                        }
                    } else {
                        Text("Couldn't find anything about \(song.mainArtist).")
                            .font(theme.font(14)).foregroundColor(theme.p.fog).padding(.top, 40)
                    }
                }
                .padding(20)
            }
            .background(ScreenBackground())
            .navigationTitle(song.mainArtist)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Close") { dismiss() } } }
        }
        .tint(theme.p.tape)
        .preferredColorScheme(theme.p.isLight ? .light : .dark)
        .presentationDetents([.medium, .large])
        .task {
            info = await ArtistInfoRepo.fetch(song.mainArtist)
            loading = false
        }
    }
}

/// Draggable progress bar with times.
struct Scrubber: View {
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var player: Player
    @ObservedObject var clock: PlayerClock
    @State private var dragging: Double?

    var body: some View {
        let duration: Int = max(1, clock.durationMs)
        let playedNow: Double = Double(clock.positionMs) / Double(duration)
        let shown: Double = min(1, max(0, dragging ?? playedNow))
        let knob: CGFloat = dragging == nil ? 12 : 18
        let shownMs: Int = Int(shown * Double(duration))
        VStack(spacing: 6) {
            GeometryReader { g in
                let filled: CGFloat = g.size.width * CGFloat(shown)
                ZStack(alignment: .leading) {
                    Capsule().fill(theme.p.gap).frame(height: 4)
                    Capsule().fill(theme.p.tape).frame(width: filled, height: 4)
                    Circle().fill(theme.p.paper).frame(width: knob, height: knob)
                        .offset(x: filled - knob / 2)
                }
                .frame(height: 24)
                .contentShape(Rectangle())
                .gesture(DragGesture(minimumDistance: 0).onChanged { v in
                    let x: Double = Double(v.location.x / g.size.width)
                    dragging = min(1, max(0, x))
                }.onEnded { v in
                    let x: Double = Double(v.location.x / g.size.width)
                    let f: Double = min(1, max(0, x))
                    player.seek(to: Int(f * Double(duration)))
                    dragging = nil
                })
            }
            .frame(height: 24)
            HStack {
                Text(formatTime(shownMs)).font(theme.font(11)).foregroundColor(theme.p.fog)
                Spacer()
                Text("-" + formatTime(duration - shownMs)).font(theme.font(11)).foregroundColor(theme.p.fog)
            }
        }
    }
}
