import SwiftUI

/// Lyrics from LRCLIB. Synced ones follow the song (tap a line to jump there); you can paste your own.
struct LyricsView: View {
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var player: Player
    @Environment(\.dismiss) var dismiss
    let song: Song
    @State private var result: LyricsResult?
    @State private var loading = true
    @State private var failed: String?
    @State private var pasting = false
    @State private var pasted = ""

    var body: some View {
        NavigationStack {
            Group {
                if loading {
                    ProgressView().tint(theme.p.tape).frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if let r = result, !r.synced.isEmpty, player.currentId == song.id {
                    SyncedLyrics(lines: Lrc.parse(r.synced), clock: player.clock)
                } else if let r = result, !(r.plain.isEmpty && r.synced.isEmpty) {
                    ScrollView {
                        Text(r.plain.isEmpty ? Lrc.parse(r.synced).map { $0.text }.joined(separator: "\n") : r.plain)
                            .font(theme.font(17, .medium)).foregroundColor(theme.p.paper)
                            .lineSpacing(6)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(20)
                    }
                } else {
                    VStack(spacing: 14) {
                        Text(result?.instrumental == true ? "Instrumental." : (failed ?? "No lyrics found for this song."))
                            .font(theme.font(15)).foregroundColor(theme.p.fog).multilineTextAlignment(.center)
                        MixButton(label: "paste my own", icon: "doc.on.clipboard") { pasting = true }
                    }
                    .padding(24)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
            }
            .background(theme.p.ink.ignoresSafeArea())
            .navigationTitle(song.title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(theme.p.ink, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Close") { dismiss() } }
                ToolbarItem(placement: .primaryAction) {
                    Menu {
                        Button { pasted = result?.own == true ? (result?.synced.isEmpty == false ? result!.synced : result!.plain) : ""; pasting = true } label: {
                            Label("Paste my own lyrics", systemImage: "doc.on.clipboard")
                        }
                        if result?.own == true {
                            Button(role: .destructive) {
                                LyricsRepo.removeOwn(for: song)
                                Task { await load() }
                            } label: { Label("Remove my lyrics", systemImage: "trash") }
                        }
                    } label: { Image(systemName: "ellipsis.circle") }
                }
            }
        }
        .tint(theme.p.tape)
        .preferredColorScheme(theme.p.isLight ? .light : .dark)
        .task { await load() }
        .sheet(isPresented: $pasting) {
            NavigationStack {
                TextEditor(text: $pasted)
                    .font(theme.font(14))
                    .foregroundColor(theme.p.paper)
                    .scrollContentBackground(.hidden)
                    .padding(12)
                    .background(theme.p.ink.ignoresSafeArea())
                    .navigationTitle("Your lyrics")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) { Button("Cancel") { pasting = false } }
                        ToolbarItem(placement: .confirmationAction) {
                            Button("Save") {
                                if !pasted.trimmed.isEmpty { LyricsRepo.saveOwn(pasted, for: song) }
                                pasting = false
                                Task { await load() }
                            }
                        }
                    }
            }
            .tint(theme.p.tape)
        }
    }

    private func load() async {
        loading = true
        failed = nil
        do {
            result = try await LyricsRepo.fetch(for: song)
        } catch {
            failed = Prefs.bool(Prefs.lyricsOnline, true)
                ? "Couldn't reach the lyrics site (\(error.localizedDescription))."
                : "Finding lyrics online is off (Settings › Player). You can paste your own."
        }
        loading = false
    }
}

struct SyncedLyrics: View {
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var player: Player
    let lines: [LyricLine]
    @ObservedObject var clock: PlayerClock

    var body: some View {
        let current = Lrc.currentIndex(lines, clock.positionMs + 250)
        ScrollViewReader { proxy in
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    ForEach(Array(lines.enumerated()), id: \.offset) { i, line in
                        Text(line.text.isEmpty ? "♪" : line.text)
                            .font(theme.font(i == current ? 24 : 21, .bold))
                            .foregroundColor(i == current ? theme.p.tape : (i < current ? theme.p.fog : theme.p.paper.opacity(0.75)))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .id(i)
                            .onTapGesture { player.seek(to: line.timeMs) }
                    }
                }
                .padding(.horizontal, 22)
                .padding(.vertical, 200)
            }
            .onChange(of: current) { i in
                withAnimation(theme.anim(.easeInOut(duration: 0.35))) { proxy.scrollTo(max(0, i), anchor: .center) }
            }
            .onAppear { proxy.scrollTo(max(0, current), anchor: .center) }
        }
    }
}
