import SwiftUI
import UIKit
import PhotosUI
import UniformTypeIdentifiers

struct SettingsView: View {
    @EnvironmentObject var model: AppModel
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var player: Player
    @EnvironmentObject var nav: Nav

    private enum PickMode { case music, font, backup }
    @State private var picking = false
    @State private var pickMode: PickMode = .music
    @State private var colorsOpen = false
    @State private var styleOpen = false
    @State private var fontOpen = false
    @State private var pictureItem: PhotosPickerItem?
    @State private var videoItem: PhotosPickerItem?
    @State private var loadingBackground = false
    @State private var exporting = false
    @State private var backupDoc = BackupDocument(data: Data())
    @State private var showTutorial = false

    @AppStorage(Prefs.downloadQuality) private var quality = "best"
    @AppStorage(Prefs.downloadParallel) private var parallel = 2
    @AppStorage(Prefs.swipeMiniPlayer) private var swipeMini = true
    @AppStorage(Prefs.clockSideways) private var clockSideways = false
    @AppStorage(Prefs.videoCovers) private var videoCovers = false
    @AppStorage(Prefs.videoWifiOnly) private var videoWifiOnly = true
    @AppStorage(Prefs.artistInfo) private var artistInfo = true
    @AppStorage(Prefs.lyricsOnline) private var lyricsOnline = true

    private var version: String {
        let v = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "?"
        return "Mixtape for iPhone v\(v)"
    }

    private var allowedTypes: [UTType] {
        switch pickMode {
        case .music: return [.audio, .folder]
        case .font: return [.font, .data]
        case .backup: return [.json]
        }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                Header(title: "settings", subtitle: version)
                UpdatesSection()
                statsSection
                lookSection
                downloadsSection
                librarySection
                playerSection
                backupSection
                aboutSection
            }
            .padding(.bottom, 24)
        }
        .mixScreen(theme)
        .toolbar(.hidden, for: .navigationBar)
        .fileImporter(isPresented: $picking, allowedContentTypes: allowedTypes, allowsMultipleSelection: pickMode == .music) { result in
            guard case .success(let urls) = result, let first = urls.first else { return }
            switch pickMode {
            case .music:
                model.importFiles(urls)
            case .font:
                if let name = FontImport.importFont(first) {
                    theme.customFontName = name
                    theme.fontId = "custom"
                    model.show("Font added")
                } else {
                    model.show("That file isn't a font iPhones can read. Try a .ttf or .otf.")
                }
            case .backup:
                model.restoreBackup(first)
            }
        }
        .fileExporter(isPresented: $exporting, document: backupDoc, contentType: .json, defaultFilename: backupName()) { result in
            if case .success = result { model.show("Backup saved") }
        }
        .onChange(of: pictureItem) { item in loadBackground(item, video: false) }
        .onChange(of: videoItem) { item in loadBackground(item, video: true) }
        .fullScreenCover(isPresented: $showTutorial) { TutorialView().mixEnvironment(model, nav) }
    }

    // MARK: - Sections

    private var statsSection: some View {
        VStack(alignment: .leading, spacing: 0) {
            SectionTitle(text: "stats")
            let ms = Stats.listening().values.reduce(0, +)
            NavigationLink { StatsView() } label: {
                SettingRow(title: "Listening time: \(Stats.formatListened(ms))", subtitle: "Your most listened songs and artists") {
                    Text(theme.btn("open")).font(theme.font(13, .semibold)).foregroundColor(theme.p.tape)
                }
            }
            .buttonStyle(.plain)
        }
    }

    private var lookSection: some View {
        VStack(alignment: .leading, spacing: 0) {
            SectionTitle(text: "theme")
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(ThemeStore.choices) { c in swatch(id: c.id, name: c.name, colors: c.colors) }
                    swatch(id: "custom", name: "Custom", colors: theme.custom)
                }
                .padding(.horizontal, 16)
            }
            fold("custom colours", summary: theme.themeId == "custom" ? "in use" : "tap to open", open: $colorsOpen) {
                VStack(alignment: .leading, spacing: 10) {
                    colorRow("Accent", 2)
                    colorRow("Background", 0)
                    colorRow("Text", 1)
                    Text("Picking a colour switches to the Custom theme. Text and accent are adjusted if they'd be hard to read.")
                        .font(theme.font(11)).foregroundColor(theme.p.fog)
                }
            }

            SectionTitle(text: "background picture")
            VStack(alignment: .leading, spacing: 10) {
                Text(theme.bgKind.isEmpty ? "Use your own picture or video behind the whole app."
                     : (theme.bgKind == "video" ? "Using your video (it only plays while the app is open)." : "Using your picture."))
                    .font(theme.font(12)).foregroundColor(theme.p.fog)
                HStack(spacing: 8) {
                    PhotosPicker(selection: $pictureItem, matching: .images) { pickerLabel("picture", icon: "photo") }
                    PhotosPicker(selection: $videoItem, matching: .videos) { pickerLabel("video", icon: "film") }
                    if loadingBackground { ProgressView().tint(theme.p.tape) }
                }
                if !theme.bgKind.isEmpty {
                    Button { theme.clearBackground() } label: {
                        Text(theme.btn("remove background")).font(theme.font(13, .semibold)).foregroundColor(theme.p.alert)
                    }
                    .buttonStyle(.plain)
                    SettingSlider(title: "Darken", value: $theme.bgDim, range: 0...0.9, text: "\(Int(theme.bgDim * 100))%")
                    SettingSlider(title: "Blur", value: $theme.bgBlur, range: 0...30, text: theme.bgBlur <= 0 ? "off" : "\(Int(theme.bgBlur))")
                    Text("Darker keeps text easy to read. A video uses more battery than a picture.")
                        .font(theme.font(11)).foregroundColor(theme.p.fog)
                }
            }
            .padding(.horizontal, 16)

            fold("style", summary: theme.rounded ? "Rounded" : "Terminal", open: $styleOpen) {
                VStack(alignment: .leading, spacing: 8) {
                    choice("Terminal · square corners, [ brackets ], ~/titles", on: !theme.rounded) { theme.rounded = false }
                    choice("Rounded · soft corners and plain labels", on: theme.rounded) { theme.rounded = true }
                    SettingToggle(title: "Animations", subtitle: "Smooth transitions between screens, lists and the player", isOn: $theme.animations)
                    SettingSlider(title: "Text size", value: $theme.textScale, range: 0.85...1.25, text: "\(Int(theme.textScale * 100))%")
                    Text("For an Apple-like look: Rounded + the Soft light or Soft dark theme + SF Pro.")
                        .font(theme.font(11)).foregroundColor(theme.p.fog)
                }
            }

            fold("font", summary: theme.fontName, open: $fontOpen) {
                VStack(alignment: .leading, spacing: 2) {
                    ForEach(ThemeStore.fonts) { f in fontRow(f) }
                    if theme.customFontName != nil {
                        fontRow(FontChoice(id: "custom", name: "Your font"))
                    }
                    MixButton(label: "import a font (.ttf / .otf)", icon: "textformat") {
                        pickMode = .font
                        picking = true
                    }
                    .padding(.top, 8)
                    Text("Free fonts: fonts.google.com, download a family and pick its .ttf file.")
                        .font(theme.font(11)).foregroundColor(theme.p.fog).padding(.top, 4)
                }
            }
        }
    }

    private var downloadsSection: some View {
        VStack(alignment: .leading, spacing: 0) {
            SectionTitle(text: "downloads")
            VStack(alignment: .leading, spacing: 8) {
                Text("Default quality").font(theme.font(14)).foregroundColor(theme.p.paper)
                HStack(spacing: 8) {
                    chip("Best", on: quality != "small") { quality = "best" }
                    chip("Data saver", on: quality == "small") { quality = "small" }
                }
                Text(quality == "small" ? "Smaller files (about 48–70 kbps AAC)." : "The best audio YouTube has (about 128–256 kbps AAC).")
                    .font(theme.font(11)).foregroundColor(theme.p.fog)
                Text("Songs at the same time").font(theme.font(14)).foregroundColor(theme.p.paper).padding(.top, 8)
                HStack(spacing: 8) {
                    ForEach(1...4, id: \.self) { n in
                        Button { parallel = n } label: {
                            Text("\(n)").font(theme.font(15, .semibold))
                                .foregroundColor(parallel == n ? theme.p.ink : theme.p.paper)
                                .frame(width: 44, height: 44)
                                .background(RoundedRectangle(cornerRadius: theme.rounded ? 12 : 3).fill(parallel == n ? theme.p.tape : theme.p.raised))
                        }
                        .buttonStyle(.plain)
                    }
                }
                Text("More is faster but uses more battery and data. Songs are saved to Files › On My iPhone › Mixtape › Music.")
                    .font(theme.font(11)).foregroundColor(theme.p.fog)
            }
            .padding(.horizontal, 16)
        }
    }

    private var librarySection: some View {
        VStack(alignment: .leading, spacing: 0) {
            SectionTitle(text: "library")
            VStack(alignment: .leading, spacing: 10) {
                Text("\(model.songs.count) songs · \(model.albums.count) albums · \(model.playlists.count) playlists")
                    .font(theme.font(13)).foregroundColor(theme.p.paper)
                HStack(spacing: 8) {
                    MixButton(label: "import files / folder", icon: "folder", primary: true) {
                        pickMode = .music
                        picking = true
                    }
                    MixButton(label: model.scanning ? "scanning…" : "rescan", icon: "arrow.clockwise") { Task { await model.rescan() } }
                }
                Text("Your music lives in the Files app › On My iPhone › Mixtape. Anything you put there shows up here. iPhones don't let apps look through other folders.")
                    .font(theme.font(11)).foregroundColor(theme.p.fog)
            }
            .padding(.horizontal, 16)
        }
    }

    private var playerSection: some View {
        VStack(alignment: .leading, spacing: 0) {
            SectionTitle(text: "player")
            SettingToggle(title: "Swipe to change songs", subtitle: "On the mini player: left = next, right = previous", isOn: $swipeMini)
            SettingToggle(title: "Sideways clock mode", subtitle: "Turn the phone sideways (rotation lock off): big clock, date and what's playing. Keeps the screen on.", isOn: $clockSideways)
            if clockSideways {
                ClockOptions()
                Button { nav.openClock(turn: 0) } label: {
                    Text(theme.btn("open the clock now")).font(theme.font(13, .semibold)).foregroundColor(theme.p.tape)
                }
                .buttonStyle(.plain)
                .padding(.horizontal, 28).padding(.vertical, 6)
            }
            SettingToggle(title: "Video covers", subtitle: "The song's music video plays silently instead of the cover, like Spotify", isOn: $videoCovers)
            if videoCovers {
                SettingToggle(title: "Only on Wi-Fi", subtitle: "Videos stream from YouTube (about 5–10 MB per song)", isOn: $videoWifiOnly)
                    .padding(.leading, 12)
            }
            SettingToggle(title: "Artist info", subtitle: "Short profile with the artist's photo, from the player (swipe up). Saved after the first time.", isOn: $artistInfo)
            NavigationLink { EqualizerView() } label: {
                SettingRow(title: "Equaliser & effects", subtitle: "Presets, 5 bands, bass, boost, slowed, reverb, bitcrush, fades") {
                    Text(theme.btn("open")).font(theme.font(13, .semibold)).foregroundColor(theme.p.tape)
                }
            }
            .buttonStyle(.plain)
            SettingToggle(title: "Find lyrics online", subtitle: "Looks each song up once on LRCLIB, then keeps them offline", isOn: $lyricsOnline)
            SettingRow(title: "Sleep timer", subtitle: player.sleepAt.map { "Stops at \($0.formatted(date: .omitted, time: .shortened))" } ?? "Off") {
                Menu {
                    ForEach([15, 30, 45, 60, 90], id: \.self) { m in
                        Button("\(m) minutes") { player.setSleep(minutes: m) }
                    }
                    Button("Off") { player.setSleep(minutes: nil) }
                } label: {
                    Text(theme.btn("set")).font(theme.font(13, .semibold)).foregroundColor(theme.p.tape)
                }
            }
        }
    }

    private var backupSection: some View {
        VStack(alignment: .leading, spacing: 0) {
            SectionTitle(text: "backup")
            SettingRow(title: "Save a backup", subtitle: "Playlists, stats, your lyrics and settings in one file (not the music)") {
                Button {
                    backupDoc = BackupDocument(data: model.backupData())
                    exporting = true
                } label: { Text(theme.btn("save")).font(theme.font(13, .semibold)).foregroundColor(theme.p.tape) }
                .buttonStyle(.plain)
            }
            SettingRow(title: "Restore a backup", subtitle: "Replaces your playlists and settings with the ones in the file") {
                Button {
                    pickMode = .backup
                    picking = true
                } label: { Text(theme.btn("restore")).font(theme.font(13, .semibold)).foregroundColor(theme.p.tape) }
                .buttonStyle(.plain)
            }
        }
    }

    private var aboutSection: some View {
        VStack(alignment: .leading, spacing: 0) {
            SectionTitle(text: "about")
            SettingRow(title: "Tutorial", subtitle: "The three intro pages again") {
                Button { showTutorial = true } label: {
                    Text(theme.btn("replay")).font(theme.font(13, .semibold)).foregroundColor(theme.p.tape)
                }
                .buttonStyle(.plain)
            }
            Text("Made by Andre. Lyrics from LRCLIB. Playlists read from Spotify's public pages, no account needed. Downloads use YouTube.")
                .font(theme.font(12)).foregroundColor(theme.p.fog)
                .padding(.horizontal, 16).padding(.top, 8)
            Text("Installed with Sideloadly? Apps signed with a free Apple ID stop opening after 7 days: install again (your music and playlists stay).")
                .font(theme.font(12)).foregroundColor(theme.p.fog)
                .padding(.horizontal, 16).padding(.top, 8)
        }
    }

    // MARK: - Pieces

    private func backupName() -> String {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd"
        return "mixtape-backup-\(f.string(from: Date())).json"
    }

    private func loadBackground(_ item: PhotosPickerItem?, video: Bool) {
        guard let item = item else { return }
        loadingBackground = true
        Task {
            let data = try? await item.loadTransferable(type: Data.self)
            loadingBackground = false
            guard let d = data else { model.show("Couldn't use that \(video ? "video" : "picture").") ; return }
            let ok = video ? theme.setBackgroundVideo(d) : theme.setBackgroundImage(d)
            if !ok { model.show("Couldn't use that \(video ? "video" : "picture").") }
            pictureItem = nil
            videoItem = nil
        }
    }

    private func pickerLabel(_ label: String, icon: String) -> some View {
        HStack(spacing: 6) {
            Image(systemName: icon).font(.system(size: 13, weight: .semibold))
            Text(theme.btn(label)).font(theme.font(13, .semibold)).lineLimit(1)
        }
        .foregroundColor(theme.p.tape)
        .padding(.horizontal, theme.rounded ? 14 : 8).padding(.vertical, 8)
        .background(RoundedRectangle(cornerRadius: theme.rounded ? 20 : 3).fill(theme.rounded ? theme.p.raised : Color.clear))
        .overlay(RoundedRectangle(cornerRadius: theme.rounded ? 20 : 3).stroke(theme.rounded ? Color.clear : theme.p.gap, lineWidth: 1))
    }

    private func fold<C: View>(_ title: String, summary: String, open: Binding<Bool>, @ViewBuilder content: () -> C) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Button { withAnimation(theme.anim(.easeInOut(duration: 0.2))) { open.wrappedValue.toggle() } } label: {
                HStack {
                    Text(theme.head(title)).font(theme.font(13, .semibold)).foregroundColor(theme.p.tape)
                    Spacer()
                    Text(summary).font(theme.font(12)).foregroundColor(theme.p.fog)
                    Image(systemName: open.wrappedValue ? "chevron.up" : "chevron.down").font(.system(size: 12)).foregroundColor(theme.p.tape)
                }
                .padding(.horizontal, 16).padding(.top, 18).padding(.bottom, 8)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            if open.wrappedValue {
                content().padding(.horizontal, 16)
            }
        }
    }

    private func choice(_ label: String, on: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 8) {
                Image(systemName: on ? "largecircle.fill.circle" : "circle").foregroundColor(on ? theme.p.tape : theme.p.fog)
                Text(label).font(theme.font(14)).foregroundColor(on ? theme.p.tape : theme.p.paper)
                Spacer()
            }
            .padding(.vertical, 6)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private func fontRow(_ f: FontChoice) -> some View {
        let on: Bool = theme.fontId == f.id
        return Button { theme.fontId = f.id } label: {
            HStack(spacing: 8) {
                Image(systemName: on ? "largecircle.fill.circle" : "circle").foregroundColor(on ? theme.p.tape : theme.p.fog)
                Text(f.name).font(theme.preview(f, size: 16)).foregroundColor(on ? theme.p.tape : theme.p.paper)
                Spacer()
            }
            .padding(.vertical, 7)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private func chip(_ label: String, on: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(label)
                .font(theme.font(13, .semibold))
                .foregroundColor(on ? theme.p.ink : theme.p.paper)
                .padding(.horizontal, 14).padding(.vertical, 8)
                .background(RoundedRectangle(cornerRadius: theme.rounded ? 16 : 3).fill(on ? theme.p.tape : theme.p.raised))
        }
        .buttonStyle(.plain)
    }

    private func swatch(id: String, name: String, colors: (UInt32, UInt32, UInt32)) -> some View {
        let p = Palette.from(colors.0, colors.1, colors.2)
        let selected = theme.themeId == id
        return Button { theme.themeId = id } label: {
            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 4) {
                    Circle().fill(p.tape).frame(width: 12, height: 12)
                    Capsule().fill(p.paper).frame(width: 34, height: 5)
                }
                Text(name).font(.system(size: 11, weight: .medium, design: theme.rounded ? .rounded : .monospaced))
                    .foregroundColor(p.paper).lineLimit(1)
            }
            .padding(10)
            .frame(width: 104, alignment: .leading)
            .background(RoundedRectangle(cornerRadius: theme.corner).fill(p.ink))
            .overlay(RoundedRectangle(cornerRadius: theme.corner).stroke(selected ? theme.p.tape : theme.p.gap, lineWidth: selected ? 2 : 1))
        }
        .buttonStyle(.plain)
    }

    private func colorRow(_ label: String, _ which: Int) -> some View {
        let binding = Binding<Color>(
            get: {
                let c = theme.custom
                return RGB([c.0, c.1, c.2][which]).color
            },
            set: { newColor in
                var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
                _ = UIColor(newColor).getRed(&r, green: &g, blue: &b, alpha: &a)
                let hex = RGB(r: Double(r), g: Double(g), b: Double(b)).hex
                var c = theme.custom
                switch which {
                case 0: c.0 = hex
                case 1: c.1 = hex
                default: c.2 = hex
                }
                theme.custom = c
                theme.themeId = "custom"
            }
        )
        return ColorPicker(selection: binding, supportsOpacity: false) {
            Text(label).font(theme.font(14)).foregroundColor(theme.p.paper)
        }
    }
}

// MARK: - Setting rows (also used by the clock options)

struct SettingRow<Trailing: View>: View {
    @EnvironmentObject var theme: ThemeStore
    let title: String
    let subtitle: String
    @ViewBuilder let trailing: () -> Trailing

    var body: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(theme.font(14, .medium)).foregroundColor(theme.p.paper)
                if !subtitle.isEmpty {
                    Text(subtitle).font(theme.font(11)).foregroundColor(theme.p.fog).fixedSize(horizontal: false, vertical: true)
                }
            }
            Spacer(minLength: 8)
            trailing()
        }
        .padding(.horizontal, 16).padding(.vertical, 8)
        .contentShape(Rectangle())
    }
}

struct SettingToggle: View {
    @EnvironmentObject var theme: ThemeStore
    let title: String
    let subtitle: String
    @Binding var isOn: Bool

    var body: some View {
        SettingRow(title: title, subtitle: subtitle) {
            Toggle("", isOn: $isOn).labelsHidden().tint(theme.p.tape)
        }
    }
}

struct SettingSlider: View {
    @EnvironmentObject var theme: ThemeStore
    let title: String
    @Binding var value: Double
    let range: ClosedRange<Double>
    let text: String

    var body: some View {
        VStack(spacing: 2) {
            HStack {
                Text(title).font(theme.font(14)).foregroundColor(theme.p.paper)
                Spacer()
                Text(text).font(theme.font(12)).foregroundColor(theme.p.tape)
            }
            Slider(value: $value, in: range).tint(theme.p.tape)
        }
        .padding(.vertical, 4)
    }
}

/// Updates: checks the GitHub releases and gets the new version onto the phone.
struct UpdatesSection: View {
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var updater: Updater
    @State private var sourceOpen = false
    @State private var repoText = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            SectionTitle(text: updater.updateAvailable ? "update available" : "updates")
            VStack(alignment: .leading, spacing: 10) {
                if let r = updater.latest, updater.updateAvailable {
                    Text("Mixtape v\(r.version) is out (you have v\(updater.currentVersion)).")
                        .font(theme.font(14, .semibold)).foregroundColor(theme.p.paper)
                    if !r.notes.isEmpty {
                        Text(r.notes).font(theme.font(12)).foregroundColor(theme.p.fog)
                            .lineLimit(12).fixedSize(horizontal: false, vertical: true)
                    }
                    HStack(spacing: 8) {
                        MixButton(label: "sidestore", icon: "arrow.down.app", primary: true) { updater.openIn("sidestore") }
                        MixButton(label: "altstore", icon: "arrow.down.app") { updater.openIn("altstore") }
                    }
                    HStack(spacing: 8) {
                        MixButton(label: updater.downloading ? "downloading…" : "save the .ipa", icon: "square.and.arrow.down") {
                            Task { await updater.download() }
                        }
                        .disabled(updater.downloading)
                        if updater.downloading { ProgressView().tint(theme.p.tape) }
                        if let file = updater.downloaded {
                            ShareLink(item: file) {
                                Text(theme.btn("send to pc")).font(theme.font(13, .semibold)).foregroundColor(theme.p.tape)
                            }
                        }
                    }
                    Text("iPhones don't let an app replace itself. SideStore / AltStore install it in one tap. With Sideloadly: save the .ipa (or AirDrop it to your PC) and drag it into Sideloadly like the first time. Your music and playlists stay.")
                        .font(theme.font(11)).foregroundColor(theme.p.fog)
                } else {
                    HStack(spacing: 10) {
                        MixButton(label: updater.checking ? "checking…" : "check for updates", icon: "arrow.triangle.2.circlepath", primary: true) {
                            Task { await updater.check() }
                        }
                        .disabled(updater.checking)
                        if updater.checking { ProgressView().tint(theme.p.tape) }
                    }
                }
                if let m = updater.message {
                    Text(m).font(theme.font(12)).foregroundColor(theme.p.fog)
                }
                Button {
                    repoText = updater.repo
                    withAnimation(theme.anim()) { sourceOpen.toggle() }
                } label: {
                    Text("Checks github.com/\(updater.repo) \(sourceOpen ? "▴" : "▾")")
                        .font(theme.font(11)).foregroundColor(theme.p.fog)
                }
                .buttonStyle(.plain)
                if sourceOpen {
                    HStack(spacing: 8) {
                        TextField("", text: $repoText, prompt: Text("owner/repo").foregroundColor(theme.p.fog))
                            .font(theme.font(13)).foregroundColor(theme.p.paper)
                            .autocorrectionDisabled().textInputAutocapitalization(.never)
                            .padding(8)
                            .background(RoundedRectangle(cornerRadius: theme.corner).fill(theme.p.raised))
                        MixButton(label: "use") {
                            updater.setRepo(repoText)
                            Task { await updater.check() }
                        }
                    }
                }
            }
            .padding(.horizontal, 16)
        }
    }
}
