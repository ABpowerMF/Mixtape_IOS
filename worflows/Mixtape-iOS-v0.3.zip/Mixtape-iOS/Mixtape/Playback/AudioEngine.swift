import Foundation
import AVFoundation

/// The sound path: two decks (so one song can fade into the next) → mixer → speed / pitch → equaliser
/// → bitcrush → reverb → speaker. Each effect is bypassed while it's off, so it costs nothing.
@MainActor
final class AudioEngine {
    final class Deck {
        let node = AVAudioPlayerNode()
        var file: AVAudioFile?
        var format: AVAudioFormat?
        /// Where in the file the current schedule starts.
        var startFrame: AVAudioFramePosition = 0
        /// Bumped on every new schedule / stop, so callbacks of old schedules are ignored.
        var generation = 0
        /// Position while paused or not yet started.
        var heldMs: Int? = 0

        var durationMs: Int {
            guard let f = file, f.processingFormat.sampleRate > 0 else { return 0 }
            return Int(Double(f.length) / f.processingFormat.sampleRate * 1000)
        }
    }

    let engine = AVAudioEngine()
    let decks: [Deck] = [Deck(), Deck()]
    /// A deck played its song to the end (index of the deck).
    var onFinished: ((Int) -> Void)?

    private let mixer = AVAudioMixerNode()
    private let timePitch = AVAudioUnitTimePitch()
    private let eq = AVAudioUnitEQ(numberOfBands: 6)
    private let crush = AVAudioUnitDistortion()
    private let reverb = AVAudioUnitReverb()
    private var crushPreset = -1

    init() {
        for d in decks { engine.attach(d.node) }
        engine.attach(mixer)
        engine.attach(timePitch)
        engine.attach(eq)
        engine.attach(crush)
        engine.attach(reverb)
        let fmt = AVAudioFormat(standardFormatWithSampleRate: 44_100, channels: 2)
        engine.connect(mixer, to: timePitch, format: fmt)
        engine.connect(timePitch, to: eq, format: fmt)
        engine.connect(eq, to: crush, format: fmt)
        engine.connect(crush, to: reverb, format: fmt)
        engine.connect(reverb, to: engine.mainMixerNode, format: fmt)
        for i in 0..<decks.count {
            engine.connect(decks[i].node, to: mixer, fromBus: 0, toBus: i, format: fmt)
            decks[i].format = fmt
        }
        for i in 0..<Fx.freqs.count {
            let band = eq.bands[i]
            band.filterType = .parametric
            band.frequency = Fx.freqs[i]
            band.bandwidth = 1.0
            band.gain = 0
            band.bypass = false
        }
        let shelf = eq.bands[5]
        shelf.filterType = .lowShelf
        shelf.frequency = 90
        shelf.gain = 0
        shelf.bypass = false
        reverb.loadFactoryPreset(.mediumHall)
        engine.prepare()
    }

    var isRunning: Bool { engine.isRunning }

    func start() throws {
        if !engine.isRunning { try engine.start() }
    }

    /// Stops the audio hardware while nothing plays (saves battery). Positions are kept.
    func sleep() {
        if engine.isRunning { engine.pause() }
    }

    /// Opens a song on a deck (nothing is played yet).
    func load(_ url: URL, deck i: Int) throws {
        let d = decks[i]
        stop(deck: i)
        let file = try AVAudioFile(forReading: url)
        let f = file.processingFormat
        if d.format == nil || d.format != f {
            engine.disconnectNodeOutput(d.node)
            engine.connect(d.node, to: mixer, fromBus: 0, toBus: i, format: f)
            d.format = f
        }
        d.file = file
        d.startFrame = 0
        d.heldMs = 0
    }

    /// Queues the deck's song from [ms] to the end. Call play() to hear it.
    func schedule(deck i: Int, fromMs ms: Int) {
        let d = decks[i]
        guard let file = d.file else { return }
        d.generation += 1
        let gen = d.generation
        d.node.stop()
        let sr = file.processingFormat.sampleRate
        let wanted = AVAudioFramePosition(Double(max(0, ms)) / 1000 * sr)
        let start = min(wanted, file.length)
        d.startFrame = start
        d.heldMs = ms
        let left = file.length - start
        guard left > 0 else {
            Task { @MainActor [weak self] in self?.finished(i, gen) }
            return
        }
        d.node.scheduleSegment(file, startingFrame: start, frameCount: AVAudioFrameCount(left), at: nil,
                               completionCallbackType: .dataPlayedBack) { [weak self] _ in
            guard let engine = self else { return }
            Task { @MainActor in engine.finished(i, gen) }
        }
    }

    private func finished(_ i: Int, _ gen: Int) {
        guard decks[i].generation == gen else { return }
        onFinished?(i)
    }

    func play(deck i: Int) throws {
        try start()
        decks[i].heldMs = nil
        decks[i].node.play()
    }

    func pause(deck i: Int) {
        let ms = positionMs(deck: i)
        decks[i].node.pause()
        decks[i].heldMs = ms
    }

    func stop(deck i: Int) {
        let d = decks[i]
        d.generation += 1
        d.node.stop()
        d.heldMs = 0
    }

    func unload(deck i: Int) {
        stop(deck: i)
        decks[i].file = nil
    }

    func setVolume(_ v: Float, deck i: Int) {
        decks[i].node.volume = max(0, min(1, v))
    }

    func volume(deck i: Int) -> Float { decks[i].node.volume }

    func positionMs(deck i: Int) -> Int {
        let d = decks[i]
        guard let file = d.file else { return 0 }
        if let held = d.heldMs { return held }
        let sr = file.processingFormat.sampleRate
        guard sr > 0 else { return 0 }
        if let nodeTime = d.node.lastRenderTime, nodeTime.isSampleTimeValid,
           let pt = d.node.playerTime(forNodeTime: nodeTime), pt.sampleRate > 0 {
            let played: Double = Double(pt.sampleTime) * sr / pt.sampleRate
            let frames: Double = Double(d.startFrame) + max(0, played)
            let ms: Int = Int(frames / sr * 1000)
            return min(ms, d.durationMs)
        }
        return Int(Double(d.startFrame) / sr * 1000)
    }

    func apply(_ fx: FxSettings) {
        for i in 0..<Fx.freqs.count {
            let g: Float = i < fx.bands.count ? fx.bands[i] : 0
            eq.bands[i].gain = fx.enabled ? max(-Fx.maxDb, min(Fx.maxDb, g)) : 0
        }
        eq.bands[5].gain = fx.enabled ? fx.bass * 12 : 0
        eq.globalGain = fx.enabled ? fx.boost : 0
        eq.bypass = !fx.enabled

        let speed: Float = max(0.5, min(1.5, fx.speed))
        timePitch.rate = speed
        timePitch.pitch = fx.vinyl ? 1200 * log2(speed) : 0
        timePitch.bypass = speed == 1

        reverb.wetDryMix = fx.reverb * 55
        reverb.bypass = fx.reverb <= 0

        let preset: Int = fx.bitcrush < 0.34 ? 0 : (fx.bitcrush < 0.67 ? 1 : 2)
        if preset != crushPreset {
            let presets: [AVAudioUnitDistortionPreset] = [.multiDecimated2, .multiDecimated3, .multiDecimated4]
            crush.loadFactoryPreset(presets[preset])
            crushPreset = preset
        }
        crush.wetDryMix = 20 + fx.bitcrush * 80
        crush.bypass = fx.bitcrush <= 0
    }
}
