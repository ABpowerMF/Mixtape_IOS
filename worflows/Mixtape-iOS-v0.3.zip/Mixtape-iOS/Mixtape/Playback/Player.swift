import Foundation
import Combine
import AVFoundation
import MediaPlayer
import UIKit

enum RepeatMode: String, Codable {
    case off, all, one
    var next: RepeatMode { self == .off ? .all : self == .all ? .one : .off }
}

/// Position of the current song. Kept apart from the Player so only progress bars redraw every tick.
final class PlayerClock: ObservableObject {
    @Published var positionMs: Int = 0
    @Published var durationMs: Int = 0
}

/// Plays the queue on the audio engine (equaliser, effects, fades, crossfade), with background audio,
/// lock screen / Control Center / headphone controls and a Spotify-style queue
/// ("Next in queue" songs you added, then the rest of the playlist or album).
@MainActor
final class Player: ObservableObject {
    @Published private(set) var queue: [String] = []
    @Published private(set) var index: Int = -1
    @Published private(set) var isPlaying = false
    /// How many songs right after the current one were added by hand ("Next in queue").
    @Published private(set) var manualCount = 0
    @Published private(set) var shuffle = false
    @Published private(set) var repeatMode: RepeatMode = .off
    /// "Playing from" label: a playlist, album, "Songs"…
    @Published private(set) var source = ""
    /// Equaliser and effects (also holds the speed).
    @Published private(set) var fx = FxSettings.load()
    @Published var sleepAt: Date?

    /// Slowed (below 1) or sped up (above 1).
    var speed: Float { fx.speed }

    let clock = PlayerClock()
    /// Looks up a song by id in the library (set by the app model).
    var resolve: (String) -> Song? = { _ in nil }
    /// Called when a song starts (for stats).
    var onSongStarted: ((Song) -> Void)?

    private let engine = AudioEngine()
    /// The deck playing the current song (the other one is used for crossfades).
    private var active = 0
    /// The song that's actually loaded on the active deck.
    private var loadedId: String?
    private var original: [String] = []
    private var pendingSeekMs: Int?
    private var needsReschedule = false
    private var wasPlayingBeforeInterruption = false
    private var crossfading = false
    private var fadingOut = false
    private var lastSave = Date.distantPast
    private var sleepTimer: Timer?
    private var ticker: Timer?
    private var lastTick = Date()
    private var engineSleep: Task<Void, Never>?
    private var visible = true
    private var skippedMissing = 0
    private var tokens: [NSObjectProtocol] = []
    private var listened: [String: Int] = [:]
    private var lastListenFlush = Date()

    private struct Ramp {
        let from: Float
        let to: Float
        let start: Date
        let seconds: Double
        let done: (() -> Void)?
    }
    private var ramps: [Int: Ramp] = [:]
    private var rampTimer: Timer?

    var currentId: String? { index >= 0 && index < queue.count ? queue[index] : nil }
    var current: Song? { currentId.flatMap { resolve($0) } }
    var hasQueue: Bool { currentId != nil }

    init() {
        configureSession()
        engine.apply(fx)
        engine.onFinished = { [weak self] deck in self?.deckFinished(deck) }
        setupRemoteCommands()
        observe()
        restoreState()
    }

    // MARK: - Starting things

    /// Plays [ids] starting at [start]. With shuffle on, the start song plays first and the rest is shuffled.
    /// start = -1 picks a random first song (the "shuffle" button).
    func play(_ ids: [String], start: Int, source: String, shuffled: Bool? = nil) {
        guard !ids.isEmpty else { return }
        if let s = shuffled { shuffle = s }
        var list = ids
        var first = start >= 0 && start < ids.count ? start : Int.random(in: 0..<ids.count)
        original = ids
        if shuffle {
            let firstId = list.remove(at: first)
            list.shuffle()
            list.insert(firstId, at: 0)
            first = 0
        }
        queue = list
        index = first
        manualCount = 0
        self.source = source
        skippedMissing = 0
        load(play: true)
    }

    /// Adds songs right after the current one, before everything else ("Play next").
    func playNext(_ ids: [String]) {
        guard !ids.isEmpty else { return }
        guard hasQueue else { play(ids, start: 0, source: "Queue"); return }
        queue.insert(contentsOf: ids, at: index + 1)
        manualCount += ids.count
        saveState(force: true)
    }

    /// Adds songs to the end of "Next in queue".
    func addToQueue(_ ids: [String]) {
        guard !ids.isEmpty else { return }
        guard hasQueue else { play(ids, start: 0, source: "Queue"); return }
        queue.insert(contentsOf: ids, at: index + 1 + manualCount)
        manualCount += ids.count
        saveState(force: true)
    }

    // MARK: - Controls

    func toggle() { isPlaying ? pause() : resume() }

    func resume() {
        guard hasQueue else { return }
        if loadedId == nil || loadedId != currentId || engine.decks[active].file == nil {
            let at = pendingSeekMs ?? clock.positionMs
            pendingSeekMs = nil
            load(play: true, seekMs: at)
            return
        }
        cancelRamps()
        fadingOut = false
        engine.setVolume(1, deck: active)
        if needsReschedule {
            engine.schedule(deck: active, fromMs: clock.positionMs)
            needsReschedule = false
        }
        startPlaying()
        updateNowPlaying()
    }

    func pause() {
        if crossfading { finishCrossfade() }
        cancelRamps()
        if engine.decks[active].file != nil {
            engine.pause(deck: active)
            clock.positionMs = engine.positionMs(deck: active)
        }
        isPlaying = false
        updateTicker()
        flushListening()
        updateNowPlaying()
        saveState(force: true)
        // Turn the audio hardware off after a while paused (battery).
        engineSleep?.cancel()
        engineSleep = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 15_000_000_000)
            guard !Task.isCancelled, let self = self, !self.isPlaying else { return }
            self.engine.sleep()
        }
    }

    func next() { advance(auto: false) }

    func previous() {
        if clock.positionMs > 3000 || index <= 0 {
            seek(to: 0)
            if !isPlaying { resume() }
            return
        }
        index -= 1
        load(play: true)
    }

    func seek(to ms: Int) {
        clock.positionMs = ms
        guard loadedId != nil, loadedId == currentId, engine.decks[active].file != nil else {
            pendingSeekMs = ms
            updateNowPlaying()
            return
        }
        if crossfading { finishCrossfade() }
        cancelRamps()
        fadingOut = false
        engine.setVolume(1, deck: active)
        engine.schedule(deck: active, fromMs: ms)
        needsReschedule = false
        if isPlaying { try? engine.play(deck: active) }
        updateNowPlaying()
        saveState(force: true)
    }

    /// Jumps to a song in the queue (tapping it in the queue screen).
    func jump(to i: Int) {
        guard i >= 0 && i < queue.count else { return }
        let manualEnd = index + manualCount
        if i > index && i <= manualEnd {
            // Songs you queued before it are skipped, like Spotify.
            queue.removeSubrange((index + 1)..<i)
            manualCount = manualEnd - i
            index += 1
        } else if i > manualEnd {
            if manualCount > 0 { queue.removeSubrange((index + 1)...manualEnd) }
            let newIndex = i - manualCount
            manualCount = 0
            index = newIndex
        } else {
            index = i
            manualCount = 0
        }
        load(play: true)
    }

    func remove(at i: Int) {
        guard i >= 0 && i < queue.count, i != index else { return }
        queue.remove(at: i)
        if i < index { index -= 1 } else if i <= index + manualCount { manualCount -= 1 }
        saveState(force: true)
    }

    func clearManual() {
        guard manualCount > 0 else { return }
        queue.removeSubrange((index + 1)...(index + manualCount))
        manualCount = 0
        saveState(force: true)
    }

    /// Reorders the songs after the current one. [from]/[to] count from the first song after it
    /// (moves stay inside their section, so "Next in queue" keeps its size).
    func moveUpcoming(from: Int, to: Int) {
        let a = index + 1 + from, b = index + 1 + to
        guard a != b, a > index, a < queue.count, b > index, b < queue.count else { return }
        let id = queue.remove(at: a)
        queue.insert(id, at: b)
        manualCount = max(0, min(manualCount, queue.count - index - 1))
        saveState(force: true)
    }

    func setShuffle(_ on: Bool) {
        guard on != shuffle else { return }
        shuffle = on
        guard hasQueue else { return }
        let manualEnd = index + manualCount
        let head = Array(queue[...manualEnd])
        var rest = Array(queue[(manualEnd + 1)...])
        if on {
            original = queue
            rest.shuffle()
        } else if let cur = currentId, let pos = original.firstIndex(of: cur) {
            var left = rest
            var ordered: [String] = []
            for id in original[(pos + 1)...] {
                if let k = left.firstIndex(of: id) { ordered.append(id); left.remove(at: k) }
            }
            rest = ordered + left
        }
        queue = head + rest
        saveState(force: true)
    }

    func cycleRepeat() {
        repeatMode = repeatMode.next
        saveState(force: true)
    }

    func setFx(_ new: FxSettings) {
        fx = new
        fx.save()
        engine.apply(fx)
        updateNowPlaying()
    }

    func setSpeed(_ value: Float) {
        var f = fx
        f.speed = value
        setFx(f)
    }

    func setSleep(minutes: Int?) {
        sleepTimer?.invalidate()
        sleepTimer = nil
        guard let m = minutes else { sleepAt = nil; return }
        let at = Date().addingTimeInterval(Double(m) * 60)
        sleepAt = at
        sleepTimer = Timer.scheduledTimer(withTimeInterval: Double(m) * 60, repeats: false) { [weak self] _ in
            Task { @MainActor in
                self?.pause()
                self?.sleepAt = nil
            }
        }
    }

    /// The screen is on (true) or the app is in the background (false).
    func setVisible(_ v: Bool) {
        visible = v
        if v {
            if loadedId != nil { clock.positionMs = engine.positionMs(deck: active) }
        } else {
            flushListening()
            saveState(force: true)
        }
        updateTicker()
    }

    /// Drops songs whose files are gone (after a library scan).
    func prune(valid: Set<String>) {
        guard !queue.isEmpty else { return }
        let cur = currentId
        var newQueue: [String] = []
        var newIndex = -1
        var newManual = 0
        for (i, id) in queue.enumerated() {
            guard valid.contains(id) || id == cur else { continue }
            if i == index { newIndex = newQueue.count }
            if i > index && i <= index + manualCount { newManual += 1 }
            newQueue.append(id)
        }
        if newQueue.count != queue.count {
            queue = newQueue
            index = newIndex
            manualCount = newManual
            original = original.filter { valid.contains($0) }
            saveState(force: true)
        }
    }

    // MARK: - Internals

    /// Where the queue goes after this song (nil = the end).
    private func nextIndex() -> Int? {
        if index + 1 < queue.count { return index + 1 }
        if repeatMode == .all && !queue.isEmpty { return 0 }
        return nil
    }

    private func moveIndex(to n: Int) {
        if n == index + 1 { manualCount = max(0, manualCount - 1) } else { manualCount = 0 }
        index = n
    }

    private func advance(auto: Bool) {
        flushListening()
        if auto && repeatMode == .one {
            load(play: true)
            return
        }
        if let n = nextIndex() {
            moveIndex(to: n)
            load(play: true)
        } else if auto {
            // End of the queue: stop at the start of the last song.
            isPlaying = false
            engine.schedule(deck: active, fromMs: 0)
            engine.setVolume(1, deck: active)
            clock.positionMs = 0
            updateTicker()
            updateNowPlaying()
            saveState(force: true)
        }
    }

    private func deckFinished(_ deck: Int) {
        // The deck that faded out during a crossfade: nothing to do.
        guard deck == active else { return }
        advance(auto: true)
    }

    private func load(play: Bool, seekMs: Int? = nil) {
        cancelRamps()
        crossfading = false
        fadingOut = false
        needsReschedule = false
        engine.stop(deck: 1 - active)
        guard let song = current else {
            engine.unload(deck: active)
            loadedId = nil
            isPlaying = false
            updateTicker()
            updateNowPlaying()
            return
        }
        do {
            try engine.load(song.url, deck: active)
        } catch {
            // A file deleted in the Files app, or one iOS can't read: skip it (but never loop forever).
            skippedMissing += 1
            loadedId = nil
            if skippedMissing < 20, let n = nextIndex(), n != index {
                moveIndex(to: n)
                load(play: play)
            } else {
                isPlaying = false
                updateTicker()
            }
            return
        }
        skippedMissing = 0
        loadedId = song.id
        let duration = engine.decks[active].durationMs
        clock.durationMs = duration > 0 ? duration : song.durationMs
        let start = max(0, seekMs ?? 0)
        clock.positionMs = start
        engine.schedule(deck: active, fromMs: start)
        let fadeIn = play && fx.fadeSeconds > 0 && start < 500
        engine.setVolume(fadeIn ? 0 : 1, deck: active)
        if play {
            startPlaying()
            if fadeIn { ramp(deck: active, to: 1, seconds: Double(fx.fadeSeconds)) }
            onSongStarted?(song)
        } else {
            isPlaying = false
            updateTicker()
        }
        nowPlayingArtId = nil
        updateNowPlaying()
        saveState(force: true)
    }

    private func startPlaying() {
        activateSession()
        engineSleep?.cancel()
        do {
            try engine.play(deck: active)
            isPlaying = true
        } catch {
            isPlaying = false
        }
        lastTick = Date()
        updateTicker()
    }

    // MARK: - Crossfade and fades

    private func startCrossfade(to n: Int, seconds: Double) {
        guard n >= 0 && n < queue.count, let nextSong = resolve(queue[n]) else { return }
        let old = active
        let new = 1 - active
        do {
            try engine.load(nextSong.url, deck: new)
            engine.schedule(deck: new, fromMs: 0)
            engine.setVolume(0, deck: new)
            try engine.play(deck: new)
        } catch {
            return
        }
        flushListening()
        crossfading = true
        fadingOut = false
        moveIndex(to: n)
        active = new
        loadedId = nextSong.id
        let duration = engine.decks[new].durationMs
        clock.durationMs = duration > 0 ? duration : nextSong.durationMs
        clock.positionMs = 0
        let secs = max(0.5, seconds)
        ramp(deck: old, to: 0, seconds: secs) { [weak self] in
            self?.engine.stop(deck: old)
            self?.crossfading = false
        }
        ramp(deck: new, to: 1, seconds: secs)
        onSongStarted?(nextSong)
        nowPlayingArtId = nil
        updateNowPlaying()
        saveState(force: true)
    }

    private func finishCrossfade() {
        ramps[1 - active] = nil
        engine.stop(deck: 1 - active)
        crossfading = false
    }

    private func ramp(deck: Int, to target: Float, seconds: Double, done: (() -> Void)? = nil) {
        ramps[deck] = Ramp(from: engine.volume(deck: deck), to: target, start: Date(), seconds: max(0.05, seconds), done: done)
        if rampTimer == nil {
            rampTimer = Timer.scheduledTimer(withTimeInterval: 0.03, repeats: true) { [weak self] _ in
                Task { @MainActor in self?.stepRamps() }
            }
        }
    }

    private func stepRamps() {
        let now = Date()
        for (deck, r) in ramps {
            let t: Double = min(1, now.timeIntervalSince(r.start) / r.seconds)
            let v: Float = r.from + (r.to - r.from) * Float(t)
            engine.setVolume(v, deck: deck)
            if t >= 1 {
                ramps[deck] = nil
                r.done?()
            }
        }
        if ramps.isEmpty {
            rampTimer?.invalidate()
            rampTimer = nil
        }
    }

    private func cancelRamps() {
        ramps.removeAll()
        rampTimer?.invalidate()
        rampTimer = nil
    }

    // MARK: - Ticks

    private func updateTicker() {
        if isPlaying {
            guard ticker == nil else { return }
            ticker = Timer.scheduledTimer(withTimeInterval: 0.25, repeats: true) { [weak self] _ in
                Task { @MainActor in self?.tick() }
            }
        } else {
            ticker?.invalidate()
            ticker = nil
        }
    }

    private func tick() {
        let now = Date()
        let elapsed = now.timeIntervalSince(lastTick)
        lastTick = now
        guard isPlaying, loadedId != nil else { return }
        let pos = engine.positionMs(deck: active)
        if abs(clock.positionMs - pos) >= 200 { clock.positionMs = pos }
        if let id = loadedId, elapsed > 0, elapsed < 5 { listened[id, default: 0] += Int(elapsed * 1000) }
        if now.timeIntervalSince(lastListenFlush) > 20 { flushListening() }

        let duration = clock.durationMs
        let s: Double = Double(max(0.5, fx.speed))
        let remainReal: Double = Double(duration - pos) / 1000 / s
        if !crossfading && duration > 0 && remainReal > 0 {
            if fx.crossfadeSeconds > 0, repeatMode != .one, Double(fx.crossfadeSeconds) >= remainReal, let n = nextIndex() {
                startCrossfade(to: n, seconds: remainReal)
            } else if fx.fadeSeconds > 0, !fadingOut, Double(fx.fadeSeconds) >= remainReal {
                fadingOut = true
                ramp(deck: active, to: 0, seconds: remainReal)
            }
        }
        if now.timeIntervalSince(lastSave) > 15 { saveState() }
    }

    private func flushListening() {
        lastListenFlush = Date()
        guard !listened.isEmpty else { return }
        Stats.addListening(listened)
        listened = [:]
    }

    // MARK: - Audio session

    private func configureSession() {
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, policy: .longFormAudio, options: [])
    }

    private func activateSession() {
        try? AVAudioSession.sharedInstance().setActive(true)
    }

    private func observe() {
        let nc = NotificationCenter.default
        tokens.append(nc.addObserver(forName: AVAudioSession.interruptionNotification, object: nil, queue: .main) { [weak self] note in
            let info = note.userInfo ?? [:]
            let type = (info[AVAudioSessionInterruptionTypeKey] as? UInt).flatMap { AVAudioSession.InterruptionType(rawValue: $0) }
            let opts = AVAudioSession.InterruptionOptions(rawValue: (info[AVAudioSessionInterruptionOptionKey] as? UInt) ?? 0)
            Task { @MainActor in
                guard let self = self else { return }
                if type == .began {
                    self.wasPlayingBeforeInterruption = self.isPlaying
                    if self.isPlaying { self.pause() }
                    self.needsReschedule = true
                } else if type == .ended, opts.contains(.shouldResume), self.wasPlayingBeforeInterruption {
                    self.resume()
                }
            }
        })
        tokens.append(nc.addObserver(forName: AVAudioSession.routeChangeNotification, object: nil, queue: .main) { [weak self] note in
            let reason = (note.userInfo?[AVAudioSessionRouteChangeReasonKey] as? UInt).flatMap { AVAudioSession.RouteChangeReason(rawValue: $0) }
            Task { @MainActor in
                // Headphones unplugged / Bluetooth gone: pause instead of blasting the speaker.
                if reason == .oldDeviceUnavailable, self?.isPlaying == true { self?.pause() }
            }
        })
        tokens.append(nc.addObserver(forName: .AVAudioEngineConfigurationChange, object: engine.engine, queue: .main) { [weak self] _ in
            Task { @MainActor in self?.engineRestarted() }
        })
    }

    /// iOS stopped the engine (new headphones, AirPlay…): carry on from the same spot.
    private func engineRestarted() {
        let wasPlaying = isPlaying
        if crossfading { finishCrossfade() }
        cancelRamps()
        engine.setVolume(1, deck: active)
        needsReschedule = true
        isPlaying = false
        updateTicker()
        if wasPlaying { resume() }
    }

    // MARK: - Lock screen

    private var nowPlayingArtId: String?

    private func updateNowPlaying() {
        let center = MPNowPlayingInfoCenter.default()
        guard let song = current else {
            center.nowPlayingInfo = nil
            return
        }
        var info: [String: Any] = center.nowPlayingInfo ?? [:]
        if info[MPMediaItemPropertyTitle] as? String != song.title || nowPlayingArtId != song.id {
            info = [:]
        }
        let pos: Int = loadedId != nil ? engine.positionMs(deck: active) : clock.positionMs
        info[MPMediaItemPropertyTitle] = song.title
        info[MPMediaItemPropertyArtist] = song.displayArtist
        info[MPMediaItemPropertyAlbumTitle] = song.album
        info[MPMediaItemPropertyPlaybackDuration] = Double(max(clock.durationMs, 1)) / 1000
        info[MPNowPlayingInfoPropertyElapsedPlaybackTime] = Double(pos) / 1000
        info[MPNowPlayingInfoPropertyPlaybackRate] = isPlaying ? Double(fx.speed) : 0.0
        info[MPNowPlayingInfoPropertyDefaultPlaybackRate] = Double(fx.speed)
        center.nowPlayingInfo = info
        if nowPlayingArtId != song.id {
            nowPlayingArtId = song.id
            Task { [weak self] in
                guard let img = await Artwork.shared.image(for: song) else { return }
                await MainActor.run {
                    guard let self = self, self.currentId == song.id else { return }
                    var i = MPNowPlayingInfoCenter.default().nowPlayingInfo ?? [:]
                    i[MPMediaItemPropertyArtwork] = MPMediaItemArtwork(boundsSize: img.size) { _ in img }
                    MPNowPlayingInfoCenter.default().nowPlayingInfo = i
                }
            }
        }
    }

    private func setupRemoteCommands() {
        let c = MPRemoteCommandCenter.shared()
        c.playCommand.addTarget { [weak self] _ in Task { @MainActor in self?.resume() }; return .success }
        c.pauseCommand.addTarget { [weak self] _ in Task { @MainActor in self?.pause() }; return .success }
        c.togglePlayPauseCommand.addTarget { [weak self] _ in Task { @MainActor in self?.toggle() }; return .success }
        c.nextTrackCommand.addTarget { [weak self] _ in Task { @MainActor in self?.next() }; return .success }
        c.previousTrackCommand.addTarget { [weak self] _ in Task { @MainActor in self?.previous() }; return .success }
        c.changePlaybackPositionCommand.addTarget { [weak self] event in
            guard let e = event as? MPChangePlaybackPositionCommandEvent else { return .commandFailed }
            let ms = Int(e.positionTime * 1000)
            Task { @MainActor in self?.seek(to: ms) }
            return .success
        }
        c.skipForwardCommand.isEnabled = false
        c.skipBackwardCommand.isEnabled = false
    }

    // MARK: - Remembering the queue

    private func saveState(force: Bool = false) {
        guard force || Date().timeIntervalSince(lastSave) > 5 else { return }
        lastSave = Date()
        let d = UserDefaults.standard
        d.set(queue, forKey: "player.queue")
        d.set(original, forKey: "player.original")
        d.set(index, forKey: "player.index")
        d.set(manualCount, forKey: "player.manual")
        d.set(source, forKey: "player.source")
        d.set(shuffle, forKey: "player.shuffle")
        d.set(repeatMode.rawValue, forKey: "player.repeat")
        let pos: Int = loadedId != nil ? engine.positionMs(deck: active) : clock.positionMs
        d.set(pos, forKey: "player.position")
    }

    private func restoreState() {
        let d = UserDefaults.standard
        queue = d.stringArray(forKey: "player.queue") ?? []
        original = d.stringArray(forKey: "player.original") ?? queue
        index = queue.isEmpty ? -1 : min(max(0, d.integer(forKey: "player.index")), queue.count - 1)
        manualCount = max(0, min(d.integer(forKey: "player.manual"), max(0, queue.count - index - 1)))
        source = d.string(forKey: "player.source") ?? ""
        shuffle = d.bool(forKey: "player.shuffle")
        repeatMode = RepeatMode(rawValue: d.string(forKey: "player.repeat") ?? "") ?? .off
        // Speed used to be saved on its own (v0.1).
        let oldSpeed = d.float(forKey: "player.speed")
        if oldSpeed > 0 && oldSpeed != 1 && fx.speed == 1 {
            fx.speed = oldSpeed
            d.removeObject(forKey: "player.speed")
            fx.save()
            engine.apply(fx)
        }
        let pos = d.integer(forKey: "player.position")
        pendingSeekMs = pos > 0 ? pos : nil
        clock.positionMs = pos
    }

    /// After the library is loaded: show the restored song's length.
    func libraryReady() {
        if let s = current, clock.durationMs == 0 { clock.durationMs = s.durationMs }
    }

    /// Reloads the effects after a backup restore.
    func reloadFx() {
        fx = FxSettings.load()
        engine.apply(fx)
    }
}
