import Foundation

/// Equaliser and effects, same as the Android app (minus "surround", which iPhones don't offer).
struct FxSettings: Codable, Equatable {
    /// Equaliser + bass + volume boost on/off. Speed, reverb, bitcrush and fades work either way.
    var enabled = false
    var preset = "Flat"
    /// Gain in dB for each of `Fx.freqs`, -12…12.
    var bands: [Float] = [0, 0, 0, 0, 0]
    /// Bass / depth, 0…1.
    var bass: Float = 0
    /// Volume boost in dB, 0…10.
    var boost: Float = 0
    /// Fade in at the start and out at the end of each song, seconds (0 = off).
    var fadeSeconds: Float = 0
    /// The next song starts while this one fades out, seconds (0 = off).
    var crossfadeSeconds: Float = 0
    /// Bitcrush 0…1 (0 = off).
    var bitcrush: Float = 0
    /// Reverb 0…1 (0 = off).
    var reverb: Float = 0
    /// Playback speed 0.5…1.5. Below 1 = slowed.
    var speed: Float = 1
    /// Pitch follows the speed like a record (the classic "slowed" sound). Off = same pitch.
    var vinyl = true

    static func load() -> FxSettings {
        guard let data = UserDefaults.standard.data(forKey: "fx"),
              var s = try? JSONDecoder().decode(FxSettings.self, from: data) else { return FxSettings() }
        if s.bands.count != Fx.freqs.count { s.bands = Array(repeating: 0, count: Fx.freqs.count) }
        return s
    }

    func save() {
        if let data = try? JSONEncoder().encode(self) { UserDefaults.standard.set(data, forKey: "fx") }
    }

    /// Something that needs the audio to go through the effects at all.
    var anyEffect: Bool { enabled || speed != 1 || reverb > 0 || bitcrush > 0 }
}

enum Fx {
    /// Five bands: 60 Hz, 230 Hz, 910 Hz, 3.6 kHz, 14 kHz.
    static let freqs: [Float] = [60, 230, 910, 3_600, 14_000]
    static let maxDb: Float = 12

    static let presets: [(String, [Float])] = [
        ("Flat", [0, 0, 0, 0, 0]),
        ("Bass boost", [6, 4, 0, 0, 0]),
        ("Bass cut", [-6, -3, 0, 0, 0]),
        ("Treble boost", [0, 0, 0, 3, 6]),
        ("Vocal", [-2, 0, 3, 3, 1]),
        ("Pop", [-1, 2, 4, 2, -1]),
        ("Rock", [5, 3, -1, 2, 4]),
        ("Hip-hop", [5, 4, 0, 1, 2]),
        ("Electronic", [5, 2, 0, 2, 5]),
        ("Jazz", [3, 1, -1, 2, 3]),
        ("Classical", [4, 2, -1, 2, 4]),
        ("Acoustic", [3, 1, 1, 2, 2]),
        ("Loudness", [5, 1, -1, 1, 4]),
    ]

    static func label(_ hz: Float) -> String {
        hz >= 1000 ? String(format: "%.1fk", hz / 1000).replacingOccurrences(of: ".0k", with: "k") : "\(Int(hz))"
    }
}
