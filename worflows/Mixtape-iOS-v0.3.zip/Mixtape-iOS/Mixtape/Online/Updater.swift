import Foundation
import Combine
import UIKit
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

/// A Mixtape for iPhone release on GitHub.
struct AppRelease: Equatable {
    var version: String
    var tag: String
    var notes: String
    var ipaURL: URL
    var pageURL: URL?
    var size: Int
    var date: String
}

/// Checks the GitHub repo's releases for a newer Mixtape and gets it onto the phone.
/// iPhones never let an app replace itself, so the last step is SideStore / AltStore (one tap)
/// or Sideloadly on a computer (the .ipa is saved to the Files app).
@MainActor
final class Updater: ObservableObject {
    static let defaultRepo = "ABpowerMF/mixtape_iOS"
    static let repoKey = "update.repo"
    private static let lastCheckKey = "update.lastCheck"

    @Published private(set) var latest: AppRelease?
    @Published private(set) var checking = false
    @Published private(set) var message: String?
    @Published private(set) var downloading = false
    @Published private(set) var downloaded: URL?

    var repo: String {
        let r = (UserDefaults.standard.string(forKey: Updater.repoKey) ?? "").trimmed
        return r.isEmpty ? Updater.defaultRepo : r
    }

    var currentVersion: String { Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "0" }

    var updateAvailable: Bool {
        guard let l = latest else { return false }
        return Updater.isNewer(l.version, than: currentVersion)
    }

    /// "0.10" is newer than "0.9"; "0.2.1" is newer than "0.2".
    static func isNewer(_ a: String, than b: String) -> Bool {
        let x = a.split(separator: ".").map { Int($0) ?? 0 }
        let y = b.split(separator: ".").map { Int($0) ?? 0 }
        for i in 0..<max(x.count, y.count) {
            let p = i < x.count ? x[i] : 0
            let q = i < y.count ? y[i] : 0
            if p != q { return p > q }
        }
        return false
    }

    /// Checks at most twice a day on its own (when the app opens).
    func checkIfDue() async -> Bool {
        let last = UserDefaults.standard.double(forKey: Updater.lastCheckKey)
        guard Date().timeIntervalSince1970 - last > 12 * 3600 else { return false }
        await check(silent: true)
        return updateAvailable
    }

    func check(silent: Bool = false) async {
        guard !checking else { return }
        checking = true
        if !silent { message = nil }
        defer { checking = false }
        do {
            let json = try await Http.json("https://api.github.com/repos/\(repo)/releases?per_page=30", step: "GitHub",
                                           headers: ["Accept": "application/vnd.github+json"], ua: Http.appUA)
            UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: Updater.lastCheckKey)
            var best: AppRelease?
            for r in json.array {
                if r["draft"].bool == true || r["prerelease"].bool == true { continue }
                guard let asset = r["assets"].array.first(where: { $0["name"].str.lowercased().hasSuffix(".ipa") }),
                      let url = URL(string: asset["browser_download_url"].str) else { continue }
                let tag = r["tag_name"].str
                let version = Updater.version(from: tag) ?? Updater.version(from: asset["name"].str) ?? "0"
                let release = AppRelease(version: version, tag: tag, notes: r["body"].str.trimmed, ipaURL: url,
                                         pageURL: URL(string: r["html_url"].str), size: asset["size"].int ?? 0,
                                         date: String(r["published_at"].str.prefix(10)))
                if best == nil || Updater.isNewer(version, than: best!.version) { best = release }
            }
            latest = best
            if best == nil {
                message = "No iPhone version found in \(repo)'s releases."
            } else if !updateAvailable {
                message = "You have the newest version (v\(currentVersion))."
            } else {
                message = nil
            }
        } catch {
            let text = error.localizedDescription
            if text.contains("HTTP 404") {
                message = "Couldn't see \(repo). The repo has to be public (or its releases in a public repo)."
            } else if text.contains("HTTP 403") {
                message = "GitHub says wait a bit (too many checks). Try again later."
            } else if !silent {
                message = "Couldn't check: \(text)"
            }
        }
    }

    /// "ios-v0.3" / "Mixtape-iOS-v0.3.ipa" → "0.3"
    static func version(from s: String) -> String? {
        s.firstMatch("v?(\\d+(?:\\.\\d+)+)")
    }

    /// Saves the new .ipa into Files › On My iPhone › Mixtape › Updates.
    func download() async {
        guard let r = latest, !downloading else { return }
        downloading = true
        message = nil
        defer { downloading = false }
        do {
            let (tmp, response) = try await Http.session.download(from: r.ipaURL)
            if let http = response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
                throw StepError(step: "download", message: "HTTP \(http.statusCode)")
            }
            let folder = Store.musicRoot.appendingPathComponent("Updates", isDirectory: true)
            try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            let dest = folder.appendingPathComponent("Mixtape-iOS-v\(r.version).ipa")
            try? FileManager.default.removeItem(at: dest)
            try FileManager.default.moveItem(at: tmp, to: dest)
            downloaded = dest
            message = "Saved to Files › On My iPhone › Mixtape › Updates."
        } catch {
            message = "Couldn't download: \(error.localizedDescription)"
        }
    }

    /// Opens SideStore or AltStore with the new version (they install it in one tap).
    func openIn(_ app: String) {
        guard let r = latest else { return }
        let link = r.ipaURL.absoluteString.urlQueryEncoded
        guard let url = URL(string: "\(app)://install?url=\(link)") else { return }
        let name = app == "sidestore" ? "SideStore" : "AltStore"
        UIApplication.shared.open(url, options: [:]) { [weak self] ok in
            guard !ok, let updater = self else { return }
            Task { @MainActor in updater.message = "\(name) isn't installed on this iPhone." }
        }
    }

    func setRepo(_ r: String) {
        UserDefaults.standard.set(r.trimmed, forKey: Updater.repoKey)
        latest = nil
        message = nil
    }
}
