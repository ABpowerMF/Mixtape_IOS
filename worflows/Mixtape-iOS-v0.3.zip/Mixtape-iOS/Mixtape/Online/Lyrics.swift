import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

struct LyricLine: Hashable {
    let timeMs: Int
    let text: String
}

/// Reads LRC text ("[01:23.45] words"). A line can carry several timestamps.
enum Lrc {
    private static let stamp = try! NSRegularExpression(pattern: "\\[(\\d{1,3}):(\\d{1,2})(?:[.:](\\d{1,3}))?\\]")

    static func isLrc(_ text: String) -> Bool {
        text.components(separatedBy: .newlines).filter { line in
            stamp.firstMatch(in: line, range: NSRange(location: 0, length: (line as NSString).length)) != nil
        }.count >= 2
    }

    static func parse(_ text: String) -> [LyricLine] {
        var out: [LyricLine] = []
        for raw in text.components(separatedBy: .newlines) {
            let ns = raw as NSString
            let stamps = stamp.matches(in: raw, range: NSRange(location: 0, length: ns.length))
            guard let lastStamp = stamps.last else { continue }
            let words = ns.substring(from: lastStamp.range.location + lastStamp.range.length).trimmed
            for m in stamps {
                let min = Int(ns.substring(with: m.range(at: 1))) ?? 0
                let sec = Int(ns.substring(with: m.range(at: 2))) ?? 0
                var fracMs = 0
                if m.range(at: 3).location != NSNotFound {
                    let frac = ns.substring(with: m.range(at: 3))
                    switch frac.count {
                    case 1: fracMs = (Int(frac) ?? 0) * 100
                    case 2: fracMs = (Int(frac) ?? 0) * 10
                    default: fracMs = Int(frac.prefix(3)) ?? 0
                    }
                }
                out.append(LyricLine(timeMs: min * 60_000 + sec * 1000 + fracMs, text: words))
            }
        }
        return out.sorted { $0.timeMs < $1.timeMs }
    }

    /// Index of the line being sung at [positionMs], or -1 before the first line.
    static func currentIndex(_ lines: [LyricLine], _ positionMs: Int) -> Int {
        var lo = 0, hi = lines.count - 1, best = -1
        while lo <= hi {
            let mid = (lo + hi) / 2
            if lines[mid].timeMs <= positionMs { best = mid; lo = mid + 1 } else { hi = mid - 1 }
        }
        return best
    }
}

struct LyricsResult: Codable {
    var synced: String
    var plain: String
    var instrumental: Bool
    /// Lyrics the user pasted themselves.
    var own: Bool = false
}

/// Synced (LRC) or plain lyrics from LRCLIB, kept forever once found.
enum LyricsRepo {
    private static func file(_ key: String) -> URL {
        Store.cacheFolder("lyrics").appendingPathComponent(String(TOTP.hexSHA1(key.lowercased()).prefix(24)) + ".json")
    }
    private static func ownFile(_ key: String) -> URL {
        let dir = Store.dataFolder.appendingPathComponent("lyrics", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent(String(TOTP.hexSHA1(key.lowercased()).prefix(24)) + ".json")
    }

    static func key(for song: Song) -> String { "\(song.artist)|\(song.title)" }

    static func saveOwn(_ text: String, for song: Song) {
        let r = LyricsResult(synced: Lrc.isLrc(text) ? text : "", plain: Lrc.isLrc(text) ? "" : text, instrumental: false, own: true)
        if let d = try? JSONEncoder().encode(r) { try? d.write(to: ownFile(key(for: song)), options: .atomic) }
    }

    static func removeOwn(for song: Song) {
        try? FileManager.default.removeItem(at: ownFile(key(for: song)))
    }

    static func cached(for song: Song) -> LyricsResult?? {
        let k = key(for: song)
        if let d = try? Data(contentsOf: ownFile(k)), let r = try? JSONDecoder().decode(LyricsResult.self, from: d) { return .some(r) }
        guard let d = try? Data(contentsOf: file(k)) else { return nil }
        if d == Data("null".utf8) { return .some(nil) }
        return .some(try? JSONDecoder().decode(LyricsResult.self, from: d))
    }

    static func fetch(for song: Song) async throws -> LyricsResult? {
        if let hit = cached(for: song) { return hit }
        guard Prefs.bool(Prefs.lyricsOnline, true) else {
            throw StepError(step: "lyrics", message: "Finding lyrics online is off (Settings › Player).")
        }
        let title = TextMatch.normalizeTitle(song.title).isEmpty ? song.title : cleanTitle(song.title)
        var q = "track_name=\(title.urlQueryEncoded)&artist_name=\(song.mainArtist.urlQueryEncoded)"
        if !song.album.isEmpty { q += "&album_name=\(song.album.urlQueryEncoded)" }
        if song.durationMs > 0 {
            let seconds: Int = (song.durationMs + 500) / 1000
            q += "&duration=\(seconds)"
        }
        var found: J?
        let reply = try await Http.request("https://lrclib.net/api/get?\(q)", step: "lyrics", ua: Http.appUA, allowErrors: true)
        if reply.status == 200 { found = reply.json }
        else if reply.status != 404 { throw StepError(step: "lyrics", message: "HTTP \(reply.status)") }
        if found == nil {
            let list = (try? await Http.json("https://lrclib.net/api/search?q=\("\(song.mainArtist) \(title)".urlQueryEncoded)", step: "lyrics", ua: Http.appUA))?.array ?? []
            let wanted: Int = song.durationMs
            func gap(_ j: J) -> Int {
                let seconds: Double = j["duration"].double ?? 0
                return abs(Int(seconds * 1000) - wanted)
            }
            found = list.min { (a: J, b: J) -> Bool in gap(a) < gap(b) }
        }
        let result = found.map {
            LyricsResult(synced: $0["syncedLyrics"].str, plain: $0["plainLyrics"].str, instrumental: $0["instrumental"].bool ?? false)
        }
        let data = result.flatMap { try? JSONEncoder().encode($0) } ?? Data("null".utf8)
        try? data.write(to: file(key(for: song)), options: .atomic)
        return result
    }

    /// "Song (feat. X) - Remastered 2011" → "Song"
    static func cleanTitle(_ s: String) -> String {
        var t = s
        for pattern in ["\\s*[(\\[][^)\\]]*(feat|ft\\.|remaster|version|edit|live|mix)[^)\\]]*[)\\]]", "\\s+-\\s+.*(remaster|version|edit|live|mix).*$"] {
            if let re = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive) {
                t = re.stringByReplacingMatches(in: t, range: NSRange(location: 0, length: (t as NSString).length), withTemplate: "")
            }
        }
        return t.trimmed.isEmpty ? s : t.trimmed
    }
}
