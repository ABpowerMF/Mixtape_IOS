import Foundation
import AVFoundation
import SwiftUI
import UIKit
import YouTubeKit

/// Video covers: the song's music video plays silently in place of the cover, like Spotify's Canvas.
/// The video is found once (saved per song) and streamed in a small size.
actor VideoCovers {
    static let shared = VideoCovers()
    private var urls: [String: URL] = [:]
    private let idsKey = "video.ids"

    func url(for song: Song) async -> URL? {
        if let u = urls[song.id] { return u }
        var ids = UserDefaults.standard.dictionary(forKey: idsKey) as? [String: String] ?? [:]
        var videoId = ids[song.id]
        if videoId == nil {
            videoId = await find(song) ?? ""
            ids[song.id] = videoId
            UserDefaults.standard.set(ids, forKey: idsKey)
        }
        guard let v = videoId, !v.isEmpty else { return nil }
        guard let streams = try? await YouTube(videoID: v, methods: [.local, .remote]).streams else { return nil }
        let playable = streams.filterVideoOnly().filter { s in s.isNativelyPlayable && (s.videoResolution ?? 9999) <= 720 }
        let sorted = playable.sorted { (a: YouTubeKit.Stream, b: YouTubeKit.Stream) -> Bool in
            let x: Int = a.videoResolution ?? 0
            let y: Int = b.videoResolution ?? 0
            return x > y
        }
        // 480p or the next size down: sharp enough for a cover, light on data.
        let pick = sorted.first { ($0.videoResolution ?? 0) <= 480 } ?? sorted.last
        guard let url = pick?.url else { return nil }
        urls[song.id] = url
        return url
    }

    private func find(_ song: Song) async -> String? {
        let title = LyricsRepo.cleanTitle(song.title)
        let query = song.mainArtist.isEmpty ? "\(title) official music video" : "\(song.mainArtist) \(title) official music video"
        guard let hits = try? await YouTubeSearch.videos(query), !hits.isEmpty else { return nil }
        let want = TextMatch.normalize(title)
        let good = hits.first { h in
            let t = TextMatch.normalize(h.title)
            return t.contains(want) && !t.contains("lyric") && !t.contains("audio")
        }
        return (good ?? hits.first)?.videoId
    }
}

/// A muted, looping video filling its frame (for video covers).
struct VideoCoverView: UIViewRepresentable {
    let url: URL
    let playing: Bool

    final class Coordinator {
        var player: AVQueuePlayer?
        var looper: AVPlayerLooper?
        var url: URL?
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> PlayerLayerView {
        let v = PlayerLayerView()
        v.playerLayer.videoGravity = .resizeAspectFill
        v.backgroundColor = .clear
        return v
    }

    func updateUIView(_ v: PlayerLayerView, context: Context) {
        let c = context.coordinator
        if c.url != url {
            c.url = url
            let player = AVQueuePlayer()
            player.isMuted = true
            player.preventsDisplaySleepDuringVideoPlayback = false
            c.looper = AVPlayerLooper(player: player, templateItem: AVPlayerItem(url: url))
            c.player = player
            v.playerLayer.player = player
        }
        if playing { c.player?.play() } else { c.player?.pause() }
    }

    static func dismantleUIView(_ v: PlayerLayerView, coordinator: Coordinator) {
        coordinator.player?.pause()
        coordinator.looper = nil
        coordinator.player = nil
    }
}
