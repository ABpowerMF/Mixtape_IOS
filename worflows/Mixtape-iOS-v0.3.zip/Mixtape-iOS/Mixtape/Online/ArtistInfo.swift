import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

/// Short artist profile: Wikipedia text + the artist's Spotify photo. Kept for 2 weeks once found.
struct ArtistInfo: Codable {
    var name: String
    var description: String
    var extract: String
    var image: String?
    var fromSpotify: Bool
    var pageURL: String?
}

enum ArtistInfoRepo {
    private static func file(_ name: String) -> URL {
        Store.cacheFolder("artist").appendingPathComponent(String(TOTP.hexSHA1(name.lowercased()).prefix(24)) + ".json")
    }

    static func cached(_ name: String) -> ArtistInfo? {
        let f = file(name)
        guard let attrs = try? FileManager.default.attributesOfItem(atPath: f.path),
              let date = attrs[.modificationDate] as? Date, Date().timeIntervalSince(date) < 14 * 24 * 3600,
              let data = try? Data(contentsOf: f) else { return nil }
        return try? JSONDecoder().decode(ArtistInfo.self, from: data)
    }

    static func fetch(_ name: String) async -> ArtistInfo? {
        if let hit = cached(name) { return hit }
        let music = try? NSRegularExpression(pattern: "(musician|singer|rapper|band|producer|dj|composer|songwriter|group|duo|vocalist|music|hip hop|rock|pop|jazz)", options: .caseInsensitive)
        var wiki: J?
        for title in [name, "\(name) (musician)", "\(name) (band)", "\(name) (rapper)", "\(name) (singer)"] {
            let path = title.replacingOccurrences(of: " ", with: "_").urlQueryEncoded
            guard let j = try? await Http.json("https://en.wikipedia.org/api/rest_v1/page/summary/\(path)", step: "wikipedia", ua: Http.appUA) else { continue }
            if j["type"].string == "disambiguation" { continue }
            let text = "\(j["description"].str) \(String(j["extract"].str.prefix(300)))"
            let isMusic = music?.firstMatch(in: text, range: NSRange(location: 0, length: (text as NSString).length)) != nil
            if !isMusic { continue }
            wiki = j
            break
        }
        var image: String?
        var spotifyName: String?
        if let found = try? await Spotify.shared.searchArtist(name) {
            image = found.image
            spotifyName = found.name
        }
        let wikiImage: String? = wiki?["originalimage"]["source"].string ?? wiki?["thumbnail"]["source"].string
        let info = ArtistInfo(
            name: spotifyName ?? wiki?["title"].string ?? name,
            description: wiki?["description"].str ?? "",
            extract: wiki?["extract"].str ?? "",
            image: image ?? wikiImage,
            fromSpotify: image != nil,
            pageURL: wiki?["content_urls"]["desktop"]["page"].string
        )
        if wiki == nil && image == nil { return nil }
        if let data = try? JSONEncoder().encode(info) { try? data.write(to: file(name), options: .atomic) }
        return info
    }
}
