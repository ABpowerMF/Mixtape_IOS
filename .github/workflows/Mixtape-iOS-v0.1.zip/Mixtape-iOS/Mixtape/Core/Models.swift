import Foundation

/// A music file in the app's folder. [id] is the path inside the folder, e.g. "Music/Artist - Song.m4a".
struct Song: Codable, Identifiable, Hashable {
    var id: String
    var title: String
    var artist: String
    var album: String
    var durationMs: Int
    var trackNo: Int = 0
    var size: Int = 0
    var modified: Double = 0
    var added: Double = 0
    var hasArt: Bool = false

    var url: URL { Store.musicRoot.appendingPathComponent(id) }
    var fileName: String { (id as NSString).lastPathComponent }
    var displayArtist: String { artist.isEmpty ? "Unknown artist" : artist }
    var albumKey: String { album.isEmpty ? "" : album.lowercased() }
    /// The first name of "A, B & C" / "A feat. B".
    var mainArtist: String {
        let seps = [", ", " & ", " feat. ", " ft. ", " x ", "; ", " / "]
        var s = artist
        for sep in seps { if let r = s.range(of: sep, options: .caseInsensitive) { s = String(s[..<r.lowerBound]) } }
        return s.trimmed
    }
}

/// One song of a playlist. Spotify songs keep their Spotify details; [songId] is the matched file (if any).
struct PlaylistEntry: Codable, Identifiable, Hashable {
    var id: String = UUID().uuidString
    var title: String
    var artists: [String]
    var album: String = ""
    var durationMs: Int = 0
    var spotifyId: String?
    var songId: String?

    var artistLine: String { artists.joined(separator: ", ") }
    var wanted: WantedSong { WantedSong(title: title, artists: artists, durationMs: durationMs) }
}

struct Playlist: Codable, Identifiable, Hashable {
    var id: String = UUID().uuidString
    var name: String
    /// "playlist", "album", "track" (from Spotify) or "own".
    var kind: String = "own"
    var spotifyId: String?
    var image: String?
    var entries: [PlaylistEntry] = []
    var created: Double = Date().timeIntervalSince1970

    var isOwn: Bool { kind == "own" }
    var matchedCount: Int { entries.filter { $0.songId != nil }.count }
    var spotifyLink: String? { spotifyId.map { "https://open.spotify.com/\(kind == "own" ? "playlist" : kind)/\($0)" } }
}

struct Album: Identifiable, Hashable {
    var id: String
    var name: String
    var artist: String
    var songs: [Song]
    var year: Int = 0
}

enum Store {
    static let fm = FileManager.default
    /// The app's own Documents folder: what people see in the Files app as "On My iPhone › Mixtape".
    static var musicRoot: URL { fm.urls(for: .documentDirectory, in: .userDomainMask)[0] }
    /// Where downloads and imported files go.
    static var musicFolder: URL {
        let u = musicRoot.appendingPathComponent("Music", isDirectory: true)
        try? fm.createDirectory(at: u, withIntermediateDirectories: true)
        return u
    }
    static var dataFolder: URL {
        let u = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("Mixtape", isDirectory: true)
        try? fm.createDirectory(at: u, withIntermediateDirectories: true)
        return u
    }
    static func cacheFolder(_ name: String) -> URL {
        let u = fm.urls(for: .cachesDirectory, in: .userDomainMask)[0].appendingPathComponent(name, isDirectory: true)
        try? fm.createDirectory(at: u, withIntermediateDirectories: true)
        return u
    }

    static func load<T: Decodable>(_ type: T.Type, _ name: String) -> T? {
        guard let data = try? Data(contentsOf: dataFolder.appendingPathComponent(name)) else { return nil }
        return try? JSONDecoder().decode(type, from: data)
    }

    static func save<T: Encodable>(_ value: T, _ name: String) {
        guard let data = try? JSONEncoder().encode(value) else { return }
        try? data.write(to: dataFolder.appendingPathComponent(name), options: .atomic)
    }

    /// A file name that works on every system ("AC/DC: Live?" → "AC-DC- Live").
    static func safeName(_ s: String) -> String {
        let bad = CharacterSet(charactersIn: "/\\:*?\"<>|").union(.controlCharacters)
        let cleaned = s.unicodeScalars.map { bad.contains($0) ? "-" : String($0) }.joined()
        let t = cleaned.trimmed
        return String((t.isEmpty ? "song" : t).prefix(120))
    }

    /// [name].[ext] in [folder], adding " (2)", " (3)"… if taken.
    static func freeURL(in folder: URL, name: String, ext: String) -> URL {
        var u = folder.appendingPathComponent("\(name).\(ext)")
        var n = 2
        while fm.fileExists(atPath: u.path) {
            u = folder.appendingPathComponent("\(name) (\(n)).\(ext)")
            n += 1
        }
        return u
    }

    static func relativeId(_ url: URL) -> String? {
        let root = musicRoot.standardizedFileURL.resolvingSymlinksInPath().path
        let p = url.standardizedFileURL.resolvingSymlinksInPath().path
        guard p.hasPrefix(root) else { return nil }
        var rel = String(p.dropFirst(root.count))
        while rel.hasPrefix("/") { rel.removeFirst() }
        return rel
    }
}

func formatTime(_ ms: Int) -> String {
    let total = max(0, ms / 1000)
    let h = total / 3600, m = (total % 3600) / 60, s = total % 60
    return h > 0 ? String(format: "%d:%02d:%02d", h, m, s) : String(format: "%d:%02d", m, s)
}
