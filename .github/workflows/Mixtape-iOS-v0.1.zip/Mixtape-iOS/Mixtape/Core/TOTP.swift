import Foundation

/// SHA-1 / HMAC-SHA1 / TOTP in plain Swift (no CryptoKit needed), used for Spotify's web-player code.
enum TOTP {
    static func sha1(_ message: [UInt8]) -> [UInt8] {
        var h0: UInt32 = 0x67452301, h1: UInt32 = 0xEFCDAB89, h2: UInt32 = 0x98BADCFE, h3: UInt32 = 0x10325476, h4: UInt32 = 0xC3D2E1F0
        var msg = message
        let bitLen = UInt64(message.count) * 8
        msg.append(0x80)
        while msg.count % 64 != 56 { msg.append(0) }
        for i in (0..<8).reversed() { msg.append(UInt8((bitLen >> (UInt64(i) * 8)) & 0xff)) }
        var w = [UInt32](repeating: 0, count: 80)
        for chunk in stride(from: 0, to: msg.count, by: 64) {
            for i in 0..<16 {
                let b = chunk + i * 4
                w[i] = UInt32(msg[b]) << 24 | UInt32(msg[b + 1]) << 16 | UInt32(msg[b + 2]) << 8 | UInt32(msg[b + 3])
            }
            for i in 16..<80 {
                let x = w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16]
                w[i] = (x << 1) | (x >> 31)
            }
            var a = h0, b = h1, c = h2, d = h3, e = h4
            for i in 0..<80 {
                var f: UInt32, k: UInt32
                switch i {
                case 0..<20: f = (b & c) | (~b & d); k = 0x5A827999
                case 20..<40: f = b ^ c ^ d; k = 0x6ED9EBA1
                case 40..<60: f = (b & c) | (b & d) | (c & d); k = 0x8F1BBCDC
                default: f = b ^ c ^ d; k = 0xCA62C1D6
                }
                let temp = ((a << 5) | (a >> 27)) &+ f &+ e &+ k &+ w[i]
                e = d; d = c; c = (b << 30) | (b >> 2); b = a; a = temp
            }
            h0 = h0 &+ a; h1 = h1 &+ b; h2 = h2 &+ c; h3 = h3 &+ d; h4 = h4 &+ e
        }
        var out: [UInt8] = []
        for h in [h0, h1, h2, h3, h4] {
            out += [UInt8(h >> 24), UInt8((h >> 16) & 0xff), UInt8((h >> 8) & 0xff), UInt8(h & 0xff)]
        }
        return out
    }

    static func hmacSHA1(key: [UInt8], message: [UInt8]) -> [UInt8] {
        var k = key.count > 64 ? sha1(key) : key
        k += [UInt8](repeating: 0, count: 64 - k.count)
        let ipad = k.map { $0 ^ 0x36 }, opad = k.map { $0 ^ 0x5c }
        return sha1(opad + sha1(ipad + message))
    }

    static func hexSHA1(_ s: String) -> String {
        sha1(Array(s.utf8)).map { String(format: "%02x", $0) }.joined()
    }

    /// Spotify web player TOTP: the secret is XOR-scrambled, joined as decimal text, used as an HMAC-SHA1 key.
    static func spotify(secret: [Int], timeMs: Double) -> String {
        let joined = secret.enumerated().map { String($0.element ^ (($0.offset % 33) + 9)) }.joined()
        let counter = UInt64(floor(timeMs / 1000 / 30))
        var msg: [UInt8] = []
        for i in (0..<8).reversed() { msg.append(UInt8((counter >> (UInt64(i) * 8)) & 0xff)) }
        let h = hmacSHA1(key: Array(joined.utf8), message: msg)
        let o = Int(h[h.count - 1] & 0xf)
        let bin = (Int(h[o]) & 0x7f) << 24 | (Int(h[o + 1]) & 0xff) << 16 | (Int(h[o + 2]) & 0xff) << 8 | (Int(h[o + 3]) & 0xff)
        return String(format: "%06d", bin % 1_000_000)
    }
}
