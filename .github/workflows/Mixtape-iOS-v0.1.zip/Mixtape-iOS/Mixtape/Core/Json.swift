import Foundation

/// Small helper for reading loose JSON (Spotify / YouTube answers) without writing a model for everything.
struct J {
    let v: Any?
    init(_ v: Any?) { self.v = v }

    static func parse(_ data: Data) -> J {
        J(try? JSONSerialization.jsonObject(with: data, options: [.fragmentsAllowed]))
    }
    static func parse(_ text: String) -> J { parse(Data(text.utf8)) }

    subscript(_ key: String) -> J { J((v as? [String: Any])?[key]) }
    subscript(_ i: Int) -> J {
        guard let a = v as? [Any], i >= 0, i < a.count else { return J(nil) }
        return J(a[i])
    }

    var exists: Bool { v != nil && !(v is NSNull) }
    var string: String? { v as? String }
    var str: String { (v as? String) ?? "" }
    var int: Int? {
        if let i = v as? Int { return i }
        if let d = v as? Double { return Int(d) }
        if let n = v as? NSNumber { return n.intValue }
        if let s = v as? String { return Int(s) }
        return nil
    }
    var double: Double? {
        if let d = v as? Double { return d }
        if let i = v as? Int { return Double(i) }
        if let n = v as? NSNumber { return n.doubleValue }
        if let s = v as? String { return Double(s) }
        return nil
    }
    var bool: Bool? { v as? Bool }
    var array: [J] { (v as? [Any])?.map { J($0) } ?? [] }
    var object: [String: Any]? { v as? [String: Any] }
    var keys: [String] { object.map { Array($0.keys) } ?? [] }

    /// First value stored under [key] anywhere inside this JSON (depth first).
    func find(_ key: String) -> J {
        func walk(_ node: Any?) -> Any? {
            if let d = node as? [String: Any] {
                if let hit = d[key], !(hit is NSNull) { return hit }
                for (_, value) in d { if let r = walk(value) { return r } }
            } else if let a = node as? [Any] {
                for value in a { if let r = walk(value) { return r } }
            }
            return nil
        }
        return J(walk(v))
    }

    /// Every object stored under [key] anywhere inside this JSON, in document order.
    func findAll(_ key: String) -> [J] {
        var out: [J] = []
        func walk(_ node: Any?) {
            if let d = node as? [String: Any] {
                if let hit = d[key] { out.append(J(hit)) }
                for (k, value) in d where k != key { walk(value) }
            } else if let a = node as? [Any] {
                for value in a { walk(value) }
            }
        }
        walk(v)
        return out
    }

    static func encode(_ object: Any) -> Data {
        (try? JSONSerialization.data(withJSONObject: object, options: [])) ?? Data()
    }
}

extension String {
    func firstMatch(_ pattern: String, group: Int = 1, options: NSRegularExpression.Options = []) -> String? {
        guard let re = try? NSRegularExpression(pattern: pattern, options: options) else { return nil }
        let ns = self as NSString
        guard let m = re.firstMatch(in: self, range: NSRange(location: 0, length: ns.length)), m.numberOfRanges > group else { return nil }
        let r = m.range(at: group)
        return r.location == NSNotFound ? nil : ns.substring(with: r)
    }

    func allMatches(_ pattern: String, options: NSRegularExpression.Options = []) -> [[String]] {
        guard let re = try? NSRegularExpression(pattern: pattern, options: options) else { return [] }
        let ns = self as NSString
        return re.matches(in: self, range: NSRange(location: 0, length: ns.length)).map { m in
            (0..<m.numberOfRanges).map { i in
                let r = m.range(at: i)
                return r.location == NSNotFound ? "" : ns.substring(with: r)
            }
        }
    }

    var urlQueryEncoded: String {
        var allowed = CharacterSet.alphanumerics
        allowed.insert(charactersIn: "-._~")
        return addingPercentEncoding(withAllowedCharacters: allowed) ?? self
    }

    var trimmed: String { trimmingCharacters(in: .whitespacesAndNewlines) }
}
