import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

/// A failed step of an online job, e.g. "token: HTTP 403". Shown to the user as is.
struct StepError: LocalizedError {
    let step: String
    let message: String
    var errorDescription: String? { "\(step): \(message)" }
    var status: Int? { message.firstMatch("^HTTP (\\d{3})").flatMap { Int($0) } }
}

struct HttpReply {
    let data: Data
    let response: HTTPURLResponse
    var text: String { String(decoding: data, as: UTF8.self) }
    var json: J { J.parse(data) }
    var status: Int { response.statusCode }
    func header(_ name: String) -> String? {
        for (k, v) in response.allHeaderFields {
            if let key = k as? String, key.caseInsensitiveCompare(name) == .orderedSame { return v as? String }
        }
        return nil
    }
}

enum Http {
    static let desktopUA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
    static let appUA = "Mixtape for iPhone (music player)"

    static let session: URLSession = {
        let c = URLSessionConfiguration.default
        c.timeoutIntervalForRequest = 25
        c.httpCookieAcceptPolicy = .always
        c.httpShouldSetCookies = true
        return URLSession(configuration: c)
    }()

    /// Any request. Throws StepError for network failures and for non-2xx answers (unless [allowErrors]).
    static func request(_ url: String, step: String = "request", method: String = "GET", body: Data? = nil,
                        headers: [String: String] = [:], timeout: Double = 20, ua: String = desktopUA,
                        allowErrors: Bool = false) async throws -> HttpReply {
        guard let u = URL(string: url) else { throw StepError(step: step, message: "bad address") }
        var req = URLRequest(url: u, timeoutInterval: timeout)
        req.httpMethod = method
        req.httpBody = body
        req.setValue(ua, forHTTPHeaderField: "User-Agent")
        req.setValue("en", forHTTPHeaderField: "Accept-Language")
        for (k, v) in headers { req.setValue(v, forHTTPHeaderField: k) }
        let reply: HttpReply = try await withCheckedThrowingContinuation { cont in
            let task = session.dataTask(with: req) { data, response, error in
                if let error = error {
                    cont.resume(throwing: StepError(step: step, message: error.localizedDescription))
                } else if let http = response as? HTTPURLResponse {
                    cont.resume(returning: HttpReply(data: data ?? Data(), response: http))
                } else {
                    cont.resume(throwing: StepError(step: step, message: "no answer"))
                }
            }
            task.resume()
        }
        if !allowErrors && !(200..<300).contains(reply.status) {
            let snippet = String(reply.text.prefix(120)).replacingOccurrences(of: "\n", with: " ")
            throw StepError(step: step, message: "HTTP \(reply.status) \(snippet)".trimmed)
        }
        return reply
    }

    static func text(_ url: String, step: String = "request", headers: [String: String] = [:], ua: String = desktopUA) async throws -> String {
        try await request(url, step: step, headers: headers, ua: ua).text
    }

    static func json(_ url: String, step: String = "request", headers: [String: String] = [:], ua: String = desktopUA) async throws -> J {
        try await request(url, step: step, headers: headers, ua: ua).json
    }

    static func postJSON(_ url: String, step: String, object: Any, headers: [String: String] = [:], ua: String = desktopUA) async throws -> J {
        var h = headers
        if h["Content-Type"] == nil { h["Content-Type"] = "application/json" }
        return try await request(url, step: step, method: "POST", body: J.encode(object), headers: h, ua: ua).json
    }
}
