import SwiftUI
import UIKit

/// RGB colour used to build palettes (so contrast can be computed).
struct RGB: Equatable {
    var r: Double, g: Double, b: Double
    init(_ hex: UInt32) {
        r = Double((hex >> 16) & 0xff) / 255
        g = Double((hex >> 8) & 0xff) / 255
        b = Double(hex & 0xff) / 255
    }
    init(r: Double, g: Double, b: Double) { self.r = r; self.g = g; self.b = b }

    var color: Color { Color(red: r, green: g, blue: b) }
    var ui: UIColor { UIColor(red: r, green: g, blue: b, alpha: 1) }

    var luminance: Double {
        func ch(_ c: Double) -> Double { c <= 0.03928 ? c / 12.92 : pow((c + 0.055) / 1.055, 2.4) }
        return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b)
    }
    func lerp(_ o: RGB, _ t: Double) -> RGB { RGB(r: r + (o.r - r) * t, g: g + (o.g - g) * t, b: b + (o.b - b) * t) }
    static func contrast(_ a: RGB, _ b: RGB) -> Double {
        let la = a.luminance + 0.05, lb = b.luminance + 0.05
        return max(la, lb) / min(la, lb)
    }
    var hex: UInt32 {
        func c(_ v: Double) -> UInt32 { UInt32(max(0, min(255, (v * 255).rounded()))) }
        return c(r) << 16 | c(g) << 8 | c(b)
    }
}

/// The app's colours: background, panels, highlights, lines, text, dim text, accent, errors.
struct Palette {
    var ink: Color, deep: Color, raised: Color, gap: Color, paper: Color, fog: Color, tape: Color
    var alert = Color(red: 1, green: 0.37, blue: 0.34)
    var isLight: Bool

    /// Builds a full palette from three colours. Text and accent are nudged until they stand out from the
    /// background, so a theme can never make the app unreadable.
    static func from(_ background: UInt32, _ text: UInt32, _ accent: UInt32) -> Palette {
        let bg = RGB(background)
        var t = RGB(text)
        if RGB.contrast(t, bg) < 4.5 { t = bg.luminance > 0.5 ? RGB(0x111111) : RGB(0xF2F2F2) }
        var a = RGB(accent)
        var step = 0
        while RGB.contrast(a, bg) < 2.5 && step < 10 { a = a.lerp(t, 0.2); step += 1 }
        return Palette(ink: bg.color, deep: bg.lerp(t, 0.05).color, raised: bg.lerp(t, 0.10).color, gap: bg.lerp(t, 0.20).color,
                       paper: t.color, fog: bg.lerp(t, 0.55).color, tape: a.color, isLight: bg.luminance > 0.5)
    }
}

struct ThemeChoice: Identifiable {
    let id: String
    let name: String
    let colors: (UInt32, UInt32, UInt32)
}

/// Theme, style (terminal or rounded) and text size. Same choices as the Android app.
final class ThemeStore: ObservableObject {
    static let choices: [ThemeChoice] = [
        ThemeChoice(id: "terminal", name: "Terminal", colors: (0x050805, 0xCFF5CF, 0x39FF6A)),
        ThemeChoice(id: "mono", name: "Black & white", colors: (0x000000, 0xF2F2F2, 0xFFFFFF)),
        ThemeChoice(id: "paper", name: "White & black", colors: (0xFFFFFF, 0x111111, 0x000000)),
        ThemeChoice(id: "greenwhite", name: "Green & white", colors: (0xFFFFFF, 0x102010, 0x16A34A)),
        ThemeChoice(id: "amber", name: "Amber", colors: (0x0A0700, 0xFFE2A8, 0xFFB000)),
        ThemeChoice(id: "night", name: "Night drive", colors: (0x16202E, 0xEAF0F7, 0xF2C14E)),
        ThemeChoice(id: "softlight", name: "Soft light", colors: (0xF2F2F7, 0x1C1C1E, 0x007AFF)),
        ThemeChoice(id: "softdark", name: "Soft dark", colors: (0x000000, 0xF2F2F7, 0x0A84FF)),
        ThemeChoice(id: "rose", name: "Rose", colors: (0x1A1014, 0xF7E8EE, 0xFF6FA3)),
    ]

    @Published var themeId: String { didSet { save() } }
    @Published var rounded: Bool { didSet { save() } }
    @Published var textScale: Double { didSet { save() } }
    @Published var custom: (UInt32, UInt32, UInt32) { didSet { save() } }

    init() {
        let d = UserDefaults.standard
        themeId = d.string(forKey: "theme.id") ?? "terminal"
        rounded = d.bool(forKey: "theme.rounded")
        let s = d.double(forKey: "theme.scale")
        textScale = s > 0 ? s : 1
        let c = d.array(forKey: "theme.custom") as? [Int]
        custom = c.map { ($0.count == 3) ? (UInt32($0[0]), UInt32($0[1]), UInt32($0[2])) : (0x050805, 0xCFF5CF, 0x39FF6A) } ?? (0x050805, 0xCFF5CF, 0x39FF6A)
    }

    private func save() {
        let d = UserDefaults.standard
        d.set(themeId, forKey: "theme.id")
        d.set(rounded, forKey: "theme.rounded")
        d.set(textScale, forKey: "theme.scale")
        d.set([Int(custom.0), Int(custom.1), Int(custom.2)], forKey: "theme.custom")
    }

    private var cachedKey = ""
    private var cached: Palette?

    /// The current colours (worked out once per theme change, not on every redraw).
    var p: Palette {
        let key = "\(themeId)|\(custom.0)|\(custom.1)|\(custom.2)"
        if key == cachedKey, let c = cached { return c }
        let palette: Palette
        if themeId == "custom" {
            palette = Palette.from(custom.0, custom.1, custom.2)
        } else {
            let c = ThemeStore.choices.first { $0.id == themeId } ?? ThemeStore.choices[0]
            palette = Palette.from(c.colors.0, c.colors.1, c.colors.2)
        }
        cachedKey = key
        cached = palette
        return palette
    }

    func font(_ size: CGFloat, _ weight: Font.Weight = .regular) -> Font {
        .system(size: size * CGFloat(textScale), weight: weight, design: rounded ? .rounded : .monospaced)
    }

    /// Corner radius: square-ish for terminal, round for the Apple style.
    var corner: CGFloat { rounded ? 14 : 4 }
    var coverCorner: CGFloat { rounded ? 10 : 3 }

    private func cap(_ s: String) -> String { s.prefix(1).uppercased() + s.dropFirst() }
    func path(_ name: String) -> String { rounded ? cap(name) : "~/\(name)" }
    func btn(_ label: String) -> String { rounded ? cap(label) : "[ \(label) ]" }
    func head(_ text: String) -> String { rounded ? cap(text) : "> \(text)" }
}
