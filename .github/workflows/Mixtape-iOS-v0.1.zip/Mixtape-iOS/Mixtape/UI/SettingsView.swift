import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct SettingsView: View {
    @EnvironmentObject var model: AppModel
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var player: Player
    @State private var picking = false
    @State private var showLook = true
    @State private var showLibrary = true

    private var version: String {
        let v = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "?"
        return "Mixtape for iPhone v\(v)"
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                Header(title: "settings", subtitle: version)

                fold("look", open: $showLook) {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Theme").font(theme.font(13)).foregroundColor(theme.p.fog)
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 100), spacing: 10)], spacing: 10) {
                            ForEach(ThemeStore.choices) { c in
                                swatch(id: c.id, name: c.name, colors: c.colors)
                            }
                            swatch(id: "custom", name: "Custom", colors: theme.custom)
                        }
                        if theme.themeId == "custom" {
                            colorRow("Background", 0)
                            colorRow("Text", 1)
                            colorRow("Accent", 2)
                            Text("Text and accent are adjusted automatically if they'd be hard to read.")
                                .font(theme.font(11)).foregroundColor(theme.p.fog)
                        }
                        Text("Style").font(theme.font(13)).foregroundColor(theme.p.fog).padding(.top, 6)
                        HStack(spacing: 8) {
                            styleChip("Terminal", selected: !theme.rounded) { theme.rounded = false }
                            styleChip("Rounded", selected: theme.rounded) { theme.rounded = true }
                        }
                        Text("Text size").font(theme.font(13)).foregroundColor(theme.p.fog).padding(.top, 6)
                        HStack {
                            Text("A").font(theme.font(12)).foregroundColor(theme.p.fog)
                            Slider(value: $theme.textScale, in: 0.85...1.25, step: 0.05).tint(theme.p.tape)
                            Text("A").font(theme.font(18)).foregroundColor(theme.p.fog)
                        }
                    }
                }

                fold("library", open: $showLibrary) {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("\(model.songs.count) songs · \(model.albums.count) albums · \(model.playlists.count) playlists")
                            .font(theme.font(13)).foregroundColor(theme.p.paper)
                        HStack(spacing: 8) {
                            MixButton(label: "import files / folder", icon: "folder", primary: true) { picking = true }
                            MixButton(label: model.scanning ? "scanning…" : "rescan", icon: "arrow.clockwise") { Task { await model.rescan() } }
                        }
                        Text("Your music lives in the Files app › On My iPhone › Mixtape. Anything you put there shows up here. Mixtape can only see that folder (iPhones don't let apps look through the rest).")
                            .font(theme.font(12)).foregroundColor(theme.p.fog)
                    }
                }

                SectionTitle(text: "playback")
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text("Sleep timer").font(theme.font(14)).foregroundColor(theme.p.paper)
                        Spacer()
                        Menu {
                            ForEach([15, 30, 45, 60, 90], id: \.self) { m in
                                Button("\(m) minutes") { player.setSleep(minutes: m) }
                            }
                            Button("Off") { player.setSleep(minutes: nil) }
                        } label: {
                            Text(player.sleepAt.map { "until \($0.formatted(date: .omitted, time: .shortened))" } ?? "off")
                                .font(theme.font(13)).foregroundColor(theme.p.tape)
                        }
                    }
                    Text("Lock screen, Control Center, AirPods and car buttons all control Mixtape.")
                        .font(theme.font(12)).foregroundColor(theme.p.fog)
                }
                .padding(.horizontal, 16)

                SectionTitle(text: "about")
                Text("Made by Andre. Lyrics from LRCLIB. Playlists read from Spotify's public pages, no account needed. Downloads use YouTube.")
                    .font(theme.font(12)).foregroundColor(theme.p.fog)
                    .padding(.horizontal, 16)
                Text("Installed with Sideloadly? Apps signed with a free Apple ID stop opening after 7 days: plug in and sideload again (your music and playlists stay).")
                    .font(theme.font(12)).foregroundColor(theme.p.fog)
                    .padding(.horizontal, 16).padding(.top, 8)
            }
            .padding(.bottom, 24)
        }
        .mixScreen(theme)
        .toolbar(.hidden, for: .navigationBar)
        .fileImporter(isPresented: $picking, allowedContentTypes: [.audio, .folder], allowsMultipleSelection: true) { result in
            if case .success(let urls) = result { model.importFiles(urls) }
        }
    }

    private func fold<C: View>(_ title: String, open: Binding<Bool>, @ViewBuilder content: () -> C) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Button { withAnimation(.easeInOut(duration: 0.2)) { open.wrappedValue.toggle() } } label: {
                HStack {
                    Text(theme.head(title)).font(theme.font(13, .semibold)).foregroundColor(theme.p.tape)
                    Spacer()
                    Image(systemName: open.wrappedValue ? "chevron.up" : "chevron.down").font(.system(size: 12)).foregroundColor(theme.p.tape)
                }
                .padding(.horizontal, 16).padding(.top, 18).padding(.bottom, 8)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            if open.wrappedValue {
                content().padding(.horizontal, 16)
            }
        }
    }

    private func swatch(id: String, name: String, colors: (UInt32, UInt32, UInt32)) -> some View {
        let p = Palette.from(colors.0, colors.1, colors.2)
        let selected = theme.themeId == id
        return Button { theme.themeId = id } label: {
            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 4) {
                    Circle().fill(p.tape).frame(width: 12, height: 12)
                    Capsule().fill(p.paper).frame(width: 34, height: 5)
                }
                Text(name).font(.system(size: 11, weight: .medium, design: theme.rounded ? .rounded : .monospaced))
                    .foregroundColor(p.paper).lineLimit(1)
            }
            .padding(10)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(RoundedRectangle(cornerRadius: theme.corner).fill(p.ink))
            .overlay(RoundedRectangle(cornerRadius: theme.corner).stroke(selected ? theme.p.tape : theme.p.gap, lineWidth: selected ? 2 : 1))
        }
        .buttonStyle(.plain)
    }

    private func styleChip(_ label: String, selected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(label)
                .font(.system(size: 13, weight: .semibold, design: label == "Rounded" ? .rounded : .monospaced))
                .foregroundColor(selected ? theme.p.ink : theme.p.paper)
                .padding(.horizontal, 14).padding(.vertical, 8)
                .background(RoundedRectangle(cornerRadius: label == "Rounded" ? 16 : 3).fill(selected ? theme.p.tape : theme.p.raised))
        }
        .buttonStyle(.plain)
    }

    private func colorRow(_ label: String, _ which: Int) -> some View {
        let binding = Binding<Color>(
            get: {
                let c = theme.custom
                return RGB([c.0, c.1, c.2][which]).color
            },
            set: { newColor in
                var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
                UIColor(newColor).getRed(&r, green: &g, blue: &b, alpha: &a)
                let hex = RGB(r: Double(r), g: Double(g), b: Double(b)).hex
                var c = theme.custom
                switch which {
                case 0: c.0 = hex
                case 1: c.1 = hex
                default: c.2 = hex
                }
                theme.custom = c
            }
        )
        return ColorPicker(selection: binding, supportsOpacity: false) {
            Text(label).font(theme.font(14)).foregroundColor(theme.p.paper)
        }
    }
}
