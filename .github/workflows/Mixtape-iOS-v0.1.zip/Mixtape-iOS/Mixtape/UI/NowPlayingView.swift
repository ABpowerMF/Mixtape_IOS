import SwiftUI

struct NowPlayingView: View {
    @EnvironmentObject var model: AppModel
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var player: Player
    @EnvironmentObject var nav: Nav
    @Environment(\.dismiss) var dismiss
    @State private var showQueue = false
    @State private var showLyrics = false
    @State private var addIds: [String]?
    @State private var showSleep = false

    var body: some View {
        let song = player.current
        GeometryReader { g in
            let art = min(g.size.width - 48, g.size.height * 0.45)
            VStack(spacing: 0) {
                HStack {
                    Button { dismiss() } label: {
                        Image(systemName: "chevron.down").font(.system(size: 18, weight: .semibold)).frame(width: 44, height: 44)
                    }
                    Spacer()
                    VStack(spacing: 1) {
                        Text(theme.rounded ? "Playing from" : "playing from").font(theme.font(10)).foregroundColor(theme.p.fog)
                        Text(player.source.isEmpty ? "Mixtape" : player.source).font(theme.font(12, .semibold)).foregroundColor(theme.p.paper).lineLimit(1)
                    }
                    Spacer()
                    Menu {
                        if let s = song {
                            Button { addIds = [s.id] } label: { Label("Add to playlist", systemImage: "music.note.list") }
                            if let album = model.albums.first(where: { $0.id == s.albumKey }), !s.album.isEmpty {
                                Button { dismiss(); nav.open(.album(album.id)) } label: { Label("Go to album", systemImage: "square.stack") }
                            }
                        }
                        Button { showSleep = true } label: { Label(player.sleepAt == nil ? "Sleep timer" : "Sleep timer (on)", systemImage: "moon.zzz") }
                    } label: {
                        Image(systemName: "ellipsis").font(.system(size: 18, weight: .semibold)).frame(width: 44, height: 44)
                    }
                }
                .foregroundColor(theme.p.paper)
                .padding(.horizontal, 8)

                Spacer(minLength: 8)
                CoverView(song: song, size: art)
                    .shadow(color: .black.opacity(0.4), radius: 20, y: 8)
                    .gesture(DragGesture(minimumDistance: 30).onEnded { v in
                        if v.translation.width < -60 { player.next() } else if v.translation.width > 60 { player.previous() }
                    })
                Spacer(minLength: 8)

                VStack(alignment: .leading, spacing: 4) {
                    Text(song?.title ?? "Nothing playing").font(theme.font(22, .bold)).foregroundColor(theme.p.paper).lineLimit(2)
                    Text(song?.displayArtist ?? "").font(theme.font(15)).foregroundColor(theme.p.fog).lineLimit(1)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 24)

                Scrubber(clock: player.clock).padding(.horizontal, 24).padding(.top, 14)

                HStack {
                    Button { player.setShuffle(!player.shuffle) } label: {
                        Image(systemName: "shuffle").font(.system(size: 20)).foregroundColor(player.shuffle ? theme.p.tape : theme.p.fog)
                    }
                    Spacer()
                    Button { player.previous() } label: { Image(systemName: "backward.fill").font(.system(size: 30)) }
                    Spacer()
                    Button { player.toggle() } label: {
                        ZStack {
                            Circle().fill(theme.p.paper).frame(width: 72, height: 72)
                            Image(systemName: player.isPlaying ? "pause.fill" : "play.fill").font(.system(size: 30)).foregroundColor(theme.p.ink)
                                .offset(x: player.isPlaying ? 0 : 2)
                        }
                    }
                    Spacer()
                    Button { player.next() } label: { Image(systemName: "forward.fill").font(.system(size: 30)) }
                    Spacer()
                    Button { player.cycleRepeat() } label: {
                        Image(systemName: player.repeatMode == .one ? "repeat.1" : "repeat").font(.system(size: 20))
                            .foregroundColor(player.repeatMode == .off ? theme.p.fog : theme.p.tape)
                    }
                }
                .buttonStyle(.plain)
                .foregroundColor(theme.p.paper)
                .padding(.horizontal, 28)
                .padding(.top, 10)

                HStack {
                    bottomButton("quote.bubble", "lyrics") { showLyrics = true }
                    Spacer()
                    Menu {
                        ForEach([(Float(0.8), "Slowed (0.8×)"), (0.9, "A bit slowed (0.9×)"), (1, "Normal"), (1.1, "Sped up (1.1×)"), (1.25, "Nightcore (1.25×)")], id: \.0) { v in
                            Button { player.setSpeed(v.0) } label: {
                                if player.speed == v.0 { Label(v.1, systemImage: "checkmark") } else { Text(v.1) }
                            }
                        }
                    } label: {
                        VStack(spacing: 3) {
                            Image(systemName: "dial.low").font(.system(size: 18))
                            Text(player.speed == 1 ? "speed" : String(format: "%.2g×", player.speed)).font(theme.font(10))
                        }
                        .foregroundColor(player.speed == 1 ? theme.p.fog : theme.p.tape)
                        .frame(width: 64)
                    }
                    Spacer()
                    bottomButton("list.bullet", "queue") { showQueue = true }
                }
                .padding(.horizontal, 28)
                .padding(.top, 18)
                .padding(.bottom, 12)
            }
        }
        .background(
            LinearGradient(colors: [theme.p.raised, theme.p.ink, theme.p.ink], startPoint: .top, endPoint: .bottom).ignoresSafeArea()
        )
        .sheet(isPresented: $showQueue) { QueueView().mixEnvironment(model, nav) }
        .sheet(isPresented: $showLyrics) {
            if let s = song { LyricsView(song: s).mixEnvironment(model, nav) }
        }
        .sheet(isPresented: Binding(get: { addIds != nil }, set: { if !$0 { addIds = nil } })) {
            AddToPlaylistSheet(ids: addIds ?? []).mixEnvironment(model, nav)
        }
        .confirmationDialog("Sleep timer", isPresented: $showSleep, titleVisibility: .visible) {
            ForEach([10, 15, 30, 45, 60, 90], id: \.self) { m in
                Button("\(m) minutes") { player.setSleep(minutes: m); model.show("Stops in \(m) minutes") }
            }
            if player.sleepAt != nil { Button("Turn off", role: .destructive) { player.setSleep(minutes: nil) } }
        }
    }

    private func bottomButton(_ icon: String, _ label: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 3) {
                Image(systemName: icon).font(.system(size: 18))
                Text(label).font(theme.font(10))
            }
            .foregroundColor(theme.p.fog)
            .frame(width: 64)
        }
        .buttonStyle(.plain)
    }
}

/// Draggable progress bar with times.
struct Scrubber: View {
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var player: Player
    @ObservedObject var clock: PlayerClock
    @State private var dragging: Double?

    var body: some View {
        let duration = max(1, clock.durationMs)
        let shown = dragging ?? Double(clock.positionMs) / Double(duration)
        VStack(spacing: 6) {
            GeometryReader { g in
                ZStack(alignment: .leading) {
                    Capsule().fill(theme.p.gap).frame(height: 4)
                    Capsule().fill(theme.p.tape).frame(width: g.size.width * min(1, max(0, shown)), height: 4)
                    Circle().fill(theme.p.paper).frame(width: dragging == nil ? 12 : 18, height: dragging == nil ? 12 : 18)
                        .offset(x: g.size.width * min(1, max(0, shown)) - (dragging == nil ? 6 : 9))
                }
                .frame(height: 24)
                .contentShape(Rectangle())
                .gesture(DragGesture(minimumDistance: 0).onChanged { v in
                    dragging = min(1, max(0, v.location.x / g.size.width))
                }.onEnded { v in
                    let f = min(1, max(0, v.location.x / g.size.width))
                    player.seek(to: Int(f * Double(duration)))
                    dragging = nil
                })
            }
            .frame(height: 24)
            HStack {
                Text(formatTime(Int(shown * Double(duration)))).font(theme.font(11)).foregroundColor(theme.p.fog)
                Spacer()
                Text("-" + formatTime(duration - Int(shown * Double(duration)))).font(theme.font(11)).foregroundColor(theme.p.fog)
            }
        }
    }
}
