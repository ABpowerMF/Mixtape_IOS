import SwiftUI

struct PlaylistView: View {
    @EnvironmentObject var model: AppModel
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var player: Player
    @EnvironmentObject var nav: Nav
    @EnvironmentObject var downloader: Downloader
    let playlistId: String
    @State private var query = ""
    @State private var updating = false
    @State private var renaming = false
    @State private var newName = ""
    @State private var linking: PlaylistEntry?
    @State private var editing = false

    var body: some View {
        if let p = model.playlist(playlistId) {
            content(p)
        } else {
            Text("This playlist is gone.").font(theme.font(14)).foregroundColor(theme.p.fog)
                .frame(maxWidth: .infinity, maxHeight: .infinity).mixScreen(theme)
        }
    }

    private func filtered(_ p: Playlist) -> [(Int, PlaylistEntry)] {
        let all = Array(p.entries.enumerated())
        let q = TextMatch.normalize(query)
        if q.isEmpty { return all }
        return all.filter { TextMatch.normalize("\($0.element.title) \($0.element.artistLine) \($0.element.album)").contains(q) }
    }

    @ViewBuilder
    private func content(_ p: Playlist) -> some View {
        let missing = p.entries.filter { $0.songId == nil }.count
        let downloading = Set(downloader.jobs.filter { !$0.status.finished && $0.request.playlistId == p.id }.compactMap { $0.request.entryId })
        Group {
            if editing {
                editList(p)
            } else {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 0) {
                        header(p, missing: missing)
                        if p.entries.count > 8 {
                            SearchField(placeholder: "Search in this playlist", text: $query, slim: true).padding(.bottom, 8)
                        }
                        ForEach(filtered(p), id: \.1.id) { pair in
                            entryRow(p, number: pair.0 + 1, entry: pair.1, busy: downloading.contains(pair.1.id))
                        }
                    }
                    .padding(.bottom, 16)
                }
                .scrollDismissesKeyboard(.immediately)
            }
        }
        .mixScreen(theme)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Menu {
                    if p.isOwn {
                        Button { editing.toggle() } label: { Label(editing ? "Done" : "Reorder / remove", systemImage: "arrow.up.arrow.down") }
                    }
                    Button { newName = p.name; renaming = true } label: { Label("Rename", systemImage: "pencil") }
                    if p.spotifyId != nil {
                        Button { update(p) } label: { Label("Update from Spotify", systemImage: "arrow.clockwise") }
                    }
                    Button(role: .destructive) {
                        model.deletePlaylist(p.id)
                        if !nav.playlistsPath.isEmpty { nav.playlistsPath.removeLast() }
                    } label: { Label("Delete playlist", systemImage: "trash") }
                } label: {
                    Image(systemName: editing ? "checkmark" : "ellipsis.circle")
                }
            }
        }
        .alert("Rename playlist", isPresented: $renaming) {
            TextField("Name", text: $newName)
            Button("Save") { model.rename(p.id, to: newName) }
            Button("Cancel", role: .cancel) {}
        }
        .sheet(item: $linking) { e in
            LinkSongSheet(entry: e) { songId in model.link(entry: e.id, in: p.id, to: songId) }.mixEnvironment(model, nav)
        }
    }

    @ViewBuilder
    private func header(_ p: Playlist, missing: Int) -> some View {
        VStack(spacing: 0) {
            RemoteCover(url: p.image, fallback: model.song(p.entries.first(where: { $0.songId != nil })?.songId), title: p.name, size: 200)
                .shadow(color: .black.opacity(0.35), radius: 14, y: 6)
                .padding(.top, 8)
            Text(p.name).font(theme.font(20, .bold)).foregroundColor(theme.p.paper)
                .multilineTextAlignment(.center).padding(.top, 14).padding(.horizontal, 16)
            Text(p.isOwn ? "\(p.entries.count) songs" : "\(p.matchedCount) of \(p.entries.count) songs on your phone")
                .font(theme.font(12)).foregroundColor(theme.p.fog).padding(.top, 3)
            HStack(spacing: 10) {
                MixButton(label: "play", icon: "play.fill", primary: true) { model.play(playlist: p, shuffled: false) }
                MixButton(label: "shuffle", icon: "shuffle") { model.play(playlist: p, shuffled: true) }
            }
            .padding(.top, 14)
            if missing > 0 && !p.isOwn {
                HStack(spacing: 10) {
                    MixButton(label: "download missing (\(missing))", icon: "arrow.down.circle") { model.download(missingIn: p.id) }
                    if updating { ProgressView().tint(theme.p.tape) }
                }
                .padding(.top, 8)
            }
            Text("Swipe a number to the right to queue it · hold a song for more")
                .font(theme.font(11)).foregroundColor(theme.p.fog).padding(.vertical, 12)
        }
        .frame(maxWidth: .infinity)
    }

    @ViewBuilder
    private func entryRow(_ p: Playlist, number: Int, entry: PlaylistEntry, busy: Bool) -> some View {
        let song = model.song(entry.songId)
        let active = song != nil && player.currentId == song?.id
        SwipeToQueue(enabled: song != nil, onQueue: { if let s = song { model.queue(s) } }) {
            Text(active ? "▶" : "\(number)")
                .font(theme.font(12))
                .foregroundColor(active ? theme.p.tape : theme.p.fog)
                .frame(width: 34, height: 44)
        } rest: {
            Button {
                if song != nil { model.play(playlist: p, startEntry: entry.id) }
                else if !busy { model.download(entry: entry, in: p.id) }
            } label: {
                HStack(spacing: 10) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(entry.title).font(theme.font(15, .medium))
                            .foregroundColor(active ? theme.p.tape : (song == nil ? theme.p.fog : theme.p.paper)).lineLimit(1)
                        Text(entry.artistLine.isEmpty ? (song?.displayArtist ?? "") : entry.artistLine)
                            .font(theme.font(12)).foregroundColor(theme.p.fog).lineLimit(1)
                    }
                    Spacer(minLength: 4)
                    if song == nil {
                        if busy {
                            ProgressView().scaleEffect(0.7).tint(theme.p.tape)
                        } else {
                            Image(systemName: "arrow.down.circle").foregroundColor(theme.p.tape)
                        }
                    } else {
                        Text(formatTime(song?.durationMs ?? entry.durationMs)).font(theme.font(11)).foregroundColor(theme.p.fog)
                    }
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 3)
        .contextMenu {
            if let s = song {
                SongMenu(song: s, extra: entryActions(p, entry))
            } else {
                Button { model.download(entry: entry, in: p.id) } label: { Label("Download", systemImage: "arrow.down.circle") }
                ForEach(entryActions(p, entry)) { a in
                    Button(role: a.destructive ? .destructive : nil, action: a.action) { Label(a.title, systemImage: a.icon) }
                }
            }
        }
    }

    private func entryActions(_ p: Playlist, _ e: PlaylistEntry) -> [MenuAction] {
        var out: [MenuAction] = []
        if !p.isOwn {
            out.append(MenuAction(title: e.songId == nil ? "Pick the file myself" : "Wrong song? Pick another", icon: "link") { linking = e })
        }
        out.append(MenuAction(title: "Remove from playlist", icon: "minus.circle", destructive: true) { model.removeEntry(e.id, from: p.id) })
        return out
    }

    private func editList(_ p: Playlist) -> some View {
        List {
            ForEach(p.entries) { e in
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(e.title).font(theme.font(15)).foregroundColor(theme.p.paper).lineLimit(1)
                        Text(e.artistLine).font(theme.font(12)).foregroundColor(theme.p.fog).lineLimit(1)
                    }
                }
                .listRowBackground(theme.p.ink)
            }
            .onMove { from, to in model.moveEntries(in: p.id, from: from, to: to) }
            .onDelete { set in
                for i in set { model.removeEntry(p.entries[i].id, from: p.id) }
            }
        }
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        .environment(\.editMode, .constant(.active))
    }

    private func update(_ p: Playlist) {
        guard let link = p.spotifyLink else { return }
        updating = true
        Task {
            do {
                let n = try await model.importSpotify(link)
                model.show("Updated: \(n.entries.count) songs")
            } catch {
                model.show("Couldn't update: \(error.localizedDescription)")
            }
            updating = false
        }
    }
}

/// Pick which file in the library is this playlist song.
struct LinkSongSheet: View {
    @EnvironmentObject var model: AppModel
    @EnvironmentObject var theme: ThemeStore
    @Environment(\.dismiss) var dismiss
    let entry: PlaylistEntry
    let onPick: (String?) -> Void
    @State private var query = ""

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 0) {
                    Text("Which file is \"\(entry.title)\" by \(entry.artistLine)?")
                        .font(theme.font(13)).foregroundColor(theme.p.fog).padding(16)
                    SearchField(placeholder: "Search your songs", text: $query)
                    ForEach(model.search(query.isEmpty ? entry.title : query).prefix(100)) { s in
                        Button {
                            onPick(s.id)
                            dismiss()
                        } label: {
                            HStack(spacing: 12) {
                                CoverView(song: s, size: 40)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(s.title).font(theme.font(14)).foregroundColor(theme.p.paper).lineLimit(1)
                                    Text(s.displayArtist).font(theme.font(12)).foregroundColor(theme.p.fog).lineLimit(1)
                                }
                                Spacer()
                            }
                            .padding(.horizontal, 16).padding(.vertical, 5)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                    }
                    if entry.songId != nil {
                        MixButton(label: "unlink", icon: "link.badge.plus") { onPick(nil); dismiss() }.padding(16)
                    }
                }
            }
            .mixScreen(theme)
            .navigationTitle(theme.rounded ? "Pick the song" : "~/link")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Close") { dismiss() } } }
        }
        .tint(theme.p.tape)
    }
}
