import SwiftUI
import UniformTypeIdentifiers

enum SongSort: String, CaseIterable {
    case title = "Title", artist = "Artist", added = "Recently added", plays = "Most played"
}

struct SongsView: View {
    @EnvironmentObject var model: AppModel
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var nav: Nav
    @State private var query = ""
    @AppStorage("songs.sort") private var sortRaw = SongSort.title.rawValue
    @State private var picking = false

    private var sort: SongSort { SongSort(rawValue: sortRaw) ?? .title }

    private var list: [Song] {
        let base = query.trimmed.isEmpty ? model.songs : model.search(query)
        switch sort {
        case .title: return base.sorted { $0.title.localizedCaseInsensitiveCompare($1.title) == .orderedAscending }
        case .artist: return base.sorted { ($0.artist.lowercased(), $0.album.lowercased(), $0.trackNo) < ($1.artist.lowercased(), $1.album.lowercased(), $1.trackNo) }
        case .added: return base.sorted { $0.added > $1.added }
        case .plays:
            let plays = Stats.plays()
            return base.sorted { (plays[$0.id] ?? 0) > (plays[$1.id] ?? 0) }
        }
    }

    var body: some View {
        let songs = list
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 0) {
                Header(title: "songs", subtitle: model.scanning && !model.scanProgress.isEmpty ? model.scanProgress : "\(model.songs.count) songs")
                if model.songs.isEmpty && !model.scanning {
                    EmptyLibrary(picking: $picking)
                } else {
                    SearchField(placeholder: "Search songs, artists, albums", text: $query).padding(.top, 10)
                    HStack(spacing: 8) {
                        MixButton(label: "shuffle", icon: "shuffle", primary: true) {
                            model.play(songs, start: -1, source: "Songs", shuffled: true)
                        }
                        Menu {
                            Picker("Sort", selection: $sortRaw) {
                                ForEach(SongSort.allCases, id: \.self) { s in Text(s.rawValue).tag(s.rawValue) }
                            }
                        } label: {
                            HStack(spacing: 4) {
                                Image(systemName: "arrow.up.arrow.down")
                                Text(sort.rawValue.lowercased())
                            }
                            .font(theme.font(12)).foregroundColor(theme.p.fog)
                        }
                        Spacer()
                    }
                    .padding(.horizontal, 16).padding(.vertical, 10)
                    Text("Swipe a cover to the right to queue it · hold a song for more")
                        .font(theme.font(11)).foregroundColor(theme.p.fog)
                        .padding(.horizontal, 16).padding(.bottom, 6)
                    ForEach(Array(songs.enumerated()), id: \.element.id) { i, s in
                        SongRow(song: s) { model.play(songs, start: i, source: "Songs") }
                    }
                }
            }
            .padding(.bottom, 16)
        }
        .scrollDismissesKeyboard(.immediately)
        .mixScreen(theme)
        .toolbar(.hidden, for: .navigationBar)
        .refreshable { await model.rescan() }
        .fileImporter(isPresented: $picking, allowedContentTypes: [.audio, .folder], allowsMultipleSelection: true) { result in
            if case .success(let urls) = result { model.importFiles(urls) }
        }
    }
}

struct EmptyLibrary: View {
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var nav: Nav
    @Binding var picking: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("No music yet.").font(theme.font(18, .bold)).foregroundColor(theme.p.paper)
            Text("Three ways to add songs:")
                .font(theme.font(14)).foregroundColor(theme.p.fog)
            VStack(alignment: .leading, spacing: 8) {
                Text("1. Import files or a whole folder (from iCloud, a USB stick, AirDrop…).")
                Text("2. In the Files app, drop music into On My iPhone › Mixtape.")
                Text("3. Download songs or whole Spotify playlists in the download tab.")
            }
            .font(theme.font(13)).foregroundColor(theme.p.paper)
            HStack(spacing: 8) {
                MixButton(label: "import files", icon: "folder", primary: true) { picking = true }
                MixButton(label: "download", icon: "arrow.down.circle") { nav.tab = .download }
            }
        }
        .padding(16)
    }
}
