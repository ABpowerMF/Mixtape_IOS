import SwiftUI

struct RootView: View {
    @EnvironmentObject var model: AppModel
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var player: Player
    @EnvironmentObject var nav: Nav

    var body: some View {
        TabView(selection: $nav.tab) {
            NavigationStack(path: $nav.songsPath) { SongsView().routes() }
                .tag(Tab.songs)
                .toolbar(.hidden, for: .tabBar)
            NavigationStack(path: $nav.albumsPath) { AlbumsView().routes() }
                .tag(Tab.albums)
                .toolbar(.hidden, for: .tabBar)
            NavigationStack(path: $nav.playlistsPath) { PlaylistsView().routes() }
                .tag(Tab.playlists)
                .toolbar(.hidden, for: .tabBar)
            NavigationStack { DownloadView() }
                .tag(Tab.download)
                .toolbar(.hidden, for: .tabBar)
            NavigationStack { SettingsView() }
                .tag(Tab.settings)
                .toolbar(.hidden, for: .tabBar)
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            VStack(spacing: 0) {
                if player.hasQueue { MiniPlayer() }
                TabBar()
            }
        }
        .tint(theme.p.tape)
        .background(theme.p.ink.ignoresSafeArea())
        .preferredColorScheme(theme.p.isLight ? .light : .dark)
        .overlay(alignment: .top) {
            if let t = model.toast {
                Toast(text: t)
                    .padding(.top, 8)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .onTapGesture { model.toast = nil }
            }
        }
        .animation(.easeOut(duration: 0.2), value: model.toast)
        .sheet(isPresented: $nav.showPlayer) {
            NowPlayingView().mixEnvironment(model, nav)
        }
        .sheet(isPresented: Binding(get: { nav.addToPlaylist != nil && !nav.showPlayer }, set: { if !$0 { nav.addToPlaylist = nil } })) {
            AddToPlaylistSheet(ids: nav.addToPlaylist ?? []).mixEnvironment(model, nav)
        }
        .sheet(item: Binding(get: { nav.showPlayer ? nil : nav.lyricsFor }, set: { nav.lyricsFor = $0 })) { song in
            LyricsView(song: song).mixEnvironment(model, nav)
        }
        .confirmationDialog("Delete this file from your phone?", isPresented: Binding(get: { nav.confirmDelete != nil }, set: { if !$0 { nav.confirmDelete = nil } }), titleVisibility: .visible) {
            Button("Delete \(nav.confirmDelete?.title ?? "song")", role: .destructive) {
                if let s = nav.confirmDelete { model.delete(s) }
                nav.confirmDelete = nil
            }
        }
    }
}

extension View {
    /// Sheets get the app's shared objects explicitly (older iOS versions don't always pass them on).
    func mixEnvironment(_ model: AppModel, _ nav: Nav) -> some View {
        self.environmentObject(model)
            .environmentObject(model.theme)
            .environmentObject(model.player)
            .environmentObject(model.downloader)
            .environmentObject(nav)
    }

    func routes() -> some View {
        navigationDestination(for: Route.self) { r in
            switch r {
            case .album(let id): AlbumView(albumId: id)
            case .playlist(let id): PlaylistView(playlistId: id)
            }
        }
    }
}

struct TabBar: View {
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var nav: Nav
    @EnvironmentObject var downloader: Downloader

    var body: some View {
        HStack(spacing: 0) {
            ForEach(Tab.allCases, id: \.self) { t in
                Button {
                    if nav.tab == t {
                        // Tapping the open tab again goes back to its start.
                        switch t {
                        case .songs: nav.songsPath = []
                        case .albums: nav.albumsPath = []
                        case .playlists: nav.playlistsPath = []
                        default: break
                        }
                    }
                    nav.tab = t
                } label: {
                    VStack(spacing: 3) {
                        ZStack(alignment: .topTrailing) {
                            Image(systemName: t.icon).font(.system(size: 19, weight: nav.tab == t ? .semibold : .regular))
                            if t == .download && downloader.activeCount > 0 {
                                Text("\(downloader.activeCount)")
                                    .font(.system(size: 9, weight: .bold))
                                    .foregroundColor(theme.p.ink)
                                    .padding(.horizontal, 4)
                                    .background(Capsule().fill(theme.p.tape))
                                    .offset(x: 10, y: -4)
                            }
                        }
                        Text(theme.rounded ? t.rawValue.capitalized : t.rawValue).font(theme.font(10))
                    }
                    .foregroundColor(nav.tab == t ? theme.p.tape : theme.p.fog)
                    .frame(maxWidth: .infinity)
                    .padding(.top, 8)
                    .padding(.bottom, 4)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
        }
        .background(theme.p.deep.ignoresSafeArea(edges: .bottom))
        .overlay(alignment: .top) { Rectangle().fill(theme.p.gap).frame(height: 0.5) }
    }
}

struct MiniPlayer: View {
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var player: Player
    @EnvironmentObject var nav: Nav

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                CoverView(song: player.current, size: 42)
                VStack(alignment: .leading, spacing: 2) {
                    Text(player.current?.title ?? "—").font(theme.font(14, .medium)).foregroundColor(theme.p.paper).lineLimit(1)
                    Text(player.current?.displayArtist ?? "").font(theme.font(12)).foregroundColor(theme.p.fog).lineLimit(1)
                }
                Spacer(minLength: 4)
                Button { player.toggle() } label: {
                    Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 22)).foregroundColor(theme.p.paper).frame(width: 44, height: 44)
                }
                .buttonStyle(.plain)
                Button { player.next() } label: {
                    Image(systemName: "forward.fill").font(.system(size: 18)).foregroundColor(theme.p.paper).frame(width: 40, height: 44)
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            ProgressLine(clock: player.clock).padding(.horizontal, 10)
        }
        .background(
            RoundedRectangle(cornerRadius: theme.rounded ? 14 : 4, style: .continuous).fill(theme.p.raised)
        )
        .padding(.horizontal, 8)
        .padding(.bottom, 6)
        .contentShape(Rectangle())
        .onTapGesture { nav.showPlayer = true }
        .gesture(DragGesture(minimumDistance: 20).onEnded { v in
            if v.translation.height < -30 { nav.showPlayer = true }
            else if v.translation.width < -60 { player.next() }
            else if v.translation.width > 60 { player.previous() }
        })
    }
}

struct AddToPlaylistSheet: View {
    @EnvironmentObject var model: AppModel
    @EnvironmentObject var theme: ThemeStore
    @Environment(\.dismiss) var dismiss
    let ids: [String]
    @State private var newName = ""

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    HStack(spacing: 8) {
                        TextField("", text: $newName, prompt: Text("New playlist name").foregroundColor(theme.p.fog))
                            .font(theme.font(15)).foregroundColor(theme.p.paper)
                            .padding(10)
                            .background(RoundedRectangle(cornerRadius: theme.corner).fill(theme.p.raised))
                        MixButton(label: "create", primary: true) {
                            let p = model.createPlaylist(newName, songs: ids)
                            model.show("Added to \(p.name)")
                            dismiss()
                        }
                    }
                    .padding(16)
                    SectionTitle(text: "your playlists")
                    ForEach(model.playlists.filter { $0.isOwn }) { p in
                        Button {
                            model.add(ids, to: p.id)
                            dismiss()
                        } label: {
                            HStack {
                                Text(p.name).font(theme.font(15)).foregroundColor(theme.p.paper)
                                Spacer()
                                Text("\(p.entries.count)").font(theme.font(12)).foregroundColor(theme.p.fog)
                            }
                            .padding(.horizontal, 16).padding(.vertical, 12)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                    }
                    if !model.playlists.contains(where: { $0.isOwn }) {
                        Text("No playlists of your own yet. Type a name above.")
                            .font(theme.font(13)).foregroundColor(theme.p.fog).padding(16)
                    }
                }
            }
            .mixScreen(theme)
            .navigationTitle(theme.rounded ? "Add to playlist" : "~/add-to-playlist")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Close") { dismiss() } } }
        }
        .tint(theme.p.tape)
        .presentationDetents([.medium, .large])
    }
}
