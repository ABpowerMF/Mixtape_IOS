import SwiftUI

/// Spotify-style queue: now playing, "Next in queue" (songs you added) and "Next from" the playlist.
/// Hold and drag a song to move it, swipe left to remove it, tap to jump to it.
struct QueueView: View {
    @EnvironmentObject var model: AppModel
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var player: Player
    @Environment(\.dismiss) var dismiss

    private struct Item: Identifiable {
        let id: String
        let queueIndex: Int
        let song: Song?
    }

    var body: some View {
        let idx = player.index
        let manual = player.manualCount
        let q = player.queue
        let manualItems: [Item] = manual > 0 ? (1...manual).compactMap { k in
            let i = idx + k
            return i < q.count ? Item(id: "\(i)-\(q[i])", queueIndex: i, song: model.song(q[i])) : nil
        } : []
        let restStart = idx + manual + 1
        let restItems: [Item] = restStart < q.count ? (restStart..<min(q.count, restStart + 300)).map { i in
            Item(id: "\(i)-\(q[i])", queueIndex: i, song: model.song(q[i]))
        } : []

        NavigationStack {
            List {
                if let s = player.current {
                    Section {
                        row(s, active: true)
                    } header: { header("now playing") }
                }
                if !manualItems.isEmpty {
                    Section {
                        ForEach(manualItems) { item in
                            row(item.song, active: false)
                                .onTapGesture { player.jump(to: item.queueIndex) }
                        }
                        .onMove { from, to in move(from, to, offset: 0) }
                        .onDelete { set in remove(set.map { manualItems[$0].queueIndex }) }
                    } header: {
                        HStack {
                            header("next in queue")
                            Spacer()
                            Button(theme.btn("clear")) { player.clearManual() }
                                .font(theme.font(12)).foregroundColor(theme.p.tape)
                        }
                    }
                }
                if !restItems.isEmpty {
                    Section {
                        ForEach(restItems) { item in
                            row(item.song, active: false)
                                .onTapGesture { player.jump(to: item.queueIndex) }
                        }
                        .onMove { from, to in move(from, to, offset: manual) }
                        .onDelete { set in remove(set.map { restItems[$0].queueIndex }) }
                    } header: { header("next from: \(player.source.isEmpty ? "your music" : player.source)") }
                }
                if manualItems.isEmpty && restItems.isEmpty {
                    Text("Nothing after this song. Swipe a song's cover to the right to add it here.")
                        .font(theme.font(13)).foregroundColor(theme.p.fog)
                        .listRowBackground(theme.p.ink)
                }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .background(theme.p.ink.ignoresSafeArea())
            .navigationTitle(theme.rounded ? "Queue" : "~/queue")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(theme.p.ink, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Close") { dismiss() } }
                ToolbarItem(placement: .primaryAction) {
                    HStack(spacing: 16) {
                        Button { player.setShuffle(!player.shuffle) } label: {
                            Image(systemName: "shuffle").foregroundColor(player.shuffle ? theme.p.tape : theme.p.fog)
                        }
                        Button { player.cycleRepeat() } label: {
                            Image(systemName: player.repeatMode == .one ? "repeat.1" : "repeat")
                                .foregroundColor(player.repeatMode == .off ? theme.p.fog : theme.p.tape)
                        }
                    }
                }
            }
        }
        .tint(theme.p.tape)
        .preferredColorScheme(theme.p.isLight ? .light : .dark)
    }

    private func header(_ text: String) -> some View {
        Text(theme.head(text)).font(theme.font(13, .semibold)).foregroundColor(theme.p.tape).textCase(nil)
    }

    private func row(_ song: Song?, active: Bool) -> some View {
        HStack(spacing: 12) {
            CoverView(song: song, size: 42)
            VStack(alignment: .leading, spacing: 2) {
                Text(song?.title ?? "Missing song").font(theme.font(14, .medium))
                    .foregroundColor(active ? theme.p.tape : theme.p.paper).lineLimit(1)
                Text(song?.displayArtist ?? "").font(theme.font(12)).foregroundColor(theme.p.fog).lineLimit(1)
            }
            Spacer()
        }
        .contentShape(Rectangle())
        .listRowBackground(theme.p.ink)
        .listRowSeparator(.hidden)
    }

    /// [offset]: where this section starts among the songs after the current one.
    private func move(_ from: IndexSet, _ to: Int, offset: Int) {
        guard let f = from.first else { return }
        let dest = to > f ? to - 1 : to
        player.moveUpcoming(from: offset + f, to: offset + dest)
    }

    private func remove(_ indices: [Int]) {
        for i in indices.sorted(by: >) { player.remove(at: i) }
    }
}
