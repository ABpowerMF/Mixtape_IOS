import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

/// One search result on YouTube Music / YouTube.
struct YTHit: Identifiable, Hashable {
    var id: String { videoId }
    var videoId: String
    var title: String
    var artist: String
    var album: String
    var durationMs: Int
    var thumbnail: String?
    var fromMusic: Bool
}

/// Searching YouTube Music (album versions with square covers) and YouTube, the way the app does on Android.
enum YouTubeSearch {
    private static let musicVersion = "1.20251006.03.00"
    private static let webVersion = "2.20251006.01.00"
    /// "Songs" filter of YouTube Music's search.
    private static let songsParams = "EgWKAQIIAWoMEA4QChADEAQQCRAF"

    static func parseDuration(_ s: String) -> Int? {
        let parts = s.trimmed.split(separator: ":").map { Int($0) }
        guard parts.count >= 2, parts.count <= 3, parts.allSatisfy({ $0 != nil }) else { return nil }
        return parts.reduce(0) { $0 * 60 + ($1 ?? 0) } * 1000
    }

    static func videoId(from link: String) -> String? {
        let t = link.trimmed
        if t.firstMatch("^([A-Za-z0-9_-]{11})$") != nil { return t }
        for p in ["[?&]v=([A-Za-z0-9_-]{11})", "youtu\\.be/([A-Za-z0-9_-]{11})", "/shorts/([A-Za-z0-9_-]{11})", "/embed/([A-Za-z0-9_-]{11})", "/live/([A-Za-z0-9_-]{11})"] {
            if let id = t.firstMatch(p) { return id }
        }
        return nil
    }

    static func isYouTubeLink(_ s: String) -> Bool {
        s.range(of: "(youtube\\.com|youtu\\.be)/", options: .regularExpression) != nil
    }

    /// Songs on YouTube Music for [query].
    static func music(_ query: String) async throws -> [YTHit] {
        let body: [String: Any] = [
            "context": ["client": ["clientName": "WEB_REMIX", "clientVersion": musicVersion, "hl": "en", "gl": "US"]],
            "query": query, "params": songsParams,
        ]
        let json = try await Http.postJSON("https://music.youtube.com/youtubei/v1/search?prettyPrint=false", step: "YouTube Music search",
                                           object: body, headers: ["Origin": "https://music.youtube.com", "Referer": "https://music.youtube.com/",
                                                                   "X-YouTube-Client-Name": "67", "X-YouTube-Client-Version": musicVersion])
        return parseMusic(json)
    }

    static func parseMusic(_ json: J) -> [YTHit] {
        var out: [YTHit] = []
        var seen = Set<String>()
        for r in json.findAll("musicResponsiveListItemRenderer") {
            let vid = r["playlistItemData"]["videoId"].string ?? r["overlay"].find("videoId").string
            guard let videoId = vid, seen.insert(videoId).inserted else { continue }
            func column(_ i: Int) -> [String] {
                r["flexColumns"][i]["musicResponsiveListItemFlexColumnRenderer"]["text"]["runs"].array.map { $0["text"].str }
            }
            let title = column(0).joined()
            if title.isEmpty { continue }
            var pieces = column(1).joined().components(separatedBy: " • ").map { $0.trimmed }.filter { !$0.isEmpty }
            if let first = pieces.first, ["song", "video", "episode"].contains(first.lowercased()) { pieces.removeFirst() }
            var duration = 0
            if let last = pieces.last, let d = parseDuration(last) { duration = d; pieces.removeLast() }
            // Some layouts put the length in a fixed column instead.
            if duration == 0 {
                for c in r["fixedColumns"].array {
                    if let d = parseDuration(c.find("text").find("text").str) { duration = d }
                }
            }
            let artist = pieces.first ?? ""
            let album = pieces.count >= 2 ? pieces[1] : ""
            let thumbs = r["thumbnail"]["musicThumbnailRenderer"]["thumbnail"]["thumbnails"].array
            let thumb = thumbs.last?["url"].string.map(bigThumb)
            out.append(YTHit(videoId: videoId, title: title, artist: artist, album: album, durationMs: duration, thumbnail: thumb, fromMusic: true))
        }
        return out
    }

    /// Regular YouTube videos for [query].
    static func videos(_ query: String) async throws -> [YTHit] {
        let body: [String: Any] = [
            "context": ["client": ["clientName": "WEB", "clientVersion": webVersion, "hl": "en", "gl": "US"]],
            "query": query,
        ]
        let json = try await Http.postJSON("https://www.youtube.com/youtubei/v1/search?prettyPrint=false", step: "YouTube search",
                                           object: body, headers: ["Origin": "https://www.youtube.com", "X-YouTube-Client-Name": "1",
                                                                   "X-YouTube-Client-Version": webVersion])
        var out: [YTHit] = []
        for v in json.findAll("videoRenderer") {
            guard let id = v["videoId"].string else { continue }
            let title = v["title"]["runs"].array.map { $0["text"].str }.joined()
            let owner = v["ownerText"]["runs"][0]["text"].str
            let length = parseDuration(v["lengthText"]["simpleText"].str) ?? 0
            out.append(YTHit(videoId: id, title: title, artist: owner, album: "", durationMs: length,
                             thumbnail: "https://i.ytimg.com/vi/\(id)/hqdefault.jpg", fromMusic: false))
            if out.count >= 8 { break }
        }
        return out
    }

    /// Candidates for a song, best first: YouTube Music songs, then regular videos only if needed.
    /// Ones close to the wanted length come first, so the right version is picked.
    static func candidates(for query: String, durationMs: Int) async -> [YTHit] {
        func rank(_ list: [YTHit]) -> [YTHit] {
            guard durationMs > 0 else { return list }
            let close = list.filter { $0.durationMs > 0 && abs($0.durationMs - durationMs) <= 20_000 }
                .sorted { abs($0.durationMs - durationMs) < abs($1.durationMs - durationMs) }
            let rest = list.filter { h in !close.contains(where: { $0.videoId == h.videoId }) }
            return close + rest
        }
        var music = rank(Array(((try? await self.music(query)) ?? []).prefix(5)))
        if music.isEmpty {
            music = rank(Array(((try? await videos("\(query) audio")) ?? []).prefix(5)))
        }
        return music
    }

    /// "=w60-h60-l90-rj" → a 544 px square cover.
    static func bigThumb(_ url: String) -> String {
        if let r = url.range(of: "=w\\d+-h\\d+[^/]*$", options: .regularExpression) {
            return url.replacingCharacters(in: r, with: "=w544-h544-l90-rj")
        }
        return url
    }

    /// Title / channel of a video link (YouTube's oEmbed), split into artist and song when it says "Artist - Song".
    static func describe(videoId: String) async -> (title: String, artist: String, thumbnail: String) {
        let link = "https://www.youtube.com/watch?v=\(videoId)"
        let thumb = "https://i.ytimg.com/vi/\(videoId)/hqdefault.jpg"
        guard let j = try? await Http.json("https://www.youtube.com/oembed?format=json&url=\(link.urlQueryEncoded)", step: "video info") else {
            return ("YouTube \(videoId)", "", thumb)
        }
        let rawTitle = j["title"].str
        var author = j["author_name"].str
        for suffix in [" - Topic", "VEVO", "Official"] where author.hasSuffix(suffix) { author = String(author.dropLast(suffix.count)).trimmed }
        let cleaned = cleanVideoTitle(rawTitle)
        if let r = cleaned.range(of: " - ") {
            return (String(cleaned[r.upperBound...]).trimmed, String(cleaned[..<r.lowerBound]).trimmed, thumb)
        }
        return (cleaned.isEmpty ? rawTitle : cleaned, author, thumb)
    }

    /// "Song (Official Music Video) [HD]" → "Song"
    static func cleanVideoTitle(_ s: String) -> String {
        var t = s
        let re = try! NSRegularExpression(pattern: "\\s*[(\\[][^)\\]]*(official|video|audio|lyric|visuali[sz]er|hd|hq|4k|mv)[^)\\]]*[)\\]]", options: .caseInsensitive)
        t = re.stringByReplacingMatches(in: t, range: NSRange(location: 0, length: (t as NSString).length), withTemplate: "")
        return t.trimmed
    }
}
