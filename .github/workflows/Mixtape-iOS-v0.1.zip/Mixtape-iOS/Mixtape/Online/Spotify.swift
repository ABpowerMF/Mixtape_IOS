import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

/// A song of a Spotify playlist / album.
struct SpotifyTrack {
    var id: String
    var title: String
    var artists: [String]
    var album: String
    var durationMs: Int
}

struct SpotifyList {
    var kind: String
    var id: String
    var name: String
    var image: String?
    var tracks: [SpotifyTrack]
    var note: String?
}

/// Public Spotify playlists / albums / songs without logging in, ported from the phone and PC apps:
/// the embed page for quick info, then the web player's own "fetchPlaylist" query (anonymous TOTP
/// token) for the full list, 100 songs per page, no song limit.
actor Spotify {
    static let shared = Spotify()

    private let secretsURL = "https://code.thetadev.de/ThetaDev/spotify-secrets/raw/branch/main/secrets/secretDict.json"
    private let fallbackVersion = 61
    private let fallbackSecret = [44, 55, 47, 42, 70, 40, 34, 114, 76, 74, 50, 111, 120, 97, 75, 76, 94, 102, 43, 69, 49, 120, 118, 80, 64, 78]

    private struct Session {
        var accessToken: String
        var clientToken: String?
        var clientVersion: String
        var jsPackURL: String?
        var expiresAt: Double
    }
    private var session: Session?

    private let hashesKey = "spotify.queryHashes"
    private func hashes() -> [String: String] { UserDefaults.standard.dictionary(forKey: hashesKey) as? [String: String] ?? [:] }
    private func remember(_ op: String, _ hash: String) -> String {
        var h = hashes(); h[op] = hash
        UserDefaults.standard.set(h, forKey: hashesKey)
        return hash
    }
    private func forget(_ op: String) {
        var h = hashes(); h[op] = nil
        UserDefaults.standard.set(h, forKey: hashesKey)
    }

    // MARK: - Links

    static func parseLink(_ link: String) -> (kind: String, id: String)? {
        let m = link.allMatches("open\\.spotify\\.com/(?:intl-[a-zA-Z-]+/)?(track|album|playlist)/([A-Za-z0-9]+)").first
        if let m = m, m.count == 3 { return (m[1], m[2]) }
        let uri = link.allMatches("spotify:(track|album|playlist):([A-Za-z0-9]+)").first
        if let u = uri, u.count == 3 { return (u[1], u[2]) }
        return nil
    }

    /// A Spotify playlist / album / song link → its songs.
    func importLink(_ link: String) async throws -> SpotifyList {
        guard let parsed = Spotify.parseLink(link) else {
            throw StepError(step: "link", message: "That isn't a Spotify song, album or playlist link.")
        }
        let kind = parsed.kind, id = parsed.id
        let page = try await Http.text("https://open.spotify.com/embed/\(kind)/\(id)", step: "embed page")
        guard let raw = page.firstMatch("<script id=\"__NEXT_DATA__\"[^>]*>([\\s\\S]*?)</script>") else {
            throw StepError(step: "embed page", message: "Spotify didn't send the song list. Is the link public?")
        }
        let root = J.parse(raw)
        let entity = root.find("entity")
        guard entity.exists else { throw StepError(step: "embed page", message: "Spotify didn't send the song list. Is the link public?") }
        let name = entity["name"].string ?? entity["title"].string ?? "Spotify \(kind)"
        var tracks: [SpotifyTrack]
        if kind == "track" {
            var artists = entity["artists"].array.compactMap { $0["name"].string }
            if artists.isEmpty { artists = Spotify.splitArtists(entity["subtitle"].str) }
            tracks = [SpotifyTrack(id: id, title: name, artists: artists, album: "", durationMs: entity["duration"].int ?? 0)]
        } else {
            tracks = entity["trackList"].array.compactMap { t in
                guard let title = t["title"].string, !title.isEmpty else { return nil }
                let uriId = t["uri"].str.components(separatedBy: ":").last ?? ""
                return SpotifyTrack(id: uriId.isEmpty ? "embed:\(title)" : uriId, title: title.trimmed,
                                    artists: Spotify.splitArtists(t["subtitle"].str),
                                    album: kind == "album" ? name : "", durationMs: t["duration"].int ?? 0)
            }
        }
        var note: String?
        let embedToken = root.find("accessToken").string
        if kind == "playlist" {
            do {
                let full = try await fullPlaylist(id, embedToken: embedToken)
                if full.tracks.count >= tracks.count { tracks = full.tracks }
            } catch {
                if tracks.count >= 99 {
                    note = "Got the first \(tracks.count) songs (Spotify refused the full list: \(error.localizedDescription)). Try updating it later."
                }
            }
        } else if kind == "album", tracks.count >= 50, let token = embedToken {
            if let full = try? await albumTracks(id, token: token, albumName: name), full.count > tracks.count { tracks = full }
        }
        var image = try? await cover(kind: kind, id: id)
        if image == nil { image = Spotify.pickImage(raw) }
        return SpotifyList(kind: kind, id: id, name: name, image: image, tracks: tracks, note: note)
    }

    static func splitArtists(_ s: String) -> [String] {
        s.replacingOccurrences(of: "\u{00a0}", with: " ").components(separatedBy: ", ").map { $0.trimmed }.filter { !$0.isEmpty }
    }

    static func pickImage(_ raw: String) -> String? {
        let urls = raw.allMatches("https://i\\.scdn\\.co/image/[0-9a-f]{40}").map { $0[0] }
        return urls.first { $0.contains("ab67616d0000b273") } ?? urls.first
    }

    /// The 640 px cover of a song / album / playlist (oEmbed).
    func cover(kind: String, id: String) async throws -> String? {
        let link = "https://open.spotify.com/\(kind)/\(id)"
        let j = try await Http.json("https://open.spotify.com/oembed?url=\(link.urlQueryEncoded)", step: "cover")
        guard let thumb = j["thumbnail_url"].string, !thumb.isEmpty else { return nil }
        return thumb.replacingOccurrences(of: "ab67616d00001e02", with: "ab67616d0000b273")
            .replacingOccurrences(of: "ab67616d00004851", with: "ab67616d0000b273")
    }

    private func albumTracks(_ id: String, token: String, albumName: String) async throws -> [SpotifyTrack] {
        var out: [SpotifyTrack] = []
        var next: String? = "https://api.spotify.com/v1/albums/\(id)/tracks?limit=50"
        var pages = 0
        while let url = next, pages < 40 {
            pages += 1
            let page = try await Http.json(url, step: "album", headers: ["Authorization": "Bearer \(token)"])
            for t in page["items"].array {
                guard let name = t["name"].string else { continue }
                out.append(SpotifyTrack(id: t["id"].string ?? "embed:\(name)", title: name,
                                        artists: t["artists"].array.compactMap { $0["name"].string },
                                        album: albumName, durationMs: t["duration_ms"].int ?? 0))
            }
            next = page["next"].string
        }
        return out
    }

    // MARK: - Web player session

    private func latestSecret() async -> (Int, [Int]) {
        guard let j = try? await Http.json(secretsURL, step: "secrets"), let dict = j.object else { return (fallbackVersion, fallbackSecret) }
        var bestV = -1
        var best: [Int]?
        for (k, v) in dict {
            guard let n = Int(k), let arr = v as? [Any] else { continue }
            let nums = arr.compactMap { J($0).int }
            if n > bestV && nums.count == arr.count { bestV = n; best = nums }
        }
        if let b = best { return (bestV, b) }
        return (fallbackVersion, fallbackSecret)
    }

    private func currentSession(embedToken: String?) async throws -> Session {
        let now = Date().timeIntervalSince1970 * 1000
        if let s = session, s.expiresAt > now + 60_000 { return s }
        let home = try await Http.request("https://open.spotify.com/", step: "home page")
        let html = home.text
        var clientVersion: String?
        if let cfg = html.firstMatch("<script id=\"appServerConfig\" type=\"text/plain\">([^<]+)</script>"),
           let data = Data(base64Encoded: cfg) {
            clientVersion = J.parse(data)["clientVersion"].string
        }
        clientVersion = clientVersion ?? html.firstMatch("\"clientVersion\":\"([^\"]+)\"") ?? "1.2.70.0"
        var jsPack = html.firstMatch("src=\"([^\"]*web-player/web-player[^\"]*\\.js)\"")
        if let j = jsPack, j.hasPrefix("//") { jsPack = "https:" + j }
        let cookies = HTTPCookieStorage.shared.cookies(for: URL(string: "https://open.spotify.com/")!) ?? []
        let deviceId = cookies.first { $0.name == "sp_t" }?.value ?? UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased()

        var token: String?
        var clientId: String?
        var expires = now + 50 * 60_000
        var tokenError = ""
        do {
            let (version, secret) = await latestSecret()
            let code = TOTP.spotify(secret: secret, timeMs: Date().timeIntervalSince1970 * 1000)
            let url = "https://open.spotify.com/api/token?reason=init&productType=web-player&totp=\(code)&totpServer=\(code)&totpVer=\(version)"
            let res = try await Http.json(url, step: "token")
            token = res["accessToken"].string
            clientId = res["clientId"].string
            if let e = res["accessTokenExpirationTimestampMs"].double, e > 0 { expires = e }
        } catch {
            tokenError = error.localizedDescription
        }
        if token == nil { token = embedToken }
        guard let accessToken = token else {
            throw StepError(step: "token", message: tokenError.isEmpty ? "Spotify gave no access token" : tokenError)
        }

        var clientToken: String?
        if let cid = clientId {
            let body: [String: Any] = ["client_data": [
                "client_version": clientVersion ?? "1.2.70.0", "client_id": cid,
                "js_sdk_data": ["device_brand": "unknown", "device_model": "unknown", "os": "windows", "os_version": "NT 10.0",
                                "device_id": deviceId, "device_type": "computer"],
            ]]
            if let res = try? await Http.postJSON("https://clienttoken.spotify.com/v1/clienttoken", step: "client token", object: body,
                                                  headers: ["Accept": "application/json"]) {
                clientToken = res["granted_token"]["token"].string
            }
        }
        let s = Session(accessToken: accessToken, clientToken: clientToken, clientVersion: clientVersion ?? "1.2.70.0",
                        jsPackURL: jsPack, expiresAt: expires)
        session = s
        return s
    }

    static func findQueryHash(_ js: String, _ operation: String) -> String? {
        let op = NSRegularExpression.escapedPattern(for: operation)
        return js.firstMatch("\"\(op)\",\"(?:query|mutation)\",\"([0-9a-f]{64})\"")
    }

    /// The web player's code chunk files ("name.hash.js"), playlist-related ones first.
    static func chunkFiles(_ js: String) -> [String] {
        let maps: [[String: String]] = js.allMatches("\\{(\\d+:\"[^\"]+\"(?:,\\d+:\"[^\"]+\")*)\\}").map { m in
            var d: [String: String] = [:]
            for e in m[1].allMatches("(\\d+):\"([^\"]+)\"") { d[e[1]] = e[2] }
            return d
        }.filter { $0.count >= 5 }
        func isShortHex(_ s: String) -> Bool { s.firstMatch("^([0-9a-f]{6,20})$") != nil }
        let hashMaps = maps.filter { $0.values.allSatisfy(isShortHex) }
        let nameMaps = maps.filter { m in Double(m.values.filter { !isShortHex($0) }.count) > Double(m.count) / 2 }
        var best: ([String: String], [String: String])?
        var bestOverlap = 0
        for names in nameMaps {
            for hashes in hashMaps {
                let overlap = names.keys.filter { hashes[$0] != nil }.count
                if overlap > bestOverlap { bestOverlap = overlap; best = (names, hashes) }
            }
        }
        guard let pair = best else { return [] }
        let names = pair.0, hashes = pair.1
        func rank(_ n: String) -> Int { n.lowercased().contains("playlist") ? 2 : n.lowercased().contains("xpui") ? 1 : 0 }
        return names.compactMap { entry in hashes[entry.key].map { (entry.value, "\(entry.value).\($0).js") } }
            .sorted { rank($0.0) > rank($1.0) }
            .map { $0.1 }
    }

    private func discoverHash(_ s: Session, _ operation: String) async throws -> String {
        guard let pack = s.jsPackURL else { throw StepError(step: "query id", message: "couldn't find the web player code") }
        let main = try await Http.text(pack, step: "query id")
        if let direct = Spotify.findQueryHash(main, operation) { return remember(operation, direct) }
        let base = String(pack[..<(pack.range(of: "/", options: .backwards)?.lowerBound ?? pack.endIndex)])
        let files = Spotify.chunkFiles(main)
        if files.isEmpty { throw StepError(step: "query id", message: "couldn't read the web player's file list") }
        for file in files.prefix(250) {
            guard let js = try? await Http.text("\(base)/\(file)", step: "query id") else { continue }
            if let h = Spotify.findQueryHash(js, operation) { return remember(operation, h) }
        }
        throw StepError(step: "query id", message: "\(operation) not found in \(files.count) web player files")
    }

    private func runOperation(_ s: Session, _ operation: String, _ hash: String, _ variables: [String: Any]) async throws -> J {
        let extensions: [String: Any] = ["persistedQuery": ["version": 1, "sha256Hash": hash]]
        var headers = ["Authorization": "Bearer \(s.accessToken)", "Spotify-App-Version": s.clientVersion,
                       "App-Platform": "WebPlayer", "Accept": "application/json"]
        if let ct = s.clientToken { headers["Client-Token"] = ct }
        var text: String
        do {
            var h = headers
            h["Content-Type"] = "application/json;charset=UTF-8"
            let body: [String: Any] = ["variables": variables, "operationName": operation, "extensions": extensions]
            text = try await Http.request("https://api-partner.spotify.com/pathfinder/v2/query", step: operation, method: "POST",
                                          body: J.encode(body), headers: h).text
        } catch let v2Error {
            let vars = String(decoding: J.encode(variables), as: UTF8.self).urlQueryEncoded
            let ext = String(decoding: J.encode(extensions), as: UTF8.self).urlQueryEncoded
            let url = "https://api-partner.spotify.com/pathfinder/v1/query?operationName=\(operation)&variables=\(vars)&extensions=\(ext)"
            do {
                text = try await Http.request(url, step: operation, headers: headers).text
            } catch let v1Error {
                if let e = v2Error as? StepError, let st = e.status, (400..<500).contains(st) { throw v2Error }
                throw v1Error
            }
        }
        let json = J.parse(text)
        if let first = json["errors"].array.first {
            throw StepError(step: operation, message: first["message"].string ?? "Spotify returned an error")
        }
        return json
    }

    /// Runs a web-player query, finding its id once and retrying after a token or id change.
    func runQuery(_ operation: String, _ variables: [String: Any], knownHash: String? = nil, embedToken: String? = nil) async throws -> J {
        var s = try await currentSession(embedToken: embedToken)
        var hash = hashes()[operation] ?? knownHash
        if hash == nil { hash = try? await discoverHash(s, operation) }
        guard var h = hash else { throw StepError(step: "query id", message: "couldn't find \(operation)") }
        var retriedHash = false, retriedAuth = false
        while true {
            do {
                return try await runOperation(s, operation, h, variables)
            } catch {
                let msg = error.localizedDescription
                if msg.range(of: "PersistedQueryNotFound", options: .caseInsensitive) != nil {
                    forget(operation)
                    if !retriedHash { retriedHash = true; h = try await discoverHash(s, operation); continue }
                }
                if msg.contains("HTTP 401") || msg.contains("HTTP 403"), !retriedAuth {
                    retriedAuth = true
                    session = nil
                    s = try await currentSession(embedToken: embedToken)
                    continue
                }
                throw error
            }
        }
    }

    /// Every song of a public playlist (no 100-song limit).
    func fullPlaylist(_ id: String, embedToken: String? = nil) async throws -> SpotifyList {
        var tracks: [SpotifyTrack] = []
        var name: String?
        var image: String?
        var total = Int.max
        var offset = 0
        while offset < total && offset < 10_000 {
            let json = try await runQuery("fetchPlaylist", ["uri": "spotify:playlist:\(id)", "offset": offset, "limit": 100,
                                                             "enableWatchFeedEntrypoint": false], embedToken: embedToken)
            let p = json["data"]["playlistV2"]
            guard p.exists else { throw StepError(step: "playlist", message: "unexpected answer from Spotify") }
            if p["__typename"].string == "NotFound" {
                throw StepError(step: "playlist", message: "Spotify says this playlist doesn't exist or is private")
            }
            if name == nil {
                name = p["name"].string
                image = p["images"]["items"][0]["sources"][0]["url"].string
            }
            let content = p["content"]
            guard content.exists else { throw StepError(step: "playlist", message: "no song list in answer") }
            total = content["totalCount"].int ?? 0
            let items = content["items"].array
            if items.isEmpty { break }
            for it in items {
                let d = it["itemV2"]["data"]
                guard d.exists, (d["__typename"].string ?? "Track") == "Track" else { continue }
                let title = d["name"].str.trimmed
                if title.isEmpty { continue }
                let artists = d["artists"]["items"].array.compactMap { $0["profile"]["name"].string?.trimmed }.filter { !$0.isEmpty }
                let uriId = d["uri"].str.components(separatedBy: ":").last ?? ""
                tracks.append(SpotifyTrack(id: uriId.isEmpty ? "web:\(title)|\(artists.joined(separator: ","))" : uriId,
                                           title: title, artists: artists, album: d["albumOfTrack"]["name"].str,
                                           durationMs: d["trackDuration"]["totalMilliseconds"].int ?? d["duration"]["totalMilliseconds"].int ?? 0))
            }
            offset += items.count
        }
        return SpotifyList(kind: "playlist", id: id, name: name ?? "Spotify playlist", image: image, tracks: tracks, note: nil)
    }

    /// Finds an artist by name (like Spotify's search) → (name, picture), or nil if no artist has that name.
    func searchArtist(_ name: String) async throws -> (name: String, image: String?)? {
        let json = try await runQuery("searchDesktop", [
            "searchTerm": name, "offset": 0, "limit": 10, "numberOfTopResults": 5, "includeAudiobooks": false,
            "includePreReleases": true, "includeAlbumPreReleases": false, "includeAuthors": false,
            "includeEpisodeContentRatingsV2": false,
        ], knownHash: "eff59fa0a3d026b88b56fddbcf4bdfa16a186b8175a5c1a358c072e053c2e5b0")
        let artists = json["data"]["searchV2"]["artists"]["items"].array
            .map { $0["data"].exists ? $0["data"] : $0["item"]["data"] }
            .filter { $0["uri"].str.hasPrefix("spotify:artist:") }
        let want = TextMatch.normalize(name).replacingOccurrences(of: " ", with: "")
        func key(_ d: J) -> String { TextMatch.normalize(d["profile"]["name"].str).replacingOccurrences(of: " ", with: "") }
        var hit = artists.first { key($0) == want }
        if hit == nil, let first = artists.first, want.count > 3, key(first).contains(want) { hit = first }
        guard let d = hit else { return nil }
        let sources = d["visuals"]["avatarImage"]["sources"].array.sorted { ($0["width"].int ?? 0) > ($1["width"].int ?? 0) }
        return (d["profile"]["name"].string ?? name, sources.first?["url"].string)
    }
}
