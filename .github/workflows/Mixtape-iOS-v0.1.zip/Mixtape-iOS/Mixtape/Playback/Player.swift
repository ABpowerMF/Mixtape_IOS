import Foundation
import Combine
import AVFoundation
import MediaPlayer
import UIKit

enum RepeatMode: String, Codable {
    case off, all, one
    var next: RepeatMode { self == .off ? .all : self == .all ? .one : .off }
}

/// Position of the current song. Kept apart from the Player so only progress bars redraw every tick.
final class PlayerClock: ObservableObject {
    @Published var positionMs: Int = 0
    @Published var durationMs: Int = 0
}

/// Plays the queue with AVPlayer: background audio, lock screen / Control Center / headphone controls,
/// Spotify-style queue ("Next in queue" songs you added, then the rest of the playlist or album).
@MainActor
final class Player: ObservableObject {
    @Published private(set) var queue: [String] = []
    @Published private(set) var index: Int = -1
    @Published private(set) var isPlaying = false
    /// How many songs right after the current one were added by hand ("Next in queue").
    @Published private(set) var manualCount = 0
    @Published private(set) var shuffle = false
    @Published private(set) var repeatMode: RepeatMode = .off
    /// "Playing from" label: a playlist, album, "Songs"…
    @Published private(set) var source = ""
    /// Slowed (vinyl style: slower and lower) or sped up. 1 = normal.
    @Published private(set) var speed: Float = 1
    @Published var sleepAt: Date?

    let clock = PlayerClock()
    /// Looks up a song by id in the library (set by the app model).
    var resolve: (String) -> Song? = { _ in nil }
    /// Called when a song starts (for stats).
    var onSongStarted: ((Song) -> Void)?

    private var original: [String] = []
    private let avp = AVPlayer()
    private var timeObserver: Any?
    private var statusObservation: NSKeyValueObservation?
    private var pendingSeekMs: Int?
    private var wasPlayingBeforeInterruption = false
    private var lastSave = Date.distantPast
    private var sleepTimer: Timer?
    private var visible = true
    private var skippedMissing = 0
    private var tokens: [NSObjectProtocol] = []

    var currentId: String? { index >= 0 && index < queue.count ? queue[index] : nil }
    var current: Song? { currentId.flatMap { resolve($0) } }
    var hasQueue: Bool { currentId != nil }

    init() {
        avp.automaticallyWaitsToMinimizeStalling = false
        avp.allowsExternalPlayback = false
        configureSession()
        setupRemoteCommands()
        observe()
        restoreState()
    }

    // MARK: - Starting things

    /// Plays [ids] starting at [start]. With shuffle on, the start song plays first and the rest is shuffled.
    /// start = -1 picks a random first song (the "shuffle" button).
    func play(_ ids: [String], start: Int, source: String, shuffled: Bool? = nil) {
        guard !ids.isEmpty else { return }
        if let s = shuffled { shuffle = s }
        var list = ids
        var first = start >= 0 && start < ids.count ? start : Int.random(in: 0..<ids.count)
        original = ids
        if shuffle {
            let firstId = list.remove(at: first)
            list.shuffle()
            list.insert(firstId, at: 0)
            first = 0
        }
        queue = list
        index = first
        manualCount = 0
        self.source = source
        skippedMissing = 0
        load(play: true)
    }

    /// Adds songs right after the current one, before everything else ("Play next").
    func playNext(_ ids: [String]) {
        guard !ids.isEmpty else { return }
        guard hasQueue else { play(ids, start: 0, source: "Queue"); return }
        queue.insert(contentsOf: ids, at: index + 1)
        manualCount += ids.count
        saveState(force: true)
    }

    /// Adds songs to the end of "Next in queue".
    func addToQueue(_ ids: [String]) {
        guard !ids.isEmpty else { return }
        guard hasQueue else { play(ids, start: 0, source: "Queue"); return }
        queue.insert(contentsOf: ids, at: index + 1 + manualCount)
        manualCount += ids.count
        saveState(force: true)
    }

    // MARK: - Controls

    func toggle() { isPlaying ? pause() : resume() }

    func resume() {
        guard hasQueue else { return }
        if avp.currentItem == nil {
            load(play: true, seekMs: pendingSeekMs)
            pendingSeekMs = nil
            return
        }
        activateSession()
        avp.playImmediately(atRate: speed)
        updateNowPlaying()
    }

    func pause() {
        avp.pause()
        updateNowPlaying()
        saveState(force: true)
    }

    func next() { advance(auto: false) }

    func previous() {
        if clock.positionMs > 3000 || index <= 0 {
            seek(to: 0)
            if !isPlaying { resume() }
            return
        }
        index -= 1
        load(play: true)
    }

    func seek(to ms: Int) {
        clock.positionMs = ms
        if avp.currentItem == nil {
            pendingSeekMs = ms
            updateNowPlaying()
            return
        }
        avp.seek(to: CMTime(value: Int64(ms), timescale: 1000), toleranceBefore: .zero, toleranceAfter: .zero) { [weak self] _ in
            Task { @MainActor in self?.updateNowPlaying() }
        }
    }

    /// Jumps to a song in the queue (tapping it in the queue screen).
    func jump(to i: Int) {
        guard i >= 0 && i < queue.count else { return }
        let manualEnd = index + manualCount
        if i > index && i <= manualEnd {
            // Songs you queued before it are skipped, like Spotify.
            queue.removeSubrange((index + 1)..<i)
            manualCount = manualEnd - i
            index += 1
        } else if i > manualEnd {
            if manualCount > 0 { queue.removeSubrange((index + 1)...manualEnd) }
            let newIndex = i - manualCount
            manualCount = 0
            index = newIndex
        } else {
            index = i
            manualCount = 0
        }
        load(play: true)
    }

    func remove(at i: Int) {
        guard i >= 0 && i < queue.count, i != index else { return }
        queue.remove(at: i)
        if i < index { index -= 1 } else if i <= index + manualCount { manualCount -= 1 }
        saveState(force: true)
    }

    func clearManual() {
        guard manualCount > 0 else { return }
        queue.removeSubrange((index + 1)...(index + manualCount))
        manualCount = 0
        saveState(force: true)
    }

    /// Reorders the songs after the current one. [from]/[to] count from the first song after it
    /// (moves stay inside their section, so "Next in queue" keeps its size).
    func moveUpcoming(from: Int, to: Int) {
        let a = index + 1 + from, b = index + 1 + to
        guard a != b, a > index, a < queue.count, b > index, b < queue.count else { return }
        let id = queue.remove(at: a)
        queue.insert(id, at: b)
        manualCount = max(0, min(manualCount, queue.count - index - 1))
        saveState(force: true)
    }

    func setShuffle(_ on: Bool) {
        guard on != shuffle else { return }
        shuffle = on
        guard hasQueue else { return }
        let manualEnd = index + manualCount
        let head = Array(queue[...manualEnd])
        var rest = Array(queue[(manualEnd + 1)...])
        if on {
            original = queue
            rest.shuffle()
        } else if let cur = currentId, let pos = original.firstIndex(of: cur) {
            var left = rest
            var ordered: [String] = []
            for id in original[(pos + 1)...] {
                if let k = left.firstIndex(of: id) { ordered.append(id); left.remove(at: k) }
            }
            rest = ordered + left
        }
        queue = head + rest
        saveState(force: true)
    }

    func cycleRepeat() {
        repeatMode = repeatMode.next
        saveState(force: true)
    }

    func setSpeed(_ value: Float) {
        speed = value
        avp.currentItem?.audioTimePitchAlgorithm = value == 1 ? .timeDomain : .varispeed
        if isPlaying { avp.rate = value }
        UserDefaults.standard.set(value, forKey: "player.speed")
        updateNowPlaying()
    }

    func setSleep(minutes: Int?) {
        sleepTimer?.invalidate()
        sleepTimer = nil
        guard let m = minutes else { sleepAt = nil; return }
        let at = Date().addingTimeInterval(Double(m) * 60)
        sleepAt = at
        sleepTimer = Timer.scheduledTimer(withTimeInterval: Double(m) * 60, repeats: false) { [weak self] _ in
            Task { @MainActor in
                self?.pause()
                self?.sleepAt = nil
            }
        }
    }

    /// The screen is on (true) or the app is in the background (false): no progress ticks when nobody sees them.
    func setVisible(_ v: Bool) {
        visible = v
        if v {
            addTimeObserver()
            clock.positionMs = Int(avp.currentTime().seconds.isFinite ? avp.currentTime().seconds * 1000 : Double(clock.positionMs))
        } else {
            removeTimeObserver()
            saveState(force: true)
        }
    }

    /// Drops songs whose files are gone (after a library scan).
    func prune(valid: Set<String>) {
        guard !queue.isEmpty else { return }
        let cur = currentId
        var newQueue: [String] = []
        var newIndex = -1
        var newManual = 0
        for (i, id) in queue.enumerated() {
            guard valid.contains(id) || id == cur else { continue }
            if i == index { newIndex = newQueue.count }
            if i > index && i <= index + manualCount { newManual += 1 }
            newQueue.append(id)
        }
        if newQueue.count != queue.count {
            queue = newQueue
            index = newIndex
            manualCount = newManual
            original = original.filter { valid.contains($0) }
            saveState(force: true)
        }
    }

    // MARK: - Internals

    private func advance(auto: Bool) {
        if auto && repeatMode == .one {
            seek(to: 0)
            avp.playImmediately(atRate: speed)
            return
        }
        if index + 1 < queue.count {
            index += 1
            manualCount = max(0, manualCount - 1)
            load(play: true)
        } else if repeatMode == .all && !queue.isEmpty {
            index = 0
            manualCount = 0
            load(play: true)
        } else if auto {
            avp.pause()
            seek(to: 0)
        }
    }

    private func load(play: Bool, seekMs: Int? = nil) {
        guard let song = current else {
            avp.replaceCurrentItem(with: nil)
            updateNowPlaying()
            return
        }
        if !FileManager.default.fileExists(atPath: song.url.path) {
            // A file deleted in the Files app: skip it (but never loop forever).
            skippedMissing += 1
            if skippedMissing < 20 && index + 1 < queue.count { index += 1; load(play: play); return }
            return
        }
        skippedMissing = 0
        let item = AVPlayerItem(url: song.url)
        item.audioTimePitchAlgorithm = speed == 1 ? .timeDomain : .varispeed
        avp.replaceCurrentItem(with: item)
        clock.durationMs = song.durationMs
        clock.positionMs = seekMs ?? 0
        if let ms = seekMs, ms > 0 {
            avp.seek(to: CMTime(value: Int64(ms), timescale: 1000), toleranceBefore: .zero, toleranceAfter: .zero)
        }
        if play {
            activateSession()
            avp.playImmediately(atRate: speed)
            onSongStarted?(song)
        }
        nowPlayingArtId = nil
        updateNowPlaying()
        saveState(force: true)
    }

    private func configureSession() {
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, policy: .longFormAudio, options: [])
    }

    private func activateSession() {
        try? AVAudioSession.sharedInstance().setActive(true)
    }

    private func observe() {
        statusObservation = avp.observe(\.timeControlStatus, options: [.initial, .new]) { [weak self] player, _ in
            let playing = player.timeControlStatus != .paused
            Task { @MainActor in
                guard let self = self, self.isPlaying != playing else { return }
                self.isPlaying = playing
                self.updateNowPlaying()
            }
        }
        let nc = NotificationCenter.default
        tokens.append(nc.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: nil, queue: .main) { [weak self] note in
            let item = note.object as? AVPlayerItem
            Task { @MainActor in
                guard let self = self, item === self.avp.currentItem else { return }
                self.advance(auto: true)
            }
        })
        tokens.append(nc.addObserver(forName: .AVPlayerItemFailedToPlayToEndTime, object: nil, queue: .main) { [weak self] note in
            let item = note.object as? AVPlayerItem
            Task { @MainActor in
                guard let self = self, item === self.avp.currentItem else { return }
                self.advance(auto: true)
            }
        })
        tokens.append(nc.addObserver(forName: AVAudioSession.interruptionNotification, object: nil, queue: .main) { [weak self] note in
            let info = note.userInfo ?? [:]
            let type = (info[AVAudioSessionInterruptionTypeKey] as? UInt).flatMap { AVAudioSession.InterruptionType(rawValue: $0) }
            let opts = AVAudioSession.InterruptionOptions(rawValue: (info[AVAudioSessionInterruptionOptionKey] as? UInt) ?? 0)
            Task { @MainActor in
                guard let self = self else { return }
                if type == .began {
                    self.wasPlayingBeforeInterruption = self.isPlaying
                } else if type == .ended, opts.contains(.shouldResume), self.wasPlayingBeforeInterruption {
                    self.resume()
                }
            }
        })
        tokens.append(nc.addObserver(forName: AVAudioSession.routeChangeNotification, object: nil, queue: .main) { [weak self] note in
            let reason = (note.userInfo?[AVAudioSessionRouteChangeReasonKey] as? UInt).flatMap { AVAudioSession.RouteChangeReason(rawValue: $0) }
            Task { @MainActor in
                // Headphones unplugged / Bluetooth gone: pause instead of blasting the speaker.
                if reason == .oldDeviceUnavailable { self?.pause() }
            }
        })
        addTimeObserver()
    }

    private func addTimeObserver() {
        guard timeObserver == nil else { return }
        timeObserver = avp.addPeriodicTimeObserver(forInterval: CMTime(value: 1, timescale: 2), queue: .main) { [weak self] t in
            let ms = t.seconds.isFinite ? Int(t.seconds * 1000) : 0
            Task { @MainActor in self?.tick(ms) }
        }
    }

    private func removeTimeObserver() {
        if let o = timeObserver { avp.removeTimeObserver(o) }
        timeObserver = nil
    }

    private func tick(_ ms: Int) {
        guard avp.currentItem != nil else { return }
        if abs(clock.positionMs - ms) >= 250 { clock.positionMs = ms }
        if clock.durationMs <= 0, let d = avp.currentItem?.duration, d.isNumeric { clock.durationMs = Int(d.seconds * 1000) }
        if isPlaying && Date().timeIntervalSince(lastSave) > 15 { saveState() }
    }

    // MARK: - Lock screen

    private var nowPlayingArtId: String?

    private func updateNowPlaying() {
        let center = MPNowPlayingInfoCenter.default()
        guard let song = current else {
            center.nowPlayingInfo = nil
            return
        }
        var info: [String: Any] = center.nowPlayingInfo ?? [:]
        if info[MPMediaItemPropertyTitle] as? String != song.title || nowPlayingArtId != song.id {
            info = [:]
        }
        info[MPMediaItemPropertyTitle] = song.title
        info[MPMediaItemPropertyArtist] = song.displayArtist
        info[MPMediaItemPropertyAlbumTitle] = song.album
        info[MPMediaItemPropertyPlaybackDuration] = Double(max(clock.durationMs, song.durationMs)) / 1000
        info[MPNowPlayingInfoPropertyElapsedPlaybackTime] = avp.currentItem != nil && avp.currentTime().seconds.isFinite ? avp.currentTime().seconds : Double(clock.positionMs) / 1000
        info[MPNowPlayingInfoPropertyPlaybackRate] = isPlaying ? Double(speed) : 0.0
        info[MPNowPlayingInfoPropertyDefaultPlaybackRate] = Double(speed)
        center.nowPlayingInfo = info
        if nowPlayingArtId != song.id {
            nowPlayingArtId = song.id
            Task { [weak self] in
                guard let img = await Artwork.shared.image(for: song) else { return }
                await MainActor.run {
                    guard let self = self, self.currentId == song.id else { return }
                    var i = MPNowPlayingInfoCenter.default().nowPlayingInfo ?? [:]
                    i[MPMediaItemPropertyArtwork] = MPMediaItemArtwork(boundsSize: img.size) { _ in img }
                    MPNowPlayingInfoCenter.default().nowPlayingInfo = i
                }
            }
        }
    }

    private func setupRemoteCommands() {
        let c = MPRemoteCommandCenter.shared()
        c.playCommand.addTarget { [weak self] _ in Task { @MainActor in self?.resume() }; return .success }
        c.pauseCommand.addTarget { [weak self] _ in Task { @MainActor in self?.pause() }; return .success }
        c.togglePlayPauseCommand.addTarget { [weak self] _ in Task { @MainActor in self?.toggle() }; return .success }
        c.nextTrackCommand.addTarget { [weak self] _ in Task { @MainActor in self?.next() }; return .success }
        c.previousTrackCommand.addTarget { [weak self] _ in Task { @MainActor in self?.previous() }; return .success }
        c.changePlaybackPositionCommand.addTarget { [weak self] event in
            guard let e = event as? MPChangePlaybackPositionCommandEvent else { return .commandFailed }
            let ms = Int(e.positionTime * 1000)
            Task { @MainActor in self?.seek(to: ms) }
            return .success
        }
        c.skipForwardCommand.isEnabled = false
        c.skipBackwardCommand.isEnabled = false
    }

    // MARK: - Remembering the queue

    private func saveState(force: Bool = false) {
        guard force || Date().timeIntervalSince(lastSave) > 5 else { return }
        lastSave = Date()
        let d = UserDefaults.standard
        d.set(queue, forKey: "player.queue")
        d.set(original, forKey: "player.original")
        d.set(index, forKey: "player.index")
        d.set(manualCount, forKey: "player.manual")
        d.set(source, forKey: "player.source")
        d.set(shuffle, forKey: "player.shuffle")
        d.set(repeatMode.rawValue, forKey: "player.repeat")
        let pos = avp.currentItem != nil && avp.currentTime().seconds.isFinite ? Int(avp.currentTime().seconds * 1000) : clock.positionMs
        d.set(pos, forKey: "player.position")
    }

    private func restoreState() {
        let d = UserDefaults.standard
        queue = d.stringArray(forKey: "player.queue") ?? []
        original = d.stringArray(forKey: "player.original") ?? queue
        index = queue.isEmpty ? -1 : min(max(0, d.integer(forKey: "player.index")), queue.count - 1)
        manualCount = max(0, min(d.integer(forKey: "player.manual"), max(0, queue.count - index - 1)))
        source = d.string(forKey: "player.source") ?? ""
        shuffle = d.bool(forKey: "player.shuffle")
        repeatMode = RepeatMode(rawValue: d.string(forKey: "player.repeat") ?? "") ?? .off
        let sp = d.float(forKey: "player.speed")
        speed = sp > 0 ? sp : 1
        let pos = d.integer(forKey: "player.position")
        pendingSeekMs = pos > 0 ? pos : nil
        clock.positionMs = pos
    }

    /// After the library is loaded: show the restored song's length and lock screen info.
    func libraryReady() {
        if let s = current, clock.durationMs == 0 { clock.durationMs = s.durationMs }
    }
}
