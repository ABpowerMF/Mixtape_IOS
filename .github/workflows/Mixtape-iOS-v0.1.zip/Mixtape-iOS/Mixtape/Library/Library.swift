import Foundation
import AVFoundation
import UIKit

/// Finds the music files in the app's folder and reads their tags. Results are cached by size + date,
/// so after the first scan only new or changed files are read.
enum Library {
    static let audioExtensions: Set<String> = ["mp3", "m4a", "aac", "wav", "aif", "aiff", "aifc", "flac", "caf", "alac", "m4b", "mp4"]

    struct FileInfo {
        let id: String
        let url: URL
        let size: Int
        let modified: Double
    }

    static func listFiles() -> [FileInfo] {
        let root = Store.musicRoot
        let keys: [URLResourceKey] = [.fileSizeKey, .contentModificationDateKey, .isRegularFileKey, .isDirectoryKey]
        guard let walker = FileManager.default.enumerator(at: root, includingPropertiesForKeys: keys, options: [.skipsHiddenFiles, .skipsPackageDescendants]) else { return [] }
        var out: [FileInfo] = []
        for case let url as URL in walker {
            let values = try? url.resourceValues(forKeys: Set(keys))
            if values?.isDirectory == true {
                if url.lastPathComponent == ".Trash" { walker.skipDescendants() }
                continue
            }
            guard values?.isRegularFile == true, audioExtensions.contains(url.pathExtension.lowercased()) else { continue }
            guard let id = Store.relativeId(url) else { continue }
            out.append(FileInfo(id: id, url: url, size: values?.fileSize ?? 0,
                                modified: values?.contentModificationDate?.timeIntervalSince1970 ?? 0))
        }
        return out
    }

    /// The whole library: cached entries for unchanged files, fresh tags for new / changed ones.
    static func scan(existing: [Song], progress: @escaping (Int, Int) -> Void) async -> [Song] {
        let known = Dictionary(existing.map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a })
        let files = listFiles()
        var out: [Song] = []
        out.reserveCapacity(files.count)
        var fresh = 0
        let todo = files.filter { f in
            guard let k = known[f.id] else { return true }
            return k.size != f.size || abs(k.modified - f.modified) > 1
        }.count
        for f in files {
            if let k = known[f.id], k.size == f.size, abs(k.modified - f.modified) <= 1 {
                out.append(k)
                continue
            }
            var song = await read(f)
            song.added = known[f.id]?.added ?? Date().timeIntervalSince1970
            out.append(song)
            fresh += 1
            if fresh % 10 == 0 { progress(fresh, todo) }
        }
        return out
    }

    static func read(_ f: FileInfo) async -> Song {
        let asset = AVURLAsset(url: f.url)
        var title = "", artist = "", album = "", trackNo = 0, durationMs = 0, hasArt = false
        if let loaded = try? await asset.load(.commonMetadata, .duration) {
            let common = loaded.0, duration = loaded.1
            durationMs = duration.isNumeric ? Int(duration.seconds * 1000) : 0
            title = await string(common, .commonIdentifierTitle) ?? ""
            artist = await string(common, .commonIdentifierArtist) ?? ""
            album = await string(common, .commonIdentifierAlbumName) ?? ""
            hasArt = !AVMetadataItem.metadataItems(from: common, filteredByIdentifier: .commonIdentifierArtwork).isEmpty
        }
        if let all = try? await asset.load(.metadata) {
            if let s = await string(all, .id3MetadataTrackNumber) {
                trackNo = Int(s.split(separator: "/").first.map(String.init) ?? "") ?? 0
            } else if let item = AVMetadataItem.metadataItems(from: all, filteredByIdentifier: .iTunesMetadataTrackNumber).first,
                      let data = try? await item.load(.dataValue), data.count >= 4 {
                trackNo = Int(data[data.startIndex + 2]) << 8 | Int(data[data.startIndex + 3])
            }
            if artist.isEmpty { artist = await string(all, .iTunesMetadataAlbumArtist) ?? "" }
        }
        if title.isEmpty || artist.isEmpty {
            // "Artist - Title.mp3"
            let base = (f.url.deletingPathExtension().lastPathComponent)
            if let r = base.range(of: " - ") {
                if artist.isEmpty { artist = String(base[..<r.lowerBound]).trimmed }
                if title.isEmpty { title = String(base[r.upperBound...]).trimmed }
            } else if title.isEmpty {
                title = base
            }
        }
        return Song(id: f.id, title: title, artist: artist, album: album, durationMs: durationMs, trackNo: trackNo,
                    size: f.size, modified: f.modified, added: Date().timeIntervalSince1970, hasArt: hasArt)
    }

    static func string(_ items: [AVMetadataItem], _ id: AVMetadataIdentifier) async -> String? {
        guard let item = AVMetadataItem.metadataItems(from: items, filteredByIdentifier: id).first else { return nil }
        let s = (try? await item.load(.stringValue)) ?? nil
        guard let v = s?.trimmed, !v.isEmpty else { return nil }
        return v
    }

    static func artworkData(_ url: URL) async -> Data? {
        let asset = AVURLAsset(url: url)
        guard let common = try? await asset.load(.commonMetadata),
              let item = AVMetadataItem.metadataItems(from: common, filteredByIdentifier: .commonIdentifierArtwork).first else { return nil }
        return (try? await item.load(.dataValue)) ?? nil
    }

    /// Copies picked / shared files into the Music folder. Folders are copied song by song.
    static func importFiles(_ urls: [URL]) -> Int {
        var count = 0
        for url in urls {
            let scoped = url.startAccessingSecurityScopedResource()
            defer { if scoped { url.stopAccessingSecurityScopedResource() } }
            var isDir: ObjCBool = false
            FileManager.default.fileExists(atPath: url.path, isDirectory: &isDir)
            if isDir.boolValue {
                let walker = FileManager.default.enumerator(at: url, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles])
                while let f = walker?.nextObject() as? URL {
                    if audioExtensions.contains(f.pathExtension.lowercased()), copyIn(f) { count += 1 }
                }
            } else if audioExtensions.contains(url.pathExtension.lowercased()), copyIn(url) {
                count += 1
            }
        }
        return count
    }

    private static func copyIn(_ url: URL) -> Bool {
        // Already inside the app's folder (e.g. "Open in Mixtape" from the Files app) → nothing to copy.
        if let id = Store.relativeId(url), !id.hasPrefix("Inbox/") { return false }
        let name = url.deletingPathExtension().lastPathComponent
        let dest = Store.freeURL(in: Store.musicFolder, name: Store.safeName(name), ext: url.pathExtension.lowercased())
        do {
            if Store.relativeId(url)?.hasPrefix("Inbox/") == true {
                try FileManager.default.moveItem(at: url, to: dest)
            } else {
                try FileManager.default.copyItem(at: url, to: dest)
            }
            return true
        } catch {
            return false
        }
    }

    /// Moves anything iOS dropped into Documents/Inbox (files opened with Mixtape) into Music.
    static func drainInbox() {
        let inbox = Store.musicRoot.appendingPathComponent("Inbox", isDirectory: true)
        guard let files = try? FileManager.default.contentsOfDirectory(at: inbox, includingPropertiesForKeys: nil) else { return }
        for f in files where audioExtensions.contains(f.pathExtension.lowercased()) { _ = copyIn(f) }
    }
}

/// Covers: from the song files (cached small on disk) and from the internet (Spotify / YouTube).
final class Artwork {
    static let shared = Artwork()
    private let memory = NSCache<NSString, UIImage>()
    private let folder = Store.cacheFolder("art")

    init() { memory.countLimit = 400 }

    private func key(_ song: Song) -> String { TOTP.hexSHA1("\(song.id)|\(Int(song.modified))") }

    func cached(_ song: Song) -> UIImage? { memory.object(forKey: key(song) as NSString) }

    func image(for song: Song) async -> UIImage? {
        guard song.hasArt else { return nil }
        let k = key(song)
        if let hit = memory.object(forKey: k as NSString) { return hit }
        let file = folder.appendingPathComponent(k + ".jpg")
        if let data = try? Data(contentsOf: file), let img = UIImage(data: data) {
            memory.setObject(img, forKey: k as NSString)
            return img
        }
        guard let data = await Library.artworkData(song.url), let full = UIImage(data: data) else { return nil }
        let small = Artwork.resize(full, to: 600)
        if let jpg = small.jpegData(compressionQuality: 0.85) { try? jpg.write(to: file, options: .atomic) }
        memory.setObject(small, forKey: k as NSString)
        return small
    }

    func remote(_ url: String?) async -> UIImage? {
        guard let url = url, !url.isEmpty else { return nil }
        let k = TOTP.hexSHA1(url)
        if let hit = memory.object(forKey: k as NSString) { return hit }
        let file = folder.appendingPathComponent("r-" + k + ".jpg")
        if let data = try? Data(contentsOf: file), let img = UIImage(data: data) {
            memory.setObject(img, forKey: k as NSString)
            return img
        }
        guard let reply = try? await Http.request(url, step: "cover"), let img = UIImage(data: reply.data) else { return nil }
        try? reply.data.write(to: file, options: .atomic)
        memory.setObject(img, forKey: k as NSString)
        return img
    }

    static func resize(_ image: UIImage, to side: CGFloat) -> UIImage {
        let w = image.size.width, h = image.size.height
        guard w > side || h > side else { return image }
        let scale = side / max(w, h)
        let size = CGSize(width: (w * scale).rounded(), height: (h * scale).rounded())
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        return UIGraphicsImageRenderer(size: size, format: format).image { _ in image.draw(in: CGRect(origin: .zero, size: size)) }
    }

    /// Center square crop (YouTube video thumbnails are 4:3 / 16:9).
    static func squareCrop(_ image: UIImage) -> UIImage {
        guard let cg = image.cgImage else { return image }
        let w = cg.width, h = cg.height
        // hqdefault has black bars top and bottom: crop to the 16:9 picture first, then to a square.
        var rect = CGRect(x: 0, y: 0, width: w, height: h)
        if abs(Double(w) / Double(h) - 4.0 / 3.0) < 0.05 {
            let picH = Int(Double(w) * 9 / 16)
            rect = CGRect(x: 0, y: (h - picH) / 2, width: w, height: picH)
        }
        let side = min(rect.width, rect.height)
        let square = CGRect(x: rect.midX - side / 2, y: rect.midY - side / 2, width: side, height: side).integral
        guard let cropped = cg.cropping(to: square) else { return image }
        return UIImage(cgImage: cropped)
    }
}
