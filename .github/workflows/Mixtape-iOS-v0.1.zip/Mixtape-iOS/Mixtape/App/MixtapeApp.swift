import SwiftUI

@main
struct MixtapeApp: App {
    @StateObject private var model = AppModel()
    @StateObject private var nav = Nav()
    @Environment(\.scenePhase) private var phase

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(model)
                .environmentObject(model.theme)
                .environmentObject(model.player)
                .environmentObject(model.downloader)
                .environmentObject(nav)
                .onOpenURL { url in
                    if url.isFileURL { model.importFiles([url]) }
                }
        }
        .onChange(of: phase) { p in
            model.player.setVisible(p == .active)
            if p == .active { Task { await model.rescan() } }
        }
    }
}

enum Tab: String, CaseIterable {
    case songs, albums, playlists, download, settings

    var icon: String {
        switch self {
        case .songs: return "music.note"
        case .albums: return "square.grid.2x2"
        case .playlists: return "music.note.list"
        case .download: return "arrow.down.circle"
        case .settings: return "gearshape"
        }
    }
}

enum Route: Hashable {
    case album(String)
    case playlist(String)
}

/// Which tab is open, what's pushed on each, and the app-wide sheets.
@MainActor
final class Nav: ObservableObject {
    @Published var tab: Tab = .songs
    @Published var songsPath: [Route] = []
    @Published var albumsPath: [Route] = []
    @Published var playlistsPath: [Route] = []
    @Published var showPlayer = false
    @Published var addToPlaylist: [String]?
    @Published var lyricsFor: Song?
    @Published var confirmDelete: Song?

    func open(_ r: Route) {
        showPlayer = false
        switch tab {
        case .songs: songsPath.append(r)
        case .albums: albumsPath.append(r)
        case .playlists: playlistsPath.append(r)
        default:
            if case .album = r { tab = .albums; albumsPath = [r] } else { tab = .playlists; playlistsPath = [r] }
        }
    }
}
