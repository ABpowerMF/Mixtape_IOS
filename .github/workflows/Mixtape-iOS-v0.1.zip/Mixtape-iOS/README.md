# Mixtape for iPhone

The iPhone version of Mixtape (SwiftUI). Builds on GitHub Actions (Mac build machine) into an
unsigned `.ipa` that you install with **Sideloadly**.

## Build
1. Repo (e.g. `mixtape_iOS`) with `.github/workflows/ios.yml` (copy it from this zip).
2. Upload `Mixtape-iOS-vX.Y.zip` to the repo. The workflow builds and publishes a release
   `ios-vX.Y` with `Mixtape-iOS-vX.Y.ipa`.

## Install (Windows PC)
1. Install iTunes and iCloud from apple.com (not the Microsoft Store versions), then Sideloadly.
2. Plug in the iPhone, tap Trust. Drag the .ipa into Sideloadly, type your Apple ID, Start.
3. On the iPhone: Settings › Privacy & Security › Developer Mode › On (restarts the phone).
4. Settings › General › VPN & Device Management › your Apple ID › Trust.
With a free Apple ID the app has to be re-installed every 7 days (Sideloadly can refresh it
automatically over Wi-Fi). Music and playlists stay.

## What's in v0.1
Library (files you import / put in Files › On My iPhone › Mixtape), songs / albums / playlists,
Spotify playlist import with matching (no song limit), downloads from YouTube as tagged .m4a,
player with lock screen controls, Spotify-style queue (swipe a cover/number right to queue),
synced lyrics (LRCLIB), speed (slowed / sped up), sleep timer, themes + terminal / rounded style.
