import Foundation
import Combine
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
import AVFoundation
import UIKit
import YouTubeKit

/// What to download: a song to find on YouTube Music, or a known video.
struct DownloadRequest {
    var title: String
    var artist: String
    var album: String = ""
    var durationMs: Int = 0
    var spotifyId: String?
    /// Set when the user picked a result or pasted a YouTube link.
    var videoId: String?
    var coverURL: String?
    /// The playlist entry this download is for (so it gets linked when done).
    var playlistId: String?
    var entryId: String?

    var label: String { artist.isEmpty ? title : "\(artist) - \(title)" }
}

enum JobStatus: Equatable {
    case queued, searching, downloading, saving, done, failed(String), canceled
    var finished: Bool {
        switch self {
        case .done, .failed, .canceled: return true
        default: return false
        }
    }
}

struct DownloadJob: Identifiable {
    let id = UUID()
    var request: DownloadRequest
    var status: JobStatus = .queued
    var progress: Double = 0
    var fileId: String?
}

/// Downloads songs from YouTube as .m4a (AAC, the format YouTube streams; iPhones play it natively, no ffmpeg),
/// then writes the title / artist / album / cover tags into the file. Two at a time.
@MainActor
final class Downloader: ObservableObject {
    @Published private(set) var jobs: [DownloadJob] = []
    /// Called with the saved file (inside the app folder) and the job's request.
    var onSaved: ((URL, DownloadRequest) -> Void)?

    private var running: [UUID: Task<Void, Never>] = [:]
    private let maxParallel = 2

    var activeCount: Int { jobs.filter { !$0.status.finished }.count }

    func enqueue(_ requests: [DownloadRequest]) {
        for r in requests { jobs.append(DownloadJob(request: r)) }
        pump()
    }

    func cancel(_ id: UUID) {
        running[id]?.cancel()
        running[id] = nil
        update(id) { if !$0.status.finished { $0.status = .canceled } }
        pump()
    }

    func cancelAll() {
        for j in jobs where !j.status.finished { cancel(j.id) }
    }

    func retry(_ id: UUID) {
        update(id) { $0.status = .queued; $0.progress = 0 }
        pump()
    }

    func clearFinished() {
        jobs.removeAll { $0.status.finished }
    }

    private func update(_ id: UUID, _ change: (inout DownloadJob) -> Void) {
        guard let i = jobs.firstIndex(where: { $0.id == id }) else { return }
        change(&jobs[i])
    }

    private func pump() {
        while running.count < maxParallel, let next = jobs.first(where: { $0.status == .queued && running[$0.id] == nil }) {
            let id = next.id
            update(id) { $0.status = .searching }
            running[id] = Task { [weak self] in
                await self?.run(id, next.request)
                await MainActor.run {
                    self?.running[id] = nil
                    self?.pump()
                }
            }
        }
    }

    private func run(_ id: UUID, _ request: DownloadRequest) async {
        do {
            var req = request
            var candidates: [YTHit] = []
            if let v = req.videoId {
                candidates = [YTHit(videoId: v, title: req.title, artist: req.artist, album: req.album, durationMs: req.durationMs, thumbnail: req.coverURL, fromMusic: false)]
            } else {
                candidates = await YouTubeSearch.candidates(for: req.label, durationMs: req.durationMs)
                if candidates.isEmpty { throw StepError(step: "search", message: "nothing found on YouTube") }
            }
            try Task.checkCancellation()
            var lastError: Error = StepError(step: "download", message: "no audio found")
            for hit in candidates.prefix(4) {
                do {
                    let raw = try await downloadAudio(hit.videoId) { [weak self] p in
                        Task { @MainActor in self?.update(id) { $0.status = .downloading; $0.progress = p } }
                    }
                    try Task.checkCancellation()
                    update(id) { $0.status = .saving }
                    if req.album.isEmpty && !hit.album.isEmpty && hit.fromMusic { req.album = hit.album }
                    let cover = await coverImage(req, hit)
                    let saved = try await Tagger.save(raw: raw, request: req, cover: cover)
                    try? FileManager.default.removeItem(at: raw)
                    update(id) { $0.status = .done; $0.progress = 1; $0.fileId = Store.relativeId(saved) }
                    onSaved?(saved, req)
                    return
                } catch is CancellationError {
                    throw CancellationError()
                } catch {
                    lastError = error
                }
            }
            throw lastError
        } catch is CancellationError {
            update(id) { $0.status = .canceled }
        } catch {
            update(id) { $0.status = .failed(error.localizedDescription) }
        }
    }

    private func coverImage(_ req: DownloadRequest, _ hit: YTHit) async -> UIImage? {
        if let url = req.coverURL, let img = await Artwork.shared.remote(url) { return square(img) }
        if let sid = req.spotifyId, !sid.contains(":"), let url = try? await Spotify.shared.cover(kind: "track", id: sid),
           let img = await Artwork.shared.remote(url) { return img }
        if let t = hit.thumbnail, let img = await Artwork.shared.remote(t) { return square(img) }
        if let img = await Artwork.shared.remote("https://i.ytimg.com/vi/\(hit.videoId)/hqdefault.jpg") { return Artwork.squareCrop(img) }
        return nil
    }

    private func square(_ img: UIImage) -> UIImage {
        abs(img.size.width - img.size.height) < 2 ? img : Artwork.squareCrop(img)
    }

    /// The best .m4a audio stream of a video, saved to a temporary file. Downloaded in 8 MB pieces,
    /// which YouTube serves at full speed (one big request gets slowed down).
    nonisolated private func downloadAudio(_ videoId: String, progress: @escaping (Double) -> Void) async throws -> URL {
        let video = YouTube(videoID: videoId, methods: [.local, .remote])
        let streams: [YouTubeKit.Stream]
        do {
            streams = try await video.streams
        } catch {
            throw StepError(step: "YouTube", message: Downloader.describe(error))
        }
        let audio = streams.filterAudioOnly().filter { $0.fileExtension == .m4a }
        let sorted = audio.sorted { (a: YouTubeKit.Stream, b: YouTubeKit.Stream) -> Bool in
            let x: Int = a.bitrate ?? 0
            let y: Int = b.bitrate ?? 0
            return x > y
        }
        guard !sorted.isEmpty else { throw StepError(step: "YouTube", message: "no .m4a audio for this video") }
        var lastError: Error = StepError(step: "download", message: "failed")
        for stream in sorted.prefix(2) {
            do {
                return try await fetchChunked(stream.url, progress: progress)
            } catch is CancellationError {
                throw CancellationError()
            } catch {
                lastError = error
            }
        }
        throw lastError
    }

    nonisolated static func describe(_ error: Error) -> String {
        let s = String(describing: error)
        if s.lowercased().contains("login") || s.lowercased().contains("agerestricted") { return "YouTube wants a login for this video (age limit)" }
        if s.lowercased().contains("unplayable") || s.lowercased().contains("unavailable") { return "video not available" }
        return error.localizedDescription == "The operation couldn’t be completed." ? s : error.localizedDescription
    }

    nonisolated private func fetchChunked(_ url: URL, progress: @escaping (Double) -> Void) async throws -> URL {
        let out = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".m4a")
        FileManager.default.createFile(atPath: out.path, contents: nil)
        guard let handle = try? FileHandle(forWritingTo: out) else { throw StepError(step: "download", message: "can't write the file") }
        defer { try? handle.close() }
        let chunk = 8 * 1024 * 1024
        var start = 0
        var total = -1
        var ua = Http.desktopUA
        if url.absoluteString.contains("c=IOS") { ua = "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)" }
        else if url.absoluteString.contains("c=ANDROID") { ua = "com.google.android.youtube/20.10.38 (Linux; U; Android 11) gzip" }
        while total < 0 || start < total {
            try Task.checkCancellation()
            var req = URLRequest(url: url, timeoutInterval: 30)
            req.setValue("bytes=\(start)-\(start + chunk - 1)", forHTTPHeaderField: "Range")
            req.setValue(ua, forHTTPHeaderField: "User-Agent")
            let (data, response) = try await Http.session.data(for: req)
            guard let http = response as? HTTPURLResponse else { throw StepError(step: "download", message: "no answer") }
            if http.statusCode == 403 { throw StepError(step: "download", message: "YouTube refused the download (403)") }
            guard http.statusCode == 206 || http.statusCode == 200 else { throw StepError(step: "download", message: "HTTP \(http.statusCode)") }
            if data.isEmpty { break }
            try handle.write(contentsOf: data)
            start += data.count
            if let range = http.value(forHTTPHeaderField: "Content-Range"), let t = range.split(separator: "/").last.flatMap({ Int($0) }) {
                total = t
            } else if http.statusCode == 200 {
                total = start
            }
            if total > 0 { progress(min(1, Double(start) / Double(total))) }
            if data.count < chunk && total < 0 { break }
        }
        if start < 10_000 { throw StepError(step: "download", message: "the file came out empty") }
        return out
    }
}

/// Writes tags into a downloaded .m4a and moves it into the Music folder.
enum Tagger {
    static func save(raw: URL, request: DownloadRequest, cover: UIImage?) async throws -> URL {
        let name = Store.safeName(request.label)
        let dest = Store.freeURL(in: Store.musicFolder, name: name, ext: "m4a")
        let asset = AVURLAsset(url: raw)
        var items: [AVMetadataItem] = []
        func add(_ id: AVMetadataIdentifier, _ value: (NSCopying & NSObjectProtocol)?, dataType: String? = nil) {
            guard let v = value else { return }
            let m = AVMutableMetadataItem()
            m.identifier = id
            m.value = v
            if let t = dataType { m.dataType = t }
            m.extendedLanguageTag = "und"
            items.append(m)
        }
        add(.commonIdentifierTitle, request.title as NSString)
        if !request.artist.isEmpty { add(.commonIdentifierArtist, request.artist as NSString) }
        if !request.album.isEmpty { add(.commonIdentifierAlbumName, request.album as NSString) }
        if let img = cover.map({ Artwork.resize($0, to: 1000) }), let jpg = img.jpegData(compressionQuality: 0.9) {
            add(.commonIdentifierArtwork, jpg as NSData, dataType: kCMMetadataBaseDataType_JPEG as String)
        }
        if let exporter = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetPassthrough) {
            exporter.outputURL = dest
            exporter.outputFileType = .m4a
            exporter.metadata = items
            await withCheckedContinuation { (cont: CheckedContinuation<Void, Never>) in
                exporter.exportAsynchronously { cont.resume() }
            }
            if exporter.status == .completed, FileManager.default.fileExists(atPath: dest.path) {
                return dest
            }
            try? FileManager.default.removeItem(at: dest)
        }
        // Tagging failed: keep the song anyway, untagged (the name still says artist and title).
        try FileManager.default.moveItem(at: raw, to: dest)
        return dest
    }
}
