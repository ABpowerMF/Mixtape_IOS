import Foundation
import SwiftUI
import UIKit

/// Everything the screens share: the library, playlists, the player and the downloader.
@MainActor
final class AppModel: ObservableObject {
    @Published private(set) var songs: [Song] = []
    @Published private(set) var albums: [Album] = []
    @Published private(set) var playlists: [Playlist] = []
    @Published private(set) var scanning = false
    @Published private(set) var scanProgress = ""
    @Published var toast: String?
    @Published var importing = false

    let player = Player()
    let downloader = Downloader()
    let theme = ThemeStore()

    private(set) var byId: [String: Song] = [:]
    private var matcher = Matcher([])
    private var toastTask: Task<Void, Never>?
    private var rescanQueued = false

    init() {
        // Makes "On My iPhone › Mixtape › Music" show up in the Files app straight away.
        _ = Store.musicFolder
        songs = Store.load([Song].self, "library.json") ?? []
        playlists = Store.load([Playlist].self, "playlists.json") ?? []
        rebuildIndex()
        player.resolve = { [weak self] id in self?.byId[id] }
        player.onSongStarted = { song in Stats.record(song) }
        player.libraryReady()
        downloader.onSaved = { [weak self] url, request in
            Task { @MainActor in await self?.addDownloaded(url, request) }
        }
        Task { await rescan() }
    }

    // MARK: - Library

    func rescan() async {
        guard !scanning else { rescanQueued = true; return }
        scanning = true
        Library.drainInbox()
        let existing = songs
        let found = await Task.detached(priority: .utility) { () -> [Song] in
            await Library.scan(existing: existing) { done, total in
                Task { @MainActor [weak self] in self?.scanProgress = "Reading tags \(done)/\(total)" }
            }
        }.value
        scanProgress = ""
        scanning = false
        if found != songs {
            songs = found
            rebuildIndex()
            Store.save(songs, "library.json")
            rematchAll()
            player.prune(valid: Set(byId.keys))
        }
        player.libraryReady()
        if rescanQueued {
            rescanQueued = false
            await rescan()
        }
    }

    private func rebuildIndex() {
        byId = Dictionary(songs.map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a })
        matcher = Matcher(songs)
        var groups: [String: [Song]] = [:]
        for s in songs where !s.album.isEmpty { groups[s.albumKey, default: []].append(s) }
        var built: [Album] = []
        for (key, list) in groups {
            built.append(AppModel.makeAlbum(key: key, songs: list))
        }
        built.sort { a, b in a.name.localizedCaseInsensitiveCompare(b.name) == .orderedAscending }
        albums = built
    }

    private static func trackOrder(_ s: Song) -> Int { s.trackNo == 0 ? 999 : s.trackNo }

    private static func makeAlbum(key: String, songs list: [Song]) -> Album {
        let sorted: [Song] = list.sorted { (a: Song, b: Song) -> Bool in
            let ta = trackOrder(a), tb = trackOrder(b)
            if ta != tb { return ta < tb }
            return a.title < b.title
        }
        var counts: [String: Int] = [:]
        for s in list { counts[s.mainArtist, default: 0] += 1 }
        var artist = ""
        var best = 0
        for (name, n) in counts where n > best {
            best = n
            artist = name
        }
        return Album(id: key, name: list[0].album, artist: artist, songs: sorted)
    }

    func song(_ id: String?) -> Song? { id.flatMap { byId[$0] } }

    func search(_ query: String) -> [Song] { matcher.search(query) }

    func importFiles(_ urls: [URL]) {
        let n = Library.importFiles(urls)
        show(n == 0 ? "No music files found there" : "Added \(n) song\(n == 1 ? "" : "s")")
        Task { await rescan() }
    }

    func delete(_ song: Song) {
        try? FileManager.default.removeItem(at: song.url)
        songs.removeAll { $0.id == song.id }
        rebuildIndex()
        Store.save(songs, "library.json")
        rematchAll()
        player.prune(valid: Set(byId.keys))
        show("Deleted \(song.title)")
    }

    private func addDownloaded(_ url: URL, _ request: DownloadRequest) async {
        guard let id = Store.relativeId(url) else { return }
        let values = try? url.resourceValues(forKeys: [.fileSizeKey, .contentModificationDateKey])
        let info = Library.FileInfo(id: id, url: url, size: values?.fileSize ?? 0,
                                    modified: values?.contentModificationDate?.timeIntervalSince1970 ?? 0)
        var song = await Library.read(info)
        song.added = Date().timeIntervalSince1970
        if song.title.isEmpty { song.title = request.title }
        if song.artist.isEmpty { song.artist = request.artist }
        if song.durationMs == 0 { song.durationMs = request.durationMs }
        songs.removeAll { $0.id == id }
        songs.append(song)
        rebuildIndex()
        Store.save(songs, "library.json")
        // Link it to the playlist song it was downloaded for, even if the names differ a little.
        if let pid = request.playlistId, let eid = request.entryId, let p = playlists.firstIndex(where: { $0.id == pid }),
           let e = playlists[p].entries.firstIndex(where: { $0.id == eid }) {
            playlists[p].entries[e].songId = id
        }
        rematchAll()
    }

    // MARK: - Playlists

    func rematchAll() {
        var changed = false
        for p in playlists.indices {
            for e in playlists[p].entries.indices {
                let entry = playlists[p].entries[e]
                if let sid = entry.songId, byId[sid] != nil { continue }
                let hit = playlists[p].isOwn ? nil : matcher.match(entry.wanted)?.id
                if hit != entry.songId {
                    playlists[p].entries[e].songId = hit
                    changed = true
                }
            }
        }
        savePlaylists()
        _ = changed
    }

    func savePlaylists() { Store.save(playlists, "playlists.json") }

    func playlist(_ id: String) -> Playlist? { playlists.first { $0.id == id } }

    /// Imports (or updates) a Spotify playlist / album / song from its link.
    func importSpotify(_ link: String) async throws -> Playlist {
        let list = try await Spotify.shared.importLink(link)
        let existing = playlists.firstIndex { $0.spotifyId == list.id && $0.kind == list.kind }
        let old = existing.map { playlists[$0] }
        let oldBySpotify = Dictionary((old?.entries ?? []).compactMap { e in e.spotifyId.map { ($0, e) } }, uniquingKeysWith: { a, _ in a })
        let entries: [PlaylistEntry] = list.tracks.map { t in
            var e = PlaylistEntry(title: t.title, artists: t.artists, album: t.album, durationMs: t.durationMs, spotifyId: t.id)
            if let prev = oldBySpotify[t.id] {
                e.id = prev.id
                e.songId = prev.songId
            }
            if e.songId == nil { e.songId = matcher.match(e.wanted)?.id }
            return e
        }
        var p = old ?? Playlist(name: list.name, kind: list.kind, spotifyId: list.id)
        p.name = list.name
        p.image = list.image ?? p.image
        p.entries = entries
        if let i = existing { playlists[i] = p } else { playlists.insert(p, at: 0) }
        savePlaylists()
        if let note = list.note { show(note) }
        return p
    }

    func createPlaylist(_ name: String, songs ids: [String] = []) -> Playlist {
        var p = Playlist(name: name.trimmed.isEmpty ? "My playlist" : name.trimmed)
        p.entries = ids.compactMap { byId[$0] }.map(entryFor)
        playlists.insert(p, at: 0)
        savePlaylists()
        return p
    }

    private func entryFor(_ s: Song) -> PlaylistEntry {
        PlaylistEntry(title: s.title, artists: s.artist.isEmpty ? [] : [s.artist], album: s.album, durationMs: s.durationMs, spotifyId: nil, songId: s.id)
    }

    func add(_ ids: [String], to playlistId: String) {
        guard let i = playlists.firstIndex(where: { $0.id == playlistId }) else { return }
        let have = Set(playlists[i].entries.compactMap { $0.songId })
        let new = ids.filter { !have.contains($0) }.compactMap { byId[$0] }.map(entryFor)
        playlists[i].entries += new
        savePlaylists()
        show(new.isEmpty ? "Already in \(playlists[i].name)" : "Added to \(playlists[i].name)")
    }

    func removeEntry(_ entryId: String, from playlistId: String) {
        guard let i = playlists.firstIndex(where: { $0.id == playlistId }) else { return }
        playlists[i].entries.removeAll { $0.id == entryId }
        savePlaylists()
    }

    func moveEntries(in playlistId: String, from: IndexSet, to: Int) {
        guard let i = playlists.firstIndex(where: { $0.id == playlistId }) else { return }
        playlists[i].entries.move(fromOffsets: from, toOffset: to)
        savePlaylists()
    }

    func rename(_ playlistId: String, to name: String) {
        guard let i = playlists.firstIndex(where: { $0.id == playlistId }), !name.trimmed.isEmpty else { return }
        playlists[i].name = name.trimmed
        savePlaylists()
    }

    func deletePlaylist(_ playlistId: String) {
        playlists.removeAll { $0.id == playlistId }
        savePlaylists()
    }

    /// Links a playlist song to a file by hand ("this is the right song").
    func link(entry entryId: String, in playlistId: String, to songId: String?) {
        guard let p = playlists.firstIndex(where: { $0.id == playlistId }),
              let e = playlists[p].entries.firstIndex(where: { $0.id == entryId }) else { return }
        playlists[p].entries[e].songId = songId
        savePlaylists()
    }

    func download(missingIn playlistId: String) {
        guard let p = playlist(playlistId) else { return }
        let busy = Set(downloader.jobs.filter { !$0.status.finished }.compactMap { $0.request.entryId })
        let reqs = p.entries.filter { $0.songId == nil && !busy.contains($0.id) }.map { e in
            DownloadRequest(title: e.title, artist: e.artists.first ?? "", album: e.album, durationMs: e.durationMs,
                            spotifyId: e.spotifyId, playlistId: p.id, entryId: e.id)
        }
        downloader.enqueue(reqs)
        show(reqs.isEmpty ? "Nothing missing" : "Downloading \(reqs.count) song\(reqs.count == 1 ? "" : "s")")
    }

    func download(entry: PlaylistEntry, in playlistId: String) {
        downloader.enqueue([DownloadRequest(title: entry.title, artist: entry.artists.first ?? "", album: entry.album,
                                            durationMs: entry.durationMs, spotifyId: entry.spotifyId, playlistId: playlistId, entryId: entry.id)])
        show("Downloading \(entry.title)")
    }

    // MARK: - Playing

    func play(_ list: [Song], start: Int, source: String, shuffled: Bool? = nil) {
        player.play(list.map { $0.id }, start: start, source: source, shuffled: shuffled)
    }

    func play(playlist p: Playlist, startEntry: String? = nil, shuffled: Bool? = nil) {
        let entries = p.entries.filter { $0.songId != nil && byId[$0.songId!] != nil }
        guard !entries.isEmpty else { show("No songs of this playlist are on your phone yet"); return }
        let start = startEntry.flatMap { id in entries.firstIndex { $0.id == id } } ?? (shuffled == true ? -1 : 0)
        player.play(entries.compactMap { $0.songId }, start: start, source: p.name, shuffled: shuffled)
        UserDefaults.standard.set(p.id, forKey: "lastPlaylist")
    }

    func queue(_ s: Song) {
        player.addToQueue([s.id])
        show("Added to queue")
    }

    func playNext(_ s: Song) {
        player.playNext([s.id])
        show("Plays next")
    }

    // MARK: - Messages

    func show(_ message: String) {
        toast = message
        toastTask?.cancel()
        toastTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 2_500_000_000)
            if !Task.isCancelled { self?.toast = nil }
        }
    }
}

/// How often each song was played (for "Most played"). Small and local.
enum Stats {
    static func record(_ song: Song) {
        var plays = UserDefaults.standard.dictionary(forKey: "stats.plays") as? [String: Int] ?? [:]
        plays[song.id, default: 0] += 1
        UserDefaults.standard.set(plays, forKey: "stats.plays")
    }

    static func plays() -> [String: Int] {
        UserDefaults.standard.dictionary(forKey: "stats.plays") as? [String: Int] ?? [:]
    }
}
