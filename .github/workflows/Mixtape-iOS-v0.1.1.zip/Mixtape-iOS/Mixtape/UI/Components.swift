import SwiftUI
import UIKit

// MARK: - Covers

struct CoverView: View {
    @EnvironmentObject var theme: ThemeStore
    let song: Song?
    var size: CGFloat = 48
    @State private var image: UIImage?

    var body: some View {
        ZStack {
            if let img = image {
                Image(uiImage: img).resizable().scaledToFill()
            } else {
                Placeholder(text: song?.title ?? "", size: size)
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: coverRadius(theme, size), style: .continuous))
        .task(id: song.map { "\($0.id)|\($0.modified)" } ?? "") {
            guard let s = song else { image = nil; return }
            image = Artwork.shared.cached(s)
            if image == nil { image = await Artwork.shared.image(for: s) }
        }
    }
}

struct RemoteCover: View {
    @EnvironmentObject var theme: ThemeStore
    let url: String?
    var fallback: Song? = nil
    var title: String = ""
    var size: CGFloat = 48
    @State private var image: UIImage?

    var body: some View {
        Group {
            if let img = image {
                Image(uiImage: img).resizable().scaledToFill()
                    .frame(width: size, height: size)
                    .clipShape(RoundedRectangle(cornerRadius: coverRadius(theme, size), style: .continuous))
            } else if let f = fallback {
                CoverView(song: f, size: size)
            } else {
                Placeholder(text: title, size: size)
                    .clipShape(RoundedRectangle(cornerRadius: coverRadius(theme, size), style: .continuous))
            }
        }
        .task(id: url ?? "") { image = await Artwork.shared.remote(url) }
    }
}

struct Placeholder: View {
    @EnvironmentObject var theme: ThemeStore
    let text: String
    let size: CGFloat

    var body: some View {
        ZStack {
            theme.p.raised
            Text(initials)
                .font(theme.font(max(10, size * 0.32), .bold))
                .foregroundColor(theme.p.fog)
        }
        .frame(width: size, height: size)
    }

    private var initials: String {
        let words = text.split(separator: " ").prefix(2)
        let s = words.compactMap { $0.first.map(String.init) }.joined().uppercased()
        return s.isEmpty ? "♪" : s
    }
}

// MARK: - Text

struct Header: View {
    @EnvironmentObject var theme: ThemeStore
    let title: String
    var subtitle: String? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(theme.path(title))
                .font(theme.font(26, .bold))
                .foregroundColor(theme.p.paper)
            if let s = subtitle {
                Text(s).font(theme.font(12)).foregroundColor(theme.p.fog)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 16)
        .padding(.top, 8)
    }
}

struct SectionTitle: View {
    @EnvironmentObject var theme: ThemeStore
    let text: String
    var body: some View {
        Text(theme.head(text))
            .font(theme.font(13, .semibold))
            .foregroundColor(theme.p.tape)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 16)
            .padding(.top, 16)
            .padding(.bottom, 4)
    }
}

/// A Mixtape button: "[ label ]" in terminal style, a filled pill in the rounded style.
struct MixButton: View {
    @EnvironmentObject var theme: ThemeStore
    let label: String
    var icon: String? = nil
    var primary = false
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                if let i = icon { Image(systemName: i).font(.system(size: 13, weight: .semibold)) }
                Text(theme.btn(label)).font(theme.font(13, .semibold)).lineLimit(1)
            }
            .padding(.horizontal, theme.rounded ? 14 : 8)
            .padding(.vertical, 8)
            .foregroundColor(primary ? theme.p.ink : theme.p.tape)
            .background(
                RoundedRectangle(cornerRadius: theme.rounded ? 20 : 3, style: .continuous)
                    .fill(primary ? theme.p.tape : (theme.rounded ? theme.p.raised : Color.clear))
            )
            .overlay(
                RoundedRectangle(cornerRadius: theme.rounded ? 20 : 3, style: .continuous)
                    .stroke(theme.rounded || primary ? Color.clear : theme.p.gap, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }
}

struct SearchField: View {
    @EnvironmentObject var theme: ThemeStore
    let placeholder: String
    @Binding var text: String
    var slim = false

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass").font(.system(size: slim ? 12 : 14)).foregroundColor(theme.p.fog)
            TextField("", text: $text, prompt: Text(placeholder).foregroundColor(theme.p.fog))
                .font(theme.font(slim ? 13 : 15))
                .foregroundColor(theme.p.paper)
                .autocorrectionDisabled()
                .textInputAutocapitalization(.never)
                .submitLabel(.search)
            if !text.isEmpty {
                Button { text = "" } label: { Image(systemName: "xmark.circle.fill").foregroundColor(theme.p.fog) }
                    .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 10)
        .frame(height: slim ? 34 : 40)
        .background(RoundedRectangle(cornerRadius: theme.rounded ? 12 : 4, style: .continuous).fill(theme.p.raised))
        .padding(.horizontal, 16)
    }
}

// MARK: - Rows

/// A row whose leading part (cover or number) can be dragged right to add the song to the queue.
/// Only drags that start on that part count, so scrolling and tapping never queue by accident.
struct SwipeToQueue<Lead: View, Rest: View>: View {
    @EnvironmentObject var theme: ThemeStore
    var enabled = true
    let onQueue: () -> Void
    @ViewBuilder let lead: () -> Lead
    @ViewBuilder let rest: () -> Rest
    @State private var dx: CGFloat = 0
    @State private var armed = false
    private let threshold: CGFloat = 96

    var body: some View {
        ZStack(alignment: .leading) {
            if dx > 0 {
                HStack(spacing: 8) {
                    Image(systemName: "text.badge.plus")
                    Text(theme.btn("add to queue")).font(theme.font(13, .semibold))
                }
                .foregroundColor(theme.p.tape)
                .padding(.leading, 20)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
                .background(theme.p.tape.opacity(armed ? 0.32 : 0.16))
            }
            HStack(spacing: 12) {
                if enabled {
                    lead().contentShape(Rectangle()).simultaneousGesture(drag)
                } else {
                    lead()
                }
                rest()
            }
            .background(dx > 0 ? theme.p.ink : Color.clear)
            .offset(x: dx)
        }
    }

    private var drag: some Gesture {
        DragGesture(minimumDistance: 12, coordinateSpace: .global)
            .onChanged { v in
                let w: CGFloat = v.translation.width
                let h: CGFloat = abs(v.translation.height)
                let sideways: Bool = w > 0 && w > h * 1.4
                guard dx > 0 || sideways else { return }
                dx = max(0, min(v.translation.width, 260))
                let nowArmed = dx >= threshold
                if nowArmed != armed {
                    armed = nowArmed
                    if nowArmed { UIImpactFeedbackGenerator(style: .medium).impactOccurred() }
                }
            }
            .onEnded { _ in
                if armed { onQueue() }
                withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) { dx = 0 }
                armed = false
            }
    }
}

struct SongRow: View {
    @EnvironmentObject var model: AppModel
    @EnvironmentObject var theme: ThemeStore
    @EnvironmentObject var player: Player
    @EnvironmentObject var nav: Nav
    let song: Song
    var number: Int? = nil
    var showCover = true
    var onTap: () -> Void

    var body: some View {
        let active = player.currentId == song.id
        SwipeToQueue(onQueue: { model.queue(song) }) {
            if let n = number, !showCover {
                Text(active ? "▶" : "\(n)")
                    .font(theme.font(13))
                    .foregroundColor(active ? theme.p.tape : theme.p.fog)
                    .frame(width: 32, height: 44)
            } else {
                CoverView(song: song, size: 46)
            }
        } rest: {
            Button(action: onTap) {
                HStack(spacing: 10) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(song.title).font(theme.font(15, .medium)).foregroundColor(active ? theme.p.tape : theme.p.paper).lineLimit(1)
                        Text(song.displayArtist).font(theme.font(12)).foregroundColor(theme.p.fog).lineLimit(1)
                    }
                    Spacer(minLength: 4)
                    Text(formatTime(song.durationMs)).font(theme.font(11)).foregroundColor(theme.p.fog)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 5)
        .contextMenu { SongMenu(song: song) }
    }
}

/// Long-press menu of a song.
struct SongMenu: View {
    @EnvironmentObject var model: AppModel
    @EnvironmentObject var nav: Nav
    let song: Song
    var extra: [MenuAction] = []

    var body: some View {
        Button { model.playNext(song) } label: { Label("Play next", systemImage: "text.insert") }
        Button { model.queue(song) } label: { Label("Add to queue", systemImage: "text.badge.plus") }
        Button { nav.addToPlaylist = [song.id] } label: { Label("Add to playlist", systemImage: "music.note.list") }
        if !song.album.isEmpty, let album = model.albums.first(where: { $0.id == song.albumKey }) {
            Button { nav.open(.album(album.id)) } label: { Label("Go to album", systemImage: "square.stack") }
        }
        Button { nav.lyricsFor = song } label: { Label("Lyrics", systemImage: "quote.bubble") }
        ForEach(extra) { a in
            Button(role: a.destructive ? .destructive : nil, action: a.action) { Label(a.title, systemImage: a.icon) }
        }
        Button(role: .destructive) { nav.confirmDelete = song } label: { Label("Delete file", systemImage: "trash") }
    }
}

struct MenuAction: Identifiable {
    let id = UUID()
    let title: String
    let icon: String
    var destructive = false
    let action: () -> Void
}

// MARK: - Progress

struct ProgressLine: View {
    @EnvironmentObject var theme: ThemeStore
    @ObservedObject var clock: PlayerClock

    var body: some View {
        GeometryReader { g in
            let f: CGFloat = fraction(clock)
            let filled: CGFloat = g.size.width * f
            ZStack(alignment: .leading) {
                Rectangle().fill(theme.p.gap)
                Rectangle().fill(theme.p.tape).frame(width: filled)
            }
        }
        .frame(height: 2)
    }
}

struct Toast: View {
    @EnvironmentObject var theme: ThemeStore
    let text: String
    var body: some View {
        Text(text)
            .font(theme.font(13, .medium))
            .foregroundColor(theme.p.ink)
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .background(RoundedRectangle(cornerRadius: theme.rounded ? 16 : 4, style: .continuous).fill(theme.p.paper))
            .shadow(color: .black.opacity(0.25), radius: 8, y: 2)
            .padding(.horizontal, 24)
    }
}

extension View {
    /// Mixtape look for a screen inside a navigation stack.
    func mixScreen(_ theme: ThemeStore) -> some View {
        self
            .background(theme.p.ink.ignoresSafeArea())
            .toolbarBackground(theme.p.ink, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(theme.p.isLight ? .light : .dark, for: .navigationBar)
    }
}

func coverRadius(_ theme: ThemeStore, _ size: CGFloat) -> CGFloat {
    let scale: CGFloat = size > 100 ? 2 : 1
    return theme.coverCorner * scale
}

/// 0…1 through the current song.
func fraction(_ clock: PlayerClock) -> CGFloat {
    guard clock.durationMs > 0 else { return 0 }
    let f: CGFloat = CGFloat(clock.positionMs) / CGFloat(clock.durationMs)
    return min(1, max(0, f))
}
